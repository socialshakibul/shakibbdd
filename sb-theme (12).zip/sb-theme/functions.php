<?php
/**
 * Sadik Bin Jalil block theme.
 *
 * @package sb-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SB_THEME_VERSION', '0.7.2' );

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
	add_editor_style( array( SB_FONTS_URL, 'assets/css/home.css', 'assets/css/about.css', 'assets/css/services.css', 'assets/css/projects.css', 'assets/css/pricing.css', 'assets/css/contact.css', 'assets/css/utilities.css', 'assets/css/about-utilities.css', 'assets/css/services-utilities.css', 'assets/css/projects-utilities.css', 'assets/css/pricing-utilities.css', 'assets/css/contact-utilities.css', 'assets/css/editor.css' ) );
} );

/* Speed: drop the emoji scripts WordPress loads by default. */
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
remove_action( 'admin_print_styles', 'print_emoji_styles' );

const SB_FONTS_URL = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap';

/* Same non-blocking Google Fonts loading as the original page. */
add_action( 'wp_head', function () {
	echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
	echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
	echo '<link rel="stylesheet" href="' . esc_url( SB_FONTS_URL ) . '" media="print" onload="this.media=\'all\'">' . "\n";
	echo '<noscript><link rel="stylesheet" href="' . esc_url( SB_FONTS_URL ) . '"></noscript>' . "\n";
}, 1 );

add_action( 'wp_enqueue_scripts', function () {
	$uri = get_theme_file_uri( 'assets/' );
	if ( is_front_page() ) {
		wp_enqueue_style( 'sb-home', $uri . 'css/home.css', array(), SB_THEME_VERSION );
		wp_enqueue_style( 'sb-utilities', $uri . 'css/utilities.css', array( 'sb-home' ), SB_THEME_VERSION );
	}
	if ( is_page( 'about' ) ) {
		wp_enqueue_style( 'sb-about', $uri . 'css/about.css', array(), SB_THEME_VERSION );
		wp_enqueue_style( 'sb-about-utilities', $uri . 'css/utilities.css', array( 'sb-about' ), SB_THEME_VERSION );
		wp_enqueue_style( 'sb-about-utilities2', $uri . 'css/about-utilities.css', array( 'sb-about' ), SB_THEME_VERSION );
	}
	if ( is_page( 'services' ) ) {
		wp_enqueue_style( 'sb-services', $uri . 'css/services.css', array(), SB_THEME_VERSION );
		wp_enqueue_style( 'sb-services-utilities', $uri . 'css/services-utilities.css', array( 'sb-services' ), SB_THEME_VERSION );
	}
	if ( is_page( 'projects' ) ) {
		wp_enqueue_style( 'sb-projects', $uri . 'css/projects.css', array(), SB_THEME_VERSION );
		wp_enqueue_style( 'sb-projects-utilities', $uri . 'css/projects-utilities.css', array( 'sb-projects' ), SB_THEME_VERSION );
	}
	if ( is_page( 'pricing' ) ) {
		wp_enqueue_style( 'sb-pricing', $uri . 'css/pricing.css', array(), SB_THEME_VERSION );
		wp_enqueue_style( 'sb-pricing-utilities', $uri . 'css/pricing-utilities.css', array( 'sb-pricing' ), SB_THEME_VERSION );
	}
	if ( is_page( 'contact' ) ) {
		wp_enqueue_style( 'sb-contact', $uri . 'css/contact.css', array(), SB_THEME_VERSION );
		wp_enqueue_style( 'sb-contact-utilities', $uri . 'css/contact-utilities.css', array( 'sb-contact' ), SB_THEME_VERSION );
	}
	wp_enqueue_style( 'sb-compat', $uri . 'css/compat.css', array(), SB_THEME_VERSION );
	wp_enqueue_script( 'sb-extras', $uri . 'js/extras.js', array(), SB_THEME_VERSION, true );
	if ( is_front_page() ) {
		wp_enqueue_script( 'sb-home', $uri . 'js/home.js', array( 'sb-extras' ), SB_THEME_VERSION, true );
	}
	if ( is_page( 'services' ) ) {
		wp_enqueue_script( 'sb-services', $uri . 'js/services.js', array( 'sb-extras' ), SB_THEME_VERSION, true );
	}
	if ( is_page( 'projects' ) ) {
		wp_enqueue_script( 'sb-projects', $uri . 'js/projects.js', array( 'sb-extras' ), SB_THEME_VERSION, true );
	}
	if ( is_page( 'pricing' ) ) {
		wp_enqueue_script( 'sb-pricing', $uri . 'js/pricing.js', array( 'sb-extras' ), SB_THEME_VERSION, true );
	}
	if ( is_page( 'contact' ) ) {
		wp_enqueue_script( 'sb-contact', $uri . 'js/contact.js', array( 'sb-extras' ), SB_THEME_VERSION, true );
	}
	if ( is_page( 'about' ) ) {
		wp_enqueue_script( 'sb-about', $uri . 'js/about.js', array( 'sb-extras' ), SB_THEME_VERSION, true );
	}
} );

/* Home page title, same as the original file. */
add_filter( 'pre_get_document_title', function ( $title ) {
	if ( is_front_page() && ! defined( 'WPSEO_VERSION' ) && ! defined( 'RANK_MATH_VERSION' ) ) {
		return 'Sadik Bin Jalil | WordPress, WooCommerce & eCommerce Developer in Sylhet';
	}
	if ( is_page( 'services' ) && ! defined( 'WPSEO_VERSION' ) && ! defined( 'RANK_MATH_VERSION' ) ) {
		return 'Services | Sadik Bin Jalil — WordPress & Web Development';
	}
	if ( is_page( 'projects' ) && ! defined( 'WPSEO_VERSION' ) && ! defined( 'RANK_MATH_VERSION' ) ) {
		return 'Projects | Sadik Bin Jalil — Selected Websites & Concepts';
	}
	if ( is_page( 'pricing' ) && ! defined( 'WPSEO_VERSION' ) && ! defined( 'RANK_MATH_VERSION' ) ) {
		return 'Pricing | Sadik Bin Jalil — Website Packages & Estimates';
	}
	if ( is_page( 'contact' ) && ! defined( 'WPSEO_VERSION' ) && ! defined( 'RANK_MATH_VERSION' ) ) {
		return 'Contact | Sadik Bin Jalil — Start a Website Project';
	}
	if ( is_page( 'about' ) && ! defined( 'WPSEO_VERSION' ) && ! defined( 'RANK_MATH_VERSION' ) ) {
		return 'About Sadik Bin Jalil | WordPress, WooCommerce & eCommerce Developer';
	}
	return $title;
}, 9 );

/* Home page SEO tags (meta, Open Graph, schema), kept exactly as in the audited HTML. */
add_action( 'wp_head', function () {
	if ( ! is_front_page() ) {
		return;
	}
	echo <<<'EOT_HEAD'
<meta name="description" content="Sadik Bin Jalil is a WordPress and WooCommerce developer, eCommerce specialist and co-founder of Freelancer Lab in Sylhet, Bangladesh. Fast, responsive, SEO-ready websites.">
<meta name="theme-color" content="#f7f9fc">
<meta name="author" content="Sadik Bin Jalil">
<meta name="robots" content="index, follow, max-image-preview:large">
<meta name="color-scheme" content="light">
<meta name="geo.region" content="BD-60">
<meta name="geo.placename" content="Sylhet">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Sadik Bin Jalil">
<meta property="og:title" content="Sadik Bin Jalil | WordPress, WooCommerce & eCommerce Developer in Sylhet">
<meta property="og:description" content="Sadik Bin Jalil is a WordPress and WooCommerce developer, eCommerce specialist and co-founder of Freelancer Lab in Sylhet, Bangladesh. Fast, responsive, SEO-ready websites.">
<meta property="og:locale" content="en_US">
<meta property="og:image:alt" content="Sadik Bin Jalil, WordPress and eCommerce developer in Sylhet">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="Sadik Bin Jalil | WordPress, WooCommerce & eCommerce Developer in Sylhet">
<meta name="twitter:description" content="Sadik Bin Jalil is a WordPress and WooCommerce developer, eCommerce specialist and co-founder of Freelancer Lab in Sylhet, Bangladesh. Fast, responsive, SEO-ready websites.">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='18' fill='%23101b2d'/%3E%3Ctext x='32' y='41' font-family='Arial' font-size='26' font-weight='900' text-anchor='middle' fill='%23b7f36b'%3ESB%3C/text%3E%3C/svg%3E">
<script type="application/ld+json">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","name":"Sadik Bin Jalil","inLanguage":"en"},{"@type":"Person","name":"Sadik Bin Jalil","jobTitle":"WordPress & eCommerce Developer","description":"WordPress, WooCommerce and eCommerce specialist, instructor and co-founder of Freelancer Lab, Sylhet.","homeLocation":{"@type":"Place","address":{"@type":"PostalAddress","addressLocality":"Sylhet","addressCountry":"BD"}},"worksFor":{"@type":"Organization","name":"Freelancer Lab"},"knowsAbout":["WordPress","WooCommerce","eCommerce","Elementor","Website performance","SEO"],"sameAs":["https://www.linkedin.com/in/sadikbinjalil/","https://github.com/sadikbinjalil","https://www.facebook.com/sadikbinjalil"]},{"@type":"EducationalOrganization","name":"Freelancer Lab","address":{"@type":"PostalAddress","streetAddress":"West World Shopping City, 9th Floor, Zindabazar","addressLocality":"Sylhet","addressCountry":"BD"}}]}</script>
EOT_HEAD;
	echo "\n";
	echo '<noscript><style>.reveal{opacity:1!important;transform:none!important}</style></noscript>' . "\n";
}, 2 );

/* About page SEO tags (meta, Open Graph, schema), kept exactly as in about_sera.html. */
add_action( 'wp_head', function () {
	if ( ! is_page( 'about' ) ) {
		return;
	}
	echo <<<'EOT_ABOUT_HEAD'
<meta name="description" content="About Sadik Bin Jalil: WordPress, WooCommerce and eCommerce developer in Sylhet, Bangladesh. Experience, skills, work process, values and selected website projects.">
<meta name="theme-color" content="#f7f9fc">
<meta name="author" content="Sadik Bin Jalil">
<meta name="robots" content="index, follow, max-image-preview:large">
<meta name="color-scheme" content="light">
<meta name="geo.region" content="BD-60">
<meta name="geo.placename" content="Sylhet">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Sadik Bin Jalil">
<meta property="og:title" content="About Sadik Bin Jalil | WordPress &amp; eCommerce Developer">
<meta property="og:description" content="About Sadik Bin Jalil: WordPress, WooCommerce and eCommerce developer in Sylhet, Bangladesh. Experience, skills, work process, values and selected website projects.">
<meta property="og:locale" content="en_US">
<meta property="og:image:alt" content="Sadik Bin Jalil, WordPress and eCommerce developer in Sylhet">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="About Sadik Bin Jalil | WordPress &amp; eCommerce Developer">
<meta name="twitter:description" content="About Sadik Bin Jalil: WordPress, WooCommerce and eCommerce developer in Sylhet, Bangladesh. Experience, skills, work process, values and selected website projects.">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='18' fill='%23101b2d'/%3E%3Ctext x='32' y='41' font-family='Arial' font-size='26' font-weight='900' text-anchor='middle' fill='%23b7f36b'%3ESB%3C/text%3E%3C/svg%3E">
<noscript><script type="application/ld+json">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","name":"Sadik Bin Jalil","inLanguage":"en"},{"@type":"Person","name":"Sadik Bin Jalil","jobTitle":"WordPress & eCommerce Developer","description":"WordPress, WooCommerce and eCommerce specialist, instructor and co-founder of Freelancer Lab, Sylhet.","homeLocation":{"@type":"Place","address":{"@type":"PostalAddress","addressLocality":"Sylhet","addressCountry":"BD"}},"worksFor":{"@type":"Organization","name":"Freelancer Lab"},"knowsAbout":["WordPress","WooCommerce","eCommerce","Elementor","Website performance","SEO"],"sameAs":["https://www.linkedin.com/in/sadikbinjalil/","https://github.com/sadikbinjalil","https://www.facebook.com/sadikbinjalil"]},{"@type":"EducationalOrganization","name":"Freelancer Lab","address":{"@type":"PostalAddress","streetAddress":"West World Shopping City, 9th Floor, Zindabazar","addressLocality":"Sylhet","addressCountry":"BD"}}]}</script>
EOT_ABOUT_HEAD;
	echo "\n";
	echo '<noscript><style>.reveal{opacity:1!important;transform:none!important}</style></noscript>' . "\n";
}, 2 );

/* ------------------------------------------------------------------
 * Pages the theme needs (Home, About). Created once, as real pages that
 * show up in Dashboard > Pages, on activation or the next dashboard visit
 * after a theme update. Add new slugs here as more pages are converted.
 * ---------------------------------------------------------------- */
function sb_theme_required_pages() {
	return array(
		'home'  => 'Home',
		'about' => 'About',
		'services' => 'Services',
		'contact' => 'Contact',
		'pricing' => 'Pricing',
		'projects' => 'Projects',
	);
}

function sb_theme_setup_pages() {
	$done = get_option( 'sb_theme_pages_done', array() );
	if ( ! is_array( $done ) ) {
		$done = array();
	}
	$home_id = 0;
	foreach ( sb_theme_required_pages() as $slug => $title ) {
		$existing = get_page_by_path( $slug );
		if ( $existing ) {
			if ( 'home' === $slug ) {
				$home_id = (int) $existing->ID;
			}
			continue;
		}
		if ( in_array( $slug, $done, true ) ) {
			continue;
		}
		$id = wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_title'   => $title,
				'post_name'    => $slug,
				'post_content' => '',
			)
		);
		if ( $id && ! is_wp_error( $id ) ) {
			$done[] = $slug;
			if ( 'home' === $slug ) {
				$home_id = (int) $id;
			}
		}
	}
	update_option( 'sb_theme_pages_done', $done );

	/* Use the Home page as the front page, once, only if the site still shows latest posts. */
	if ( $home_id && ! get_option( 'sb_theme_front_done' ) ) {
		if ( 'posts' === get_option( 'show_on_front' ) ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $home_id );
		}
		update_option( 'sb_theme_front_done', 1 );
	}

	/* Clean URLs such as /about/ need the Post name permalink structure. */
	global $wp_rewrite;
	if ( ! get_option( 'permalink_structure' ) ) {
		$wp_rewrite->set_permalink_structure( '/%postname%/' );
	}
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'sb_theme_setup_pages' );

add_action( 'admin_init', function () {
	if ( get_option( 'sb_theme_setup_version' ) !== SB_THEME_VERSION ) {
		sb_theme_setup_pages();
		update_option( 'sb_theme_setup_version', SB_THEME_VERSION );
	}
} );

/* Services page SEO tags (meta, Open Graph, schema), kept exactly as in service_sra.html. */
add_action( 'wp_head', function () {
	if ( ! is_page( 'services' ) ) {
		return;
	}
	echo <<<'EOT_SERVICES_HEAD'
<meta name="description" content="Services by Sadik Bin Jalil: web design, development, WordPress, UI/UX, website redesign, responsive websites and SEO in Sylhet, Bangladesh.">
<meta name="theme-color" content="#f7f9fc">
<meta name="author" content="Sadik Bin Jalil">
<meta name="robots" content="index, follow, max-image-preview:large">
<meta name="color-scheme" content="light">
<meta name="geo.region" content="BD-60">
<meta name="geo.placename" content="Sylhet">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Sadik Bin Jalil">
<meta property="og:title" content="Services | Sadik Bin Jalil — WordPress &amp; Web Development">
<meta property="og:description" content="Services by Sadik Bin Jalil: web design, development, WordPress, UI/UX, website redesign, responsive websites and SEO in Sylhet, Bangladesh.">
<meta property="og:locale" content="en_US">
<meta property="og:image:alt" content="Sadik Bin Jalil, WordPress and eCommerce developer in Sylhet">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="Services | Sadik Bin Jalil — WordPress &amp; Web Development">
<meta name="twitter:description" content="Services by Sadik Bin Jalil: web design, development, WordPress, UI/UX, website redesign, responsive websites and SEO in Sylhet, Bangladesh.">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='18' fill='%23101b2d'/%3E%3Ctext x='32' y='41' font-family='Arial' font-size='26' font-weight='900' text-anchor='middle' fill='%23b7f36b'%3ESB%3C/text%3E%3C/svg%3E">
<noscript><script type="application/ld+json">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","name":"Sadik Bin Jalil","inLanguage":"en"},{"@type":"Person","name":"Sadik Bin Jalil","jobTitle":"WordPress & eCommerce Developer","description":"WordPress, WooCommerce and eCommerce specialist, instructor and co-founder of Freelancer Lab, Sylhet.","homeLocation":{"@type":"Place","address":{"@type":"PostalAddress","addressLocality":"Sylhet","addressCountry":"BD"}},"worksFor":{"@type":"Organization","name":"Freelancer Lab"},"knowsAbout":["WordPress","WooCommerce","eCommerce","Elementor","Website performance","SEO"],"sameAs":["https://www.linkedin.com/in/sadikbinjalil/","https://github.com/sadikbinjalil","https://www.facebook.com/sadikbinjalil"]},{"@type":"EducationalOrganization","name":"Freelancer Lab","address":{"@type":"PostalAddress","streetAddress":"West World Shopping City, 9th Floor, Zindabazar","addressLocality":"Sylhet","addressCountry":"BD"}}]}</script>
EOT_SERVICES_HEAD;
	echo "\n";
	echo '<noscript><style>.reveal{opacity:1!important;transform:none!important}</style></noscript>' . "\n";
}, 2 );

/* Projects page SEO tags (meta, Open Graph, schema), kept exactly as in the source HTML. */
add_action( 'wp_head', function () {
	if ( ! is_page( 'projects' ) ) {
		return;
	}
	echo <<<'EOT_PROJECTS_HEAD'
<meta name="description" content="Selected website projects and concept explorations by Sadik Bin Jalil: WordPress, eCommerce, UI/UX and landing page designs.">
<meta name="theme-color" content="#f7f9fc">
<meta name="author" content="Sadik Bin Jalil">
<meta name="robots" content="index, follow, max-image-preview:large">
<meta name="color-scheme" content="light">
<meta name="geo.region" content="BD-60">
<meta name="geo.placename" content="Sylhet">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Sadik Bin Jalil">
<meta property="og:title" content="Projects | Sadik Bin Jalil — Selected Websites &amp; Concepts">
<meta property="og:description" content="Selected website projects and concept explorations by Sadik Bin Jalil: WordPress, eCommerce, UI/UX and landing page designs.">
<meta property="og:locale" content="en_US">
<meta property="og:image:alt" content="Sadik Bin Jalil, WordPress and eCommerce developer in Sylhet">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="Projects | Sadik Bin Jalil — Selected Websites &amp; Concepts">
<meta name="twitter:description" content="Selected website projects and concept explorations by Sadik Bin Jalil: WordPress, eCommerce, UI/UX and landing page designs.">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='18' fill='%23101b2d'/%3E%3Ctext x='32' y='41' font-family='Arial' font-size='26' font-weight='900' text-anchor='middle' fill='%23b7f36b'%3ESB%3C/text%3E%3C/svg%3E">
<noscript><script type="application/ld+json">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","name":"Sadik Bin Jalil","inLanguage":"en"},{"@type":"Person","name":"Sadik Bin Jalil","jobTitle":"WordPress & eCommerce Developer","description":"WordPress, WooCommerce and eCommerce specialist, instructor and co-founder of Freelancer Lab, Sylhet.","homeLocation":{"@type":"Place","address":{"@type":"PostalAddress","addressLocality":"Sylhet","addressCountry":"BD"}},"worksFor":{"@type":"Organization","name":"Freelancer Lab"},"knowsAbout":["WordPress","WooCommerce","eCommerce","Elementor","Website performance","SEO"],"sameAs":["https://www.linkedin.com/in/sadikbinjalil/","https://github.com/sadikbinjalil","https://www.facebook.com/sadikbinjalil"]},{"@type":"EducationalOrganization","name":"Freelancer Lab","address":{"@type":"PostalAddress","streetAddress":"West World Shopping City, 9th Floor, Zindabazar","addressLocality":"Sylhet","addressCountry":"BD"}}]}</script>
EOT_PROJECTS_HEAD;
	echo "\n";
	echo '<noscript><style>.reveal{opacity:1!important;transform:none!important}</style></noscript>' . "\n";
}, 2 );

/* Pricing page SEO tags (meta, Open Graph, schema), kept exactly as in the source HTML. */
add_action( 'wp_head', function () {
	if ( ! is_page( 'pricing' ) ) {
		return;
	}
	echo <<<'EOT_PRICING_HEAD'
<meta name="description" content="Sample website pricing by Sadik Bin Jalil: Starter, Business, WordPress Pro and eCommerce packages, optional extras and an interactive estimate.">
<meta name="theme-color" content="#f7f9fc">
<meta name="author" content="Sadik Bin Jalil">
<meta name="robots" content="index, follow, max-image-preview:large">
<meta name="color-scheme" content="light">
<meta name="geo.region" content="BD-60">
<meta name="geo.placename" content="Sylhet">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Sadik Bin Jalil">
<meta property="og:title" content="Pricing | Sadik Bin Jalil — Website Packages &amp; Estimates">
<meta property="og:description" content="Sample website pricing by Sadik Bin Jalil: Starter, Business, WordPress Pro and eCommerce packages, optional extras and an interactive estimate.">
<meta property="og:locale" content="en_US">
<meta property="og:image:alt" content="Sadik Bin Jalil, WordPress and eCommerce developer in Sylhet">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="Pricing | Sadik Bin Jalil — Website Packages &amp; Estimates">
<meta name="twitter:description" content="Sample website pricing by Sadik Bin Jalil: Starter, Business, WordPress Pro and eCommerce packages, optional extras and an interactive estimate.">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='18' fill='%23101b2d'/%3E%3Ctext x='32' y='41' font-family='Arial' font-size='26' font-weight='900' text-anchor='middle' fill='%23b7f36b'%3ESB%3C/text%3E%3C/svg%3E">
<noscript><script type="application/ld+json">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","name":"Sadik Bin Jalil","inLanguage":"en"},{"@type":"Person","name":"Sadik Bin Jalil","jobTitle":"WordPress & eCommerce Developer","description":"WordPress, WooCommerce and eCommerce specialist, instructor and co-founder of Freelancer Lab, Sylhet.","homeLocation":{"@type":"Place","address":{"@type":"PostalAddress","addressLocality":"Sylhet","addressCountry":"BD"}},"worksFor":{"@type":"Organization","name":"Freelancer Lab"},"knowsAbout":["WordPress","WooCommerce","eCommerce","Elementor","Website performance","SEO"],"sameAs":["https://www.linkedin.com/in/sadikbinjalil/","https://github.com/sadikbinjalil","https://www.facebook.com/sadikbinjalil"]},{"@type":"EducationalOrganization","name":"Freelancer Lab","address":{"@type":"PostalAddress","streetAddress":"West World Shopping City, 9th Floor, Zindabazar","addressLocality":"Sylhet","addressCountry":"BD"}}]}</script>
EOT_PRICING_HEAD;
	echo "\n";
	echo '<noscript><style>.reveal{opacity:1!important;transform:none!important}</style></noscript>' . "\n";
}, 2 );

/* Contact page SEO tags (meta, Open Graph, schema), kept exactly as in the source HTML. */
add_action( 'wp_head', function () {
	if ( ! is_page( 'contact' ) ) {
		return;
	}
	echo <<<'EOT_CONTACT_HEAD'
<meta name="description" content="Contact Sadik Bin Jalil to discuss a WordPress, website design, redesign or eCommerce project. Send a project brief and plan the next step.">
<meta name="theme-color" content="#f7f9fc">
<meta name="author" content="Sadik Bin Jalil">
<meta name="robots" content="index, follow, max-image-preview:large">
<meta name="color-scheme" content="light">
<meta name="geo.region" content="BD-60">
<meta name="geo.placename" content="Sylhet">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Sadik Bin Jalil">
<meta property="og:title" content="Contact | Sadik Bin Jalil — Start a Website Project">
<meta property="og:description" content="Contact Sadik Bin Jalil to discuss a WordPress, website design, redesign or eCommerce project. Send a project brief and plan the next step.">
<meta property="og:locale" content="en_US">
<meta property="og:image:alt" content="Sadik Bin Jalil, WordPress and eCommerce developer in Sylhet">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="Contact | Sadik Bin Jalil — Start a Website Project">
<meta name="twitter:description" content="Contact Sadik Bin Jalil to discuss a WordPress, website design, redesign or eCommerce project. Send a project brief and plan the next step.">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='18' fill='%23101b2d'/%3E%3Ctext x='32' y='41' font-family='Arial' font-size='26' font-weight='900' text-anchor='middle' fill='%23b7f36b'%3ESB%3C/text%3E%3C/svg%3E">
<noscript><script type="application/ld+json">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","name":"Sadik Bin Jalil","inLanguage":"en"},{"@type":"Person","name":"Sadik Bin Jalil","jobTitle":"WordPress & eCommerce Developer","description":"WordPress, WooCommerce and eCommerce specialist, instructor and co-founder of Freelancer Lab, Sylhet.","homeLocation":{"@type":"Place","address":{"@type":"PostalAddress","addressLocality":"Sylhet","addressCountry":"BD"}},"worksFor":{"@type":"Organization","name":"Freelancer Lab"},"knowsAbout":["WordPress","WooCommerce","eCommerce","Elementor","Website performance","SEO"],"sameAs":["https://www.linkedin.com/in/sadikbinjalil/","https://github.com/sadikbinjalil","https://www.facebook.com/sadikbinjalil"]},{"@type":"EducationalOrganization","name":"Freelancer Lab","address":{"@type":"PostalAddress","streetAddress":"West World Shopping City, 9th Floor, Zindabazar","addressLocality":"Sylhet","addressCountry":"BD"}}]}</script>
EOT_CONTACT_HEAD;
	echo "\n";
	echo '<noscript><style>.reveal{opacity:1!important;transform:none!important}</style></noscript>' . "\n";
}, 2 );
