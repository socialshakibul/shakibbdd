/* Back to Top (separate script so it always runs) */
(function(){
  var topBtn=document.getElementById('backToTop');
  if(!topBtn)return;
  function toggleTop(){
    var y=window.pageYOffset||document.documentElement.scrollTop||document.body.scrollTop||0;
    topBtn.classList.toggle('show',y>300);
  }
  window.addEventListener('scroll',toggleTop,{passive:true});
  window.addEventListener('load',toggleTop);
  toggleTop();
  topBtn.addEventListener('click',function(){
    try{window.scrollTo({top:0,behavior:'smooth'});}catch(e){window.scrollTo(0,0);}
  });
})();


(function(){
  const menuToggle=document.getElementById('menuToggle');
  const nav=document.getElementById('mainNav');
  menuToggle.addEventListener('click',function(){
    const open=nav.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded',String(open));
    menuToggle.classList.toggle('menu-open',open);
  });
  nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');menuToggle.setAttribute('aria-expanded','false');menuToggle.classList.remove('menu-open')}));
  const bar=document.getElementById('progressBar');
  function updateProgress(){
    const max=document.documentElement.scrollHeight-window.innerHeight;
    const value=max>0?(window.scrollY/max)*100:0;
    bar.style.width=Math.min(100,Math.max(0,value))+'%';
  }
  window.addEventListener('scroll',updateProgress,{passive:true});window.addEventListener('resize',updateProgress);updateProgress();
  const animatedCounters = new WeakSet();
  const reduceMotion=window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  function animateCounter(el){
    if(animatedCounters.has(el)) return;
    animatedCounters.add(el);
    if(reduceMotion){el.textContent=Number(el.dataset.count||0).toLocaleString("en-US")+(el.dataset.suffix||"");return;}
    const target=Number(el.dataset.count||0), suffix=el.dataset.suffix||'';
    const duration=1500, start=performance.now();
    function tick(now){
      const p=Math.min(1,(now-start)/duration);
      const eased=1-Math.pow(1-p,3);
      el.textContent=Math.round(target*eased).toLocaleString('en-US')+suffix;
      if(p<1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }
  const counterObserver = new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){animateCounter(entry.target);counterObserver.unobserve(entry.target)}}),{threshold:.25});
  document.querySelectorAll('.count-up').forEach(el=>counterObserver.observe(el));
  const revealObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('is-visible');entry.target.querySelectorAll('.count-up').forEach(animateCounter);revealObserver.unobserve(entry.target)}}),{threshold:.12});
  document.querySelectorAll('.reveal').forEach(el=>revealObserver.observe(el));
  // Project cards open a full detail modal (these are clearly labelled concepts).
  const projectDetails=[
    {category:'Education · WordPress',title:'Freelancer Lab Training Center',intro:'A WordPress website for an IT training center in Sylhet, designed to present courses clearly and make it easy for learners to get in touch.',items:[['Industry','IT training & education'],['Platform','WordPress'],['Period','Nov – Dec 2023'],['Live site','freelancerlabbd.com']],features:['Clear course and program presentation','Mobile-friendly layouts for students on phones','Simple enquiry and contact paths','Search-friendly page structure'],note:'Project period is from Sadik’s LinkedIn. Build focus describes the goals of this type of site; confirm details before publishing.',url:'https://freelancerlabbd.com'},
    {category:'Legal services · WordPress',title:'Imran Solicitors',intro:'A professional WordPress website for a UK solicitors’ practice, where trust, clarity and easy contact matter most.',items:[['Industry','Legal services'],['Platform','WordPress'],['Client region','United Kingdom'],['Live site','imransolicitors.co.uk']],features:['Clear presentation of legal services','Credible, professional visual tone','Easy ways to request a consultation','Responsive layout across devices'],note:'Listed in Sadik’s public portfolio. Build focus describes the goals of this type of site; confirm details before publishing.',url:'https://imransolicitors.co.uk'},
    {category:'Home services · WordPress',title:'Great American Garage Doors',intro:'A WordPress website for a garage door business, built to help local customers understand the services and call or request a quote quickly.',items:[['Industry','Home services'],['Platform','WordPress'],['Goal','Local enquiries and calls'],['Live site','greatamericangaragedoors.com']],features:['Service pages that are easy to scan','Prominent call and quote actions','Fast, mobile-first layout','Search-friendly local content structure'],note:'Listed in Sadik’s public portfolio. Build focus describes the goals of this type of site; confirm details before publishing.',url:'https://greatamericangaragedoors.com'}
  ];
  const projectModal=document.getElementById('projectModal');
  const modalClose=document.getElementById('projectModalClose');
  let previousFocus=null;
  function closeProjectModal(){projectModal.classList.remove('is-open');projectModal.setAttribute('aria-hidden','true');document.body.style.overflow='';if(previousFocus)previousFocus.focus()}
  projectModal.addEventListener('keydown',e=>{if(e.key!=='Tab')return;const focusable=Array.from(projectModal.querySelectorAll('button:not([disabled]),a[href],input:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')).filter(el=>el.offsetParent!==null);if(!focusable.length)return;const first=focusable[0],last=focusable[focusable.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}});
  document.querySelectorAll('.project-detail-trigger').forEach(card=>card.addEventListener('click',()=>{
    const item=projectDetails[Number(card.dataset.project)];if(!item)return;previousFocus=card;
    document.getElementById('projectModalCategory').textContent=item.category;
    document.getElementById('projectModalTitle').textContent=item.title;
    document.getElementById('projectModalIntro').textContent=item.intro;
    document.getElementById('projectDetailGrid').replaceChildren(...item.items.map(([label,value])=>{const box=document.createElement('div');box.className='project-detail-item';const small=document.createElement('small');small.textContent=label;const strong=document.createElement('strong');strong.textContent=value;box.append(small,strong);return box;}));
    document.getElementById('projectDetailList').replaceChildren(...item.features.map(feature=>{const li=document.createElement('li');li.textContent=feature;return li;}));
    document.getElementById('projectModalNote').textContent=item.note;document.getElementById('projectModalLink').href=item.url;
    projectModal.classList.add('is-open');projectModal.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';modalClose.focus();
  }));
  modalClose.addEventListener('click',closeProjectModal);
  projectModal.addEventListener('click',e=>{if(e.target===projectModal)closeProjectModal()});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&projectModal.classList.contains('is-open'))closeProjectModal()});

  // Comment demo: local to this browser only. Production sharing needs a backend.
  const starterComments=[{name:'Visitor',comment:'Have a question about a website project? Leave a comment and start the conversation.'}];
  const commentsKey='sadik-portfolio-visitor-comments-v1';
  let visitorComments=starterComments.slice();
  const SBd=window.SBPM||{},pageT0=Date.now();
  if(SBd.commentUrl){visitorComments=visitorComments.concat((SBd.comments||[]).filter(c=>c&&typeof c.name==='string'&&typeof c.comment==='string'));}
  else{
  try{const saved=JSON.parse(localStorage.getItem(commentsKey)||'[]');if(Array.isArray(saved))visitorComments=visitorComments.concat(saved.filter(c=>c&&typeof c.name==='string'&&typeof c.comment==='string'));}catch(e){}
  }
  let commentIndex=0,commentTimer=null,commentPaused=false;
  const commentText=document.getElementById('rotatingCommentText'),commentName=document.getElementById('rotatingCommentName'),commentAvatar=document.getElementById('rotatingCommentAvatar'),commentCounter=document.getElementById('commentCounter'),commentDots=document.getElementById('commentDots'),commentCard=document.getElementById('rotatingComment');
  function renderCommentDots(){commentDots.replaceChildren(...visitorComments.map((_,i)=>{const dot=document.createElement('span');if(i===commentIndex)dot.classList.add('active');return dot;}));}
  function showVisitorComment(){if(!visitorComments.length)return;const c=visitorComments[commentIndex%visitorComments.length];commentCard.style.animation='none';void commentCard.offsetWidth;commentCard.style.animation='';commentText.textContent=c.comment;commentName.textContent=c.name;commentAvatar.textContent=(c.name.trim()[0]||'V').toUpperCase();document.getElementById('cmBar').style.animation='none';void document.getElementById('cmBar').offsetWidth;document.getElementById('cmBar').style.animation='';document.querySelector('.cm-progress').style.visibility=visitorComments.length>1?'visible':'hidden';commentCounter.textContent='Comment '+(commentIndex+1)+' of '+visitorComments.length;renderCommentDots();}
  function restartCommentRotation(){if(commentTimer)clearInterval(commentTimer);commentTimer=setInterval(()=>{if(!document.hidden&&!commentPaused&&visitorComments.length>1){commentIndex=(commentIndex+1)%visitorComments.length;showVisitorComment()}},5000)}
  document.addEventListener('visibilitychange',()=>{if(document.hidden){if(commentTimer)clearInterval(commentTimer);commentTimer=null}else restartCommentRotation()});
  showVisitorComment();restartCommentRotation();
  document.getElementById('visitorCommentForm').addEventListener('submit',e=>{
    e.preventDefault();const name=document.getElementById('visitorName').value.trim().slice(0,60);const comment=document.getElementById('visitorComment').value.trim().slice(0,500);const status=document.getElementById('feedbackStatus');
    if(!name||!comment){status.textContent='Please enter your name and comment.';return;}
    if(SBd.commentUrl){
      const btn=e.target.querySelector('button[type=submit]'),form=e.target;if(btn)btn.disabled=true;status.textContent='Sending…';
      fetch(SBd.commentUrl,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({name:name,comment:comment,elapsed:Date.now()-pageT0})}).then(r=>r.json().then(j=>({ok:r.ok,j:j}))).then(res=>{if(btn)btn.disabled=false;if(res.ok){status.textContent='Thanks! Your comment was sent and will appear after it is approved.';form.reset();document.getElementById('cmCount').textContent='0 / 500';}else{status.textContent=(res.j&&res.j.message)?res.j.message:'Sorry, your comment could not be sent. Please try again.';}}).catch(()=>{if(btn)btn.disabled=false;status.textContent='Sorry, your comment could not be sent. Please try again.';});
      return;
    }
    const entry={name,comment};visitorComments.push(entry);commentIndex=visitorComments.length-1;
    try{const saved=JSON.parse(localStorage.getItem(commentsKey)||'[]');const safe=Array.isArray(saved)?saved:[];safe.push(entry);localStorage.setItem(commentsKey,JSON.stringify(safe.slice(-40)));status.textContent='Thanks! Your comment is now shown in this browser.';}catch(err){status.textContent='Thanks! Your comment is shown for this session, but could not be saved.';}
    showVisitorComment();restartCommentRotation();e.target.reset();document.getElementById('cmCount').textContent='0 / 500';
  });

  function slidePill(box,sel,pill){
    if(!box||!pill)return null;
    const links=[].slice.call(box.querySelectorAll(sel));
    const cur=()=>box.querySelector(sel+'[aria-current="page"]');
    function moveTo(el){if(!el){pill.style.opacity='0';return}const c=box.getBoundingClientRect(),r=el.getBoundingClientRect();if(!r.width)return;pill.style.opacity='1';pill.style.width=r.width+'px';pill.style.height=r.height+'px';pill.style.transform='translate('+(r.left-c.left-box.clientLeft)+'px,'+(r.top-c.top-box.clientTop)+'px)'}
    const rest=()=>moveTo(cur());
    const snap=()=>{pill.style.transition='none';rest();void pill.offsetWidth;pill.style.transition=''};
    links.forEach(a=>{a.addEventListener('pointerenter',()=>moveTo(a));a.addEventListener('focus',()=>moveTo(a))});
    box.addEventListener('pointerleave',rest);
    box.addEventListener('focusout',e=>{if(!box.contains(e.relatedTarget))rest()});
    window.addEventListener('resize',snap);window.addEventListener('load',snap);
    snap();return snap;
  }
  slidePill(document.querySelector('.nav-links'),'.nav-link',document.querySelector('.nav-pill'));
  const mobBox=document.getElementById('mainNav');
  const snapMob=slidePill(mobBox,'a:not(.m-cta)',mobBox.querySelector('.m-pill'));
  menuToggle.addEventListener('click',()=>requestAnimationFrame(()=>snapMob&&snapMob()));
  const hdr=document.querySelector('.site-header');const onScrollHdr=()=>hdr.classList.toggle('is-scrolled',window.scrollY>8);window.addEventListener('scroll',onScrollHdr,{passive:true});onScrollHdr();
  const closeNav=()=>{nav.classList.remove('open');menuToggle.setAttribute('aria-expanded','false');menuToggle.classList.remove('menu-open')};
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&nav.classList.contains('open')){closeNav();menuToggle.focus()}});
  document.addEventListener('click',e=>{if(nav.classList.contains('open')&&!nav.contains(e.target)&&!menuToggle.contains(e.target))closeNav()});
  window.matchMedia('(min-width:901px)').addEventListener('change',e=>{if(e.matches)closeNav()});
  document.querySelectorAll('.work-card').forEach(card=>card.addEventListener('click',e=>{if(e.target.closest('.project-detail-trigger'))return;const t=card.querySelector('.project-detail-trigger');if(t)t.click()}));
  const commentToggle=document.getElementById('commentToggle');
  commentToggle.addEventListener('click',()=>{commentPaused=!commentPaused;commentToggle.textContent=commentPaused?'Play':'Pause';commentToggle.setAttribute('aria-pressed',String(commentPaused));commentToggle.closest('.feedback-display-card').classList.toggle('paused',commentPaused)});

  // Sticky stack: earlier cards shrink slightly as the next one slides over them
  (function(){const cs=[].slice.call(document.querySelectorAll('.stack-card'));if(!cs.length||reduceMotion)return;let t=false;
  function run(){t=false;cs.forEach((c,i)=>{const n=cs[i+1];if(!n){c.style.transform='';return}const h=c.offsetHeight,top=parseFloat(getComputedStyle(c).top)||0,gap=n.getBoundingClientRect().top-top;const p=Math.min(1,Math.max(0,1-gap/h));c.style.transform='scale('+(1-p*.06).toFixed(4)+')'})}
  window.addEventListener('scroll',()=>{if(!t){t=true;requestAnimationFrame(run)}},{passive:true});window.addEventListener('resize',run);run()})();

  // Point detail cards: slide in from a different direction for each stack card
  (function(){const D=[[["Clear offer above the fold", "This is the first screen a visitor sees, before any scrolling. It states in one or two lines what you sell, who it is for and what to do next.", "Most visitors decide within seconds whether to stay. A clear offer and one obvious button stop them leaving to look for a competitor."], ["Easy navigation on any device", "A simple menu, readable text and large tap targets that work the same on phones, tablets, laptops and desktops.", "Many visitors browse on their phones. If they cannot find a page quickly, they leave without buying or calling."], ["Real proof and trust signals", "Genuine reviews, client names, real project examples, contact details and clear policies placed where visitors make decisions.", "People buy from businesses they trust. Honest proof lowers doubt and makes the next step feel safe."]], [["Quick load times", "Pages that open fast through light code, optimised images and clean hosting setup, without heavy plugins or page builders.", "Slow pages lose visitors and rank lower on search. Speed is the cheapest way to improve both sales and visibility."], ["Search-friendly structure (SEO)", "Proper headings, page titles, descriptions, clean URLs and structured data so search engines understand each page.", "Customers who search for your service can only find you if search engines can read and rank your site."], ["Simple checkout and contact paths", "Short forms, visible buttons and few steps between interest and action, whether that is an order, a call or a message.", "Every extra step loses people. A short path turns more visitors into orders and enquiries."]], [["Conversion-focused layouts", "Page layouts planned around one goal per page, with calls to action placed where visitors are ready to act.", "A good-looking site that does not guide visitors does not earn money. Layout decides how many visitors take action."], ["Easy content editing in WordPress", "You can update text, products and images yourself through a familiar dashboard, with no developer needed for small changes.", "You stay in control of your site, save time and avoid paying for every small edit."], ["A foundation for future growth", "A clean, organised build so new pages, products and features can be added later without rebuilding from scratch.", "Your business will change. A solid foundation saves money when you grow."]], [["Plan, design, build, launch", "A clear four-stage process: understand your goals, plan the structure, design and develop, then review and launch.", "You always know what happens next, which keeps the project on track and avoids surprises."], ["Testing across phones, tablets and desktops", "Before handover, key pages, forms and menus are checked on different screen sizes and common browsers.", "A site that breaks on one device loses real customers. Testing catches problems before your visitors do."], ["Maintenance and support options", "Ongoing updates, backups, security checks and help when something needs fixing after launch.", "Websites need care. Regular maintenance keeps the site safe, fast and working as your business depends on it."]]],K=["What your customer needs", "What they find on your website", "What your business gains", "How it is delivered"],V=[["70px", "0px"], ["-70px", "0px"], ["0px", "-60px"], ["0px", "60px"]];const m=document.getElementById('pointModal'),pn=document.getElementById('pmPanel'),bd=document.getElementById('pmBody');let c=0,p=0,prev=null;
  function slide(x,y){pn.style.setProperty('--dx',x);pn.style.setProperty('--dy',y);bd.style.setProperty('--dx',x);bd.style.setProperty('--dy',y)}
  function fill(x,y,anim){const d=D[c][p];pn.className='pm-panel pm-'+(c+1);document.getElementById('pmKicker').textContent=K[c];document.getElementById('pmTitle').textContent=d[0];document.getElementById('pmDesc').textContent=d[1];document.getElementById('pmWhy').textContent=d[2];document.getElementById('pmCount').textContent=(p+1)+' of '+D[c].length;if(anim){slide(x,y);bd.style.animation='none';void bd.offsetWidth;bd.style.animation=''}}
  function open(ci,pi,t){c=ci;p=pi;prev=t;fill(0,0,false);slide(V[c][0],V[c][1]);pn.style.animation='none';void pn.offsetWidth;pn.style.animation='';m.classList.add('is-open');m.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';document.getElementById('pmClose').focus()}
  function close(){m.classList.remove('is-open');m.setAttribute('aria-hidden','true');document.body.style.overflow='';if(prev)prev.focus()}
  function step(n){const L=D[c].length;p=(p+n+L)%L;fill(n>0?'70px':'-70px','0px',true)}
  document.querySelectorAll('.sc-point').forEach(b=>b.addEventListener('click',()=>open(+b.dataset.card,+b.dataset.point,b)));
  document.getElementById('pmClose').addEventListener('click',close);document.getElementById('pmPrev').addEventListener('click',()=>step(-1));document.getElementById('pmNext').addEventListener('click',()=>step(1));
  m.addEventListener('click',e=>{if(e.target===m)close()});
  document.addEventListener('keydown',e=>{if(!m.classList.contains('is-open'))return;if(e.key==='Escape')close();else if(e.key==='ArrowRight')step(1);else if(e.key==='ArrowLeft')step(-1);else if(e.key==='Tab'){const f=[].slice.call(m.querySelectorAll('button')),a=document.activeElement;if(e.shiftKey&&a===f[0]){e.preventDefault();f[f.length-1].focus()}else if(!e.shiftKey&&a===f[f.length-1]){e.preventDefault();f[0].focus()}}});})();

  // Pinned stat deck: cards stack one after another while scrolling, numbers count up as each lands
  (function(){const tr=document.getElementById('statTrack');if(!tr)return;if(reduceMotion){tr.classList.add('static');return}
  const cs=[].slice.call(tr.querySelectorAll('.stat-big')),ds=[].slice.call(tr.querySelectorAll('.stat-dots span'));
  cs.forEach(c=>{const n=c.querySelector('.stat-num');n.textContent='0'+(n.dataset.suffix||'')});let t=false;
  function run(){t=false;const r=tr.getBoundingClientRect(),span=tr.offsetHeight-window.innerHeight*.8,pr=(window.innerHeight*.35-r.top)/span;const idx=r.top>window.innerHeight*.5?-1:Math.min(3,Math.max(0,Math.floor(pr*4)));
  cs.forEach((c,i)=>{c.classList.toggle('on',i<=idx);c.classList.toggle('back',i<idx);if(i<=idx&&!c.dataset.done){c.dataset.done='1';animateCounter(c.querySelector('.stat-num'))}});ds.forEach((d,i)=>d.classList.toggle('on',i===idx))}
  window.addEventListener('scroll',()=>{if(!t){t=true;requestAnimationFrame(run)}},{passive:true});window.addEventListener('resize',run);run()})();

  // Process steps complete as you scroll
  (function(){const g=document.querySelector('.process-grid');if(!g)return;const st=[].slice.call(g.querySelectorAll('.process-step')),fin=document.getElementById('processFinish');
  if(reduceMotion){st.forEach(x=>{x.style.setProperty('--p',1);x.classList.add('started','done')});if(fin)fin.classList.add('on');return}
  let t=false;function run(){t=false;const vh=window.innerHeight,tp=st.map(x=>x.getBoundingClientRect().top);
  st.forEach((x,i)=>{let row=0;for(let k=0;k<i;k++)if(Math.abs(tp[k]-tp[i])<12)row++;const p=Math.min(1,Math.max(0,(vh*.85-tp[i])/(vh*.16)-row*.7));x.style.setProperty('--p',p.toFixed(3));x.classList.toggle('started',p>0);x.classList.toggle('done',p>=1)});
  if(fin)fin.classList.toggle('on',st.every(x=>x.classList.contains('done')))}
  window.addEventListener('scroll',()=>{if(!t){t=true;requestAnimationFrame(run)}},{passive:true});window.addEventListener('resize',run);run()})();
  document.getElementById('visitorComment').addEventListener('input',e=>{document.getElementById('cmCount').textContent=e.target.value.length+' / 500'});

  // Showcase: details modal (website on top, description below)
  (function(){const D=[{"cat": "Fitness & Gym", "title": "Fitness Center Website", "intro": "A bold, high-energy design for a gym or fitness club. A dark hero with a strong headline and a class-schedule button leads into a BMI calculator, trainer profiles, a class timetable and membership pricing.", "facts": [["Industry", "Fitness & gyms"], ["Style", "Dark, bold, high contrast"], ["Main action", "View class schedule"], ["Preview type", "Theme design preview"]], "secs": ["Hero with class schedule button", "BMI calculator", "About and experience", "Easy-steps process", "Classes and timetable", "Trainer profiles", "Membership pricing", "Testimonials and news", "Contact details"], "alt": "Fitness center website design preview"}, {"cat": "Law Firm", "title": "Law Firm Website", "intro": "A serious, trustworthy design for law practices and legal professionals. Deep navy and gold create authority, with a consultation button, clear practice-area cards and a profile of the lead attorney.", "facts": [["Industry", "Legal services"], ["Style", "Dark navy with gold accents"], ["Main action", "Book a consultation"], ["Preview type", "Template design preview"]], "secs": ["Hero with consultation button", "Firm introduction", "Attorney profile with key figures", "Practice-area cards", "Phone and email in the header"], "alt": "Law firm website design preview"}, {"cat": "Home Services", "title": "Residential Painting Website", "intro": "A bright, friendly design for painters and other home-service businesses. A large hero with a free-estimate button leads into service cards for About, Residential, Gallery and Contact, followed by a project showcase.", "facts": [["Industry", "Home services"], ["Style", "Bright, modern, family-friendly"], ["Main action", "Get a free estimate"], ["Preview type", "Concept design preview"]], "secs": ["Hero with free-estimate button", "Service cards", "Project showcase", "Gallery", "Contact"], "alt": "Residential painting website design preview"}],m=document.getElementById('siteModal');if(!m)return;let prev=null;
  function open(i,t){const d=D[i],img=document.querySelectorAll('.sw-card img')[i];prev=t;document.getElementById('smImg').src=img.src;document.getElementById('smImg').alt=d.alt;document.getElementById('smCat').textContent=d.cat;document.getElementById('smTitle').textContent=d.title;document.getElementById('smIntro').textContent=d.intro;
  document.getElementById('smFacts').replaceChildren(...d.facts.map(f=>{const x=document.createElement('div'),a=document.createElement('small'),b=document.createElement('strong');a.textContent=f[0];b.textContent=f[1];x.append(a,b);return x}));
  document.getElementById('smSecs').replaceChildren(...d.secs.map(t=>{const l=document.createElement('li');l.textContent=t;return l}));
  document.getElementById('smView').scrollTop=0;m.querySelector('.sm-panel').scrollTop=0;m.classList.add('is-open');m.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';document.getElementById('smClose').focus()}
  function close(){m.classList.remove('is-open');m.setAttribute('aria-hidden','true');document.body.style.overflow='';if(prev)prev.focus()}
  document.querySelectorAll('.sw-btn').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();open(+b.dataset.sw,b)}));
  document.querySelectorAll('.sw-card').forEach((c,i)=>c.addEventListener('click',e=>{if(!e.target.closest('.sw-btn'))open(i,c.querySelector('.sw-btn'))}));
  document.getElementById('smClose').addEventListener('click',close);m.addEventListener('click',e=>{if(e.target===m)close()});
  document.addEventListener('keydown',e=>{if(!m.classList.contains('is-open'))return;if(e.key==='Escape')close();else if(e.key==='Tab'){const f=[].slice.call(m.querySelectorAll('button,a[href],[tabindex="0"]')),a=document.activeElement;if(e.shiftKey&&a===f[0]){e.preventDefault();f[f.length-1].focus()}else if(!e.shiftKey&&a===f[f.length-1]){e.preventDefault();f[0].focus()}}})})();
  document.getElementById('year').textContent=new Date().getFullYear();
  const quotesDefault=[
    {text:'This space is reserved for an authentic client testimonial about the collaboration, communication, and final website experience.',name:'Client testimonial placeholder',role:'Replace with approved name and role'},
    {text:'Add a verified client quote here once permission has been received. Keep the feedback specific, honest, and focused on the work delivered.',name:'Approved client name',role:'Client role · Company name'},
    {text:'Use this area to highlight a real project outcome, such as a smoother content workflow or a more usable online store.',name:'Approved client name',role:'Client role · Company name'}
  ];
  const SBq=window.SBPM||{},quotes=(SBq.quotes&&SBq.quotes.length)?SBq.quotes:quotesDefault;
  let quoteIndex=0;
  const quoteAuthor=document.querySelector('.quote-author');
  function setQuoteAvatar(q){if(!quoteAuthor)return;let im=quoteAuthor.querySelector('.quote-avatar');if(q.img){if(!im){im=document.createElement('img');im.className='quote-avatar';im.width=48;im.height=48;im.decoding='async';im.alt='';quoteAuthor.insertBefore(im,quoteAuthor.firstChild)}im.src=q.img}else if(im){im.remove()}}
  if(SBq.quotes&&SBq.quotes.length){const dsc=document.querySelector('.testimonial-disclaimer');if(dsc)dsc.style.display='none'}
  function showQuote(){const q=quotes[quoteIndex];document.getElementById('quoteText').textContent=q.text;document.getElementById('quoteName').textContent=q.name;document.getElementById('quoteRole').textContent=q.role;setQuoteAvatar(q)}
  showQuote();
  document.getElementById('quotePrev').addEventListener('click',()=>{quoteIndex=(quoteIndex-1+quotes.length)%quotes.length;showQuote()});
  document.getElementById('quoteNext').addEventListener('click',()=>{quoteIndex=(quoteIndex+1)%quotes.length;showQuote()});

  // Audit patch: live character count and pause the rotating comments on hover/focus.
  const auditCommentField=document.getElementById('visitorComment');
  const auditCount=document.getElementById('cmCount');
  if(auditCommentField&&auditCount){
    const updateAuditCount=()=>{auditCount.textContent=auditCommentField.value.length+' / 500';};
    auditCommentField.addEventListener('input',updateAuditCount);updateAuditCount();
  }
  if(commentCard){
    commentCard.addEventListener('mouseenter',()=>{commentPaused=true;});
    commentCard.addEventListener('mouseleave',()=>{commentPaused=false;});
    commentCard.addEventListener('focusin',()=>{commentPaused=true;});
    commentCard.addEventListener('focusout',()=>{commentPaused=false;});
    commentCard.setAttribute('aria-live','polite');
  }
})();
