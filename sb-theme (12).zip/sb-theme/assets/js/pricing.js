/* Back to Top (separate script so it always runs) */
(function(){
  var topBtn=document.getElementById('backToTop');
  if(!topBtn)return;
  function toggleTop(){
    var y=window.pageYOffset||document.documentElement.scrollTop||document.body.scrollTop||0;
    topBtn.classList.toggle('show',y>300);
  }
  window.addEventListener('scroll',toggleTop,{passive:true});
  window.addEventListener('load',toggleTop);
  toggleTop();
  topBtn.addEventListener('click',function(){
    try{window.scrollTo({top:0,behavior:'smooth'});}catch(e){window.scrollTo(0,0);}
  });
})();

(function(){
  const menuToggle=document.getElementById('menuToggle');
  const nav=document.getElementById('mainNav');
  menuToggle.addEventListener('click',function(){
    const open=nav.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded',String(open));
    menuToggle.classList.toggle('menu-open',open);
  });
  nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');menuToggle.setAttribute('aria-expanded','false');menuToggle.classList.remove('menu-open')}));
  const bar=document.getElementById('progressBar');
  function updateProgress(){
    const max=document.documentElement.scrollHeight-window.innerHeight;
    const value=max>0?(window.scrollY/max)*100:0;
    bar.style.width=Math.min(100,Math.max(0,value))+'%';
  }
  window.addEventListener('scroll',updateProgress,{passive:true});window.addEventListener('resize',updateProgress);updateProgress();
  const animatedCounters = new WeakSet();
  const reduceMotion=window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  function animateCounter(el){
    if(animatedCounters.has(el)) return;
    animatedCounters.add(el);
    if(reduceMotion){el.textContent=Number(el.dataset.count||0).toLocaleString("en-US")+(el.dataset.suffix||"");return;}
    const target=Number(el.dataset.count||0), suffix=el.dataset.suffix||'';
    const duration=1500, start=performance.now();
    function tick(now){
      const p=Math.min(1,(now-start)/duration);
      const eased=1-Math.pow(1-p,3);
      el.textContent=Math.round(target*eased).toLocaleString('en-US')+suffix;
      if(p<1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }
  const counterObserver = new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){animateCounter(entry.target);counterObserver.unobserve(entry.target)}}),{threshold:.25});
  document.querySelectorAll('.count-up').forEach(el=>counterObserver.observe(el));
  document.querySelectorAll('.reveal').forEach(function(el){var i=0,s=el;while((s=s.previousElementSibling)){if(s.classList.contains('reveal'))i++}el.style.setProperty('--rd',i%4)});
  const revealObserver=new IntersectionObserver(es=>es.forEach(e=>{
    if(e.isIntersecting){e.target.classList.add('is-visible');e.target.querySelectorAll('.count-up').forEach(animateCounter)}
    else if(e.boundingClientRect.top>0){e.target.classList.remove('is-visible')}
  }),{threshold:.12,rootMargin:'0px 0px -5% 0px'});
  document.querySelectorAll('.reveal').forEach(el=>revealObserver.observe(el));
  const yr=document.getElementById('year');if(yr)yr.textContent=new Date().getFullYear();
  function slidePill(box,sel,pill){
    if(!box||!pill)return null;
    const links=[].slice.call(box.querySelectorAll(sel));
    const cur=()=>box.querySelector(sel+'[aria-current="page"]');
    function moveTo(el){if(!el){pill.style.opacity='0';return}const c=box.getBoundingClientRect(),r=el.getBoundingClientRect();if(!r.width)return;pill.style.opacity='1';pill.style.width=r.width+'px';pill.style.height=r.height+'px';pill.style.transform='translate('+(r.left-c.left-box.clientLeft)+'px,'+(r.top-c.top-box.clientTop)+'px)'}
    const rest=()=>moveTo(cur());
    const snap=()=>{pill.style.transition='none';rest();void pill.offsetWidth;pill.style.transition=''};
    links.forEach(a=>{a.addEventListener('pointerenter',()=>moveTo(a));a.addEventListener('focus',()=>moveTo(a))});
    box.addEventListener('pointerleave',rest);
    box.addEventListener('focusout',e=>{if(!box.contains(e.relatedTarget))rest()});
    window.addEventListener('resize',snap);window.addEventListener('load',snap);
    snap();return snap;
  }
  slidePill(document.querySelector('.nav-links'),'.nav-link',document.querySelector('.nav-pill'));
  const mobBox=document.getElementById('mainNav');
  const snapMob=slidePill(mobBox,'a:not(.m-cta)',mobBox.querySelector('.m-pill'));
  menuToggle.addEventListener('click',()=>requestAnimationFrame(()=>snapMob&&snapMob()));
  const hdr=document.querySelector('.site-header');const onScrollHdr=()=>hdr.classList.toggle('is-scrolled',window.scrollY>8);window.addEventListener('scroll',onScrollHdr,{passive:true});onScrollHdr();
  const closeNav=()=>{nav.classList.remove('open');menuToggle.setAttribute('aria-expanded','false');menuToggle.classList.remove('menu-open')};
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&nav.classList.contains('open')){closeNav();menuToggle.focus()}});
  document.addEventListener('click',e=>{if(nav.classList.contains('open')&&!nav.contains(e.target)&&!menuToggle.contains(e.target))closeNav()});
  window.matchMedia('(min-width:901px)').addEventListener('change',e=>{if(e.matches)closeNav()});

(function(){
const money=n=>'$'+n.toLocaleString('en-US');
function animateNum(el){const v=+el.dataset.v;if(reduceMotion){el.textContent=money(v);return}const t0=performance.now(),D=900;(function f(t){const k=Math.min((t-t0)/D,1),e=1-Math.pow(1-k,3);el.textContent=money(Math.round(v*e));if(k<1)requestAnimationFrame(f)})(t0)}
const po=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)animateNum(e.target)}),{threshold:.7});
document.querySelectorAll('.pr-amt').forEach(el=>po.observe(el));
let pk=document.querySelector('.pr-pk[aria-pressed="true"]'),red=false,seo=false,pages=0,shown=0,raf;
const tot=document.getElementById('prTotal'),lines=document.getElementById('prLines'),cta=document.getElementById('prCta'),out=document.getElementById('prPages');
function calc(){return +pk.dataset.p+(red?199:0)+pages*60+(seo?120:0)}
function render(){const t=calc();
 const L=[[pk.firstChild.textContent+' package',+pk.dataset.p]];if(red)L.push(['Website Redesign',199]);if(pages)L.push([pages+' extra page'+(pages>1?'s':''),pages*60]);if(seo)L.push(['Speed & SEO Basics',120]);
 lines.replaceChildren(...L.map(r=>{const li=document.createElement('li'),a=document.createElement('span'),b=document.createElement('b');a.textContent=r[0];b.textContent=money(r[1]);li.append(a,b);return li}));
 out.textContent=pages;
 cancelAnimationFrame(raf);const from=shown,t0=performance.now();if(reduceMotion){shown=t;tot.textContent=money(t)}else(function f(n){const k=Math.min((n-t0)/450,1),e=1-Math.pow(1-k,3);shown=Math.round(from+(t-from)*e);tot.textContent=money(shown);if(k<1)raf=requestAnimationFrame(f)})(t0);
 cta.href='contact.html?package='+pk.dataset.pk+'&estimate='+t+(red?'&redesign=1':'')+(pages?'&extra_pages='+pages:'')+(seo?'&seo=1':'')}
document.querySelectorAll('.pr-pk').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.pr-pk').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));pk=b;render()}));
document.getElementById('prRed').addEventListener('click',e=>{red=!red;e.currentTarget.setAttribute('aria-pressed',String(red));render()});
document.getElementById('prSeo').addEventListener('click',e=>{seo=!seo;e.currentTarget.setAttribute('aria-pressed',String(seo));render()});
document.getElementById('prPlus').addEventListener('click',()=>{if(pages<10){pages++;render()}});
document.getElementById('prMinus').addEventListener('click',()=>{if(pages>0){pages--;render()}});
shown=599;render();
})();
})();
