/* Back to Top (separate script so it always runs) */
(function(){
  var topBtn=document.getElementById('backToTop');
  if(!topBtn)return;
  function toggleTop(){
    var y=window.pageYOffset||document.documentElement.scrollTop||document.body.scrollTop||0;
    topBtn.classList.toggle('show',y>300);
  }
  window.addEventListener('scroll',toggleTop,{passive:true});
  window.addEventListener('load',toggleTop);
  toggleTop();
  topBtn.addEventListener('click',function(){
    try{window.scrollTo({top:0,behavior:'smooth'});}catch(e){window.scrollTo(0,0);}
  });
})();

(function(){
  const menuToggle=document.getElementById('menuToggle');
  const nav=document.getElementById('mainNav');
  menuToggle.addEventListener('click',function(){
    const open=nav.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded',String(open));
    menuToggle.classList.toggle('menu-open',open);
  });
  nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');menuToggle.setAttribute('aria-expanded','false');menuToggle.classList.remove('menu-open')}));
  const bar=document.getElementById('progressBar');
  function updateProgress(){
    const max=document.documentElement.scrollHeight-window.innerHeight;
    const value=max>0?(window.scrollY/max)*100:0;
    bar.style.width=Math.min(100,Math.max(0,value))+'%';
  }
  window.addEventListener('scroll',updateProgress,{passive:true});window.addEventListener('resize',updateProgress);updateProgress();
  const animatedCounters = new WeakSet();
  const reduceMotion=window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  function animateCounter(el){
    if(animatedCounters.has(el)) return;
    animatedCounters.add(el);
    if(reduceMotion){el.textContent=Number(el.dataset.count||0).toLocaleString("en-US")+(el.dataset.suffix||"");return;}
    const target=Number(el.dataset.count||0), suffix=el.dataset.suffix||'';
    const duration=1500, start=performance.now();
    function tick(now){
      const p=Math.min(1,(now-start)/duration);
      const eased=1-Math.pow(1-p,3);
      el.textContent=Math.round(target*eased).toLocaleString('en-US')+suffix;
      if(p<1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }
  const counterObserver = new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){animateCounter(entry.target);counterObserver.unobserve(entry.target)}}),{threshold:.25});
  document.querySelectorAll('.count-up').forEach(el=>counterObserver.observe(el));
  document.querySelectorAll('.reveal').forEach(function(el){var i=0,s=el;while((s=s.previousElementSibling)){if(s.classList.contains('reveal'))i++}el.style.setProperty('--rd',i%4)});
  const revealObserver=new IntersectionObserver(es=>es.forEach(e=>{
    if(e.isIntersecting){e.target.classList.add('is-visible');e.target.querySelectorAll('.count-up').forEach(animateCounter)}
    else if(e.boundingClientRect.top>0){e.target.classList.remove('is-visible')}
  }),{threshold:.12,rootMargin:'0px 0px -5% 0px'});
  document.querySelectorAll('.reveal').forEach(el=>revealObserver.observe(el));
  const yr=document.getElementById('year');if(yr)yr.textContent=new Date().getFullYear();
  function slidePill(box,sel,pill){
    if(!box||!pill)return null;
    const links=[].slice.call(box.querySelectorAll(sel));
    const cur=()=>box.querySelector(sel+'[aria-current="page"]');
    function moveTo(el){if(!el){pill.style.opacity='0';return}const c=box.getBoundingClientRect(),r=el.getBoundingClientRect();if(!r.width)return;pill.style.opacity='1';pill.style.width=r.width+'px';pill.style.height=r.height+'px';pill.style.transform='translate('+(r.left-c.left-box.clientLeft)+'px,'+(r.top-c.top-box.clientTop)+'px)'}
    const rest=()=>moveTo(cur());
    const snap=()=>{pill.style.transition='none';rest();void pill.offsetWidth;pill.style.transition=''};
    links.forEach(a=>{a.addEventListener('pointerenter',()=>moveTo(a));a.addEventListener('focus',()=>moveTo(a))});
    box.addEventListener('pointerleave',rest);
    box.addEventListener('focusout',e=>{if(!box.contains(e.relatedTarget))rest()});
    window.addEventListener('resize',snap);window.addEventListener('load',snap);
    snap();return snap;
  }
  slidePill(document.querySelector('.nav-links'),'.nav-link',document.querySelector('.nav-pill'));
  const mobBox=document.getElementById('mainNav');
  const snapMob=slidePill(mobBox,'a:not(.m-cta)',mobBox.querySelector('.m-pill'));
  menuToggle.addEventListener('click',()=>requestAnimationFrame(()=>snapMob&&snapMob()));
  const hdr=document.querySelector('.site-header');const onScrollHdr=()=>hdr.classList.toggle('is-scrolled',window.scrollY>8);window.addEventListener('scroll',onScrollHdr,{passive:true});onScrollHdr();
  const closeNav=()=>{nav.classList.remove('open');menuToggle.setAttribute('aria-expanded','false');menuToggle.classList.remove('menu-open')};
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&nav.classList.contains('open')){closeNav();menuToggle.focus()}});
  document.addEventListener('click',e=>{if(nav.classList.contains('open')&&!nav.contains(e.target)&&!menuToggle.contains(e.target))closeNav()});
  window.matchMedia('(min-width:901px)').addEventListener('change',e=>{if(e.matches)closeNav()});
  (function(){const tr=document.getElementById('statTrack');if(!tr)return;if(reduceMotion){tr.classList.add('static');return}
  const cs=[].slice.call(tr.querySelectorAll('.stat-big')),ds=[].slice.call(tr.querySelectorAll('.stat-dots span'));
  cs.forEach(c=>{const n=c.querySelector('.stat-num');n.textContent='0'+(n.dataset.suffix||'')});let t=false;
  function run(){t=false;const r=tr.getBoundingClientRect(),span=tr.offsetHeight-window.innerHeight*.8,pr=(window.innerHeight*.35-r.top)/span;const idx=r.top>window.innerHeight*.5?-1:Math.min(3,Math.max(0,Math.floor(pr*4)));
  cs.forEach((c,i)=>{c.classList.toggle('on',i<=idx);c.classList.toggle('back',i<idx);if(i<=idx&&!c.dataset.done){c.dataset.done='1';animateCounter(c.querySelector('.stat-num'))}});ds.forEach((d,i)=>d.classList.toggle('on',i===idx))}
  window.addEventListener('scroll',()=>{if(!t){t=true;requestAnimationFrame(run)}},{passive:true});window.addEventListener('resize',run);run()})();
  (function(){const g=document.querySelector('.process-grid');if(!g)return;const st=[].slice.call(g.querySelectorAll('.process-step')),fin=document.getElementById('processFinish');
  if(reduceMotion){st.forEach(x=>{x.style.setProperty('--p',1);x.classList.add('started','done')});if(fin)fin.classList.add('on');return}
  let t=false;function run(){t=false;const vh=window.innerHeight,tp=st.map(x=>x.getBoundingClientRect().top);
  st.forEach((x,i)=>{let row=0;for(let k=0;k<i;k++)if(Math.abs(tp[k]-tp[i])<12)row++;const p=Math.min(1,Math.max(0,(vh*.85-tp[i])/(vh*.16)-row*.7));x.style.setProperty('--p',p.toFixed(3));x.classList.toggle('started',p>0);x.classList.toggle('done',p>=1)});
  if(fin)fin.classList.toggle('on',st.every(x=>x.classList.contains('done')))}
  window.addEventListener('scroll',()=>{if(!t){t=true;requestAnimationFrame(run)}},{passive:true});window.addEventListener('resize',run);run()})();
  (function(){const D=[{"cat": "Fitness & Gym", "title": "Fitness Center Website", "intro": "A bold, high-energy design for a gym or fitness club. A dark hero with a strong headline and a class-schedule button leads into a BMI calculator, trainer profiles, a class timetable and membership pricing.", "facts": [["Industry", "Fitness & gyms"], ["Style", "Dark, bold, high contrast"], ["Main action", "View class schedule"], ["Preview type", "Theme design preview"]], "secs": ["Hero with class schedule button", "BMI calculator", "About and experience", "Easy-steps process", "Classes and timetable", "Trainer profiles", "Membership pricing", "Testimonials and news", "Contact details"], "alt": "Fitness center website design preview"}, {"cat": "Law Firm", "title": "Law Firm Website", "intro": "A serious, trustworthy design for law practices and legal professionals. Deep navy and gold create authority, with a consultation button, clear practice-area cards and a profile of the lead attorney.", "facts": [["Industry", "Legal services"], ["Style", "Dark navy with gold accents"], ["Main action", "Book a consultation"], ["Preview type", "Template design preview"]], "secs": ["Hero with consultation button", "Firm introduction", "Attorney profile with key figures", "Practice-area cards", "Phone and email in the header"], "alt": "Law firm website design preview"}, {"cat": "Home Services", "title": "Residential Painting Website", "intro": "A bright, friendly design for painters and other home-service businesses. A large hero with a free-estimate button leads into service cards for About, Residential, Gallery and Contact, followed by a project showcase.", "facts": [["Industry", "Home services"], ["Style", "Bright, modern, family-friendly"], ["Main action", "Get a free estimate"], ["Preview type", "Concept design preview"]], "secs": ["Hero with free-estimate button", "Service cards", "Project showcase", "Gallery", "Contact"], "alt": "Residential painting website design preview"}],m=document.getElementById('siteModal');if(!m)return;let prev=null;
  function open(i,t){const d=D[i],img=document.querySelectorAll('.sw-card img')[i];prev=t;document.getElementById('smImg').src=img.src;document.getElementById('smImg').alt=d.alt;document.getElementById('smCat').textContent=d.cat;document.getElementById('smTitle').textContent=d.title;document.getElementById('smIntro').textContent=d.intro;
  document.getElementById('smFacts').replaceChildren(...d.facts.map(f=>{const x=document.createElement('div'),a=document.createElement('small'),b=document.createElement('strong');a.textContent=f[0];b.textContent=f[1];x.append(a,b);return x}));
  document.getElementById('smSecs').replaceChildren(...d.secs.map(t=>{const l=document.createElement('li');l.textContent=t;return l}));
  document.getElementById('smView').scrollTop=0;m.querySelector('.sm-panel').scrollTop=0;m.classList.add('is-open');m.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';document.getElementById('smClose').focus()}
  function close(){m.classList.remove('is-open');m.setAttribute('aria-hidden','true');document.body.style.overflow='';if(prev)prev.focus()}
  document.querySelectorAll('.sw-btn').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();open(+b.dataset.sw,b)}));
  document.querySelectorAll('.sw-card').forEach((c,i)=>c.addEventListener('click',e=>{if(!e.target.closest('.sw-btn'))open(i,c.querySelector('.sw-btn'))}));
  document.getElementById('smClose').addEventListener('click',close);m.addEventListener('click',e=>{if(e.target===m)close()});
  document.addEventListener('keydown',e=>{if(!m.classList.contains('is-open'))return;if(e.key==='Escape')close();else if(e.key==='Tab'){const f=[].slice.call(m.querySelectorAll('button,a[href],[tabindex="0"]')),a=document.activeElement;if(e.shiftKey&&a===f[0]){e.preventDefault();f[f.length-1].focus()}else if(!e.shiftKey&&a===f[f.length-1]){e.preventDefault();f[0].focus()}}})})();
})();
