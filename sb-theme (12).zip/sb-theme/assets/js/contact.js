/* Back to Top (separate script so it always runs) */
(function(){
  var topBtn=document.getElementById('backToTop');
  if(!topBtn)return;
  function toggleTop(){
    var y=window.pageYOffset||document.documentElement.scrollTop||document.body.scrollTop||0;
    topBtn.classList.toggle('show',y>300);
  }
  window.addEventListener('scroll',toggleTop,{passive:true});
  window.addEventListener('load',toggleTop);
  toggleTop();
  topBtn.addEventListener('click',function(){
    try{window.scrollTo({top:0,behavior:'smooth'});}catch(e){window.scrollTo(0,0);}
  });
})();

(function(){
  const menuToggle=document.getElementById('menuToggle');
  const nav=document.getElementById('mainNav');
  menuToggle.addEventListener('click',function(){
    const open=nav.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded',String(open));
    menuToggle.classList.toggle('menu-open',open);
  });
  nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');menuToggle.setAttribute('aria-expanded','false');menuToggle.classList.remove('menu-open')}));
  const bar=document.getElementById('progressBar');
  function updateProgress(){
    const max=document.documentElement.scrollHeight-window.innerHeight;
    const value=max>0?(window.scrollY/max)*100:0;
    bar.style.width=Math.min(100,Math.max(0,value))+'%';
  }
  window.addEventListener('scroll',updateProgress,{passive:true});window.addEventListener('resize',updateProgress);updateProgress();
  const animatedCounters = new WeakSet();
  const reduceMotion=window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  function animateCounter(el){
    if(animatedCounters.has(el)) return;
    animatedCounters.add(el);
    if(reduceMotion){el.textContent=Number(el.dataset.count||0).toLocaleString("en-US")+(el.dataset.suffix||"");return;}
    const target=Number(el.dataset.count||0), suffix=el.dataset.suffix||'';
    const duration=1500, start=performance.now();
    function tick(now){
      const p=Math.min(1,(now-start)/duration);
      const eased=1-Math.pow(1-p,3);
      el.textContent=Math.round(target*eased).toLocaleString('en-US')+suffix;
      if(p<1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }
  const counterObserver = new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){animateCounter(entry.target);counterObserver.unobserve(entry.target)}}),{threshold:.25});
  document.querySelectorAll('.count-up').forEach(el=>counterObserver.observe(el));
  document.querySelectorAll('.reveal').forEach(function(el){var i=0,s=el;while((s=s.previousElementSibling)){if(s.classList.contains('reveal'))i++}el.style.setProperty('--rd',i%4)});
  const revealObserver=new IntersectionObserver(es=>es.forEach(e=>{
    if(e.isIntersecting){e.target.classList.add('is-visible');e.target.querySelectorAll('.count-up').forEach(animateCounter)}
    else if(e.boundingClientRect.top>0){e.target.classList.remove('is-visible')}
  }),{threshold:.12,rootMargin:'0px 0px -5% 0px'});
  document.querySelectorAll('.reveal').forEach(el=>revealObserver.observe(el));
  const yr=document.getElementById('year');if(yr)yr.textContent=new Date().getFullYear();
  function slidePill(box,sel,pill){
    if(!box||!pill)return null;
    const links=[].slice.call(box.querySelectorAll(sel));
    const cur=()=>box.querySelector(sel+'[aria-current="page"]');
    function moveTo(el){if(!el){pill.style.opacity='0';return}const c=box.getBoundingClientRect(),r=el.getBoundingClientRect();if(!r.width)return;pill.style.opacity='1';pill.style.width=r.width+'px';pill.style.height=r.height+'px';pill.style.transform='translate('+(r.left-c.left-box.clientLeft)+'px,'+(r.top-c.top-box.clientTop)+'px)'}
    const rest=()=>moveTo(cur());
    const snap=()=>{pill.style.transition='none';rest();void pill.offsetWidth;pill.style.transition=''};
    links.forEach(a=>{a.addEventListener('pointerenter',()=>moveTo(a));a.addEventListener('focus',()=>moveTo(a))});
    box.addEventListener('pointerleave',rest);
    box.addEventListener('focusout',e=>{if(!box.contains(e.relatedTarget))rest()});
    window.addEventListener('resize',snap);window.addEventListener('load',snap);
    snap();return snap;
  }
  slidePill(document.querySelector('.nav-links'),'.nav-link',document.querySelector('.nav-pill'));
  const mobBox=document.getElementById('mainNav');
  const snapMob=slidePill(mobBox,'a:not(.m-cta)',mobBox.querySelector('.m-pill'));
  menuToggle.addEventListener('click',()=>requestAnimationFrame(()=>snapMob&&snapMob()));
  const hdr=document.querySelector('.site-header');const onScrollHdr=()=>hdr.classList.toggle('is-scrolled',window.scrollY>8);window.addEventListener('scroll',onScrollHdr,{passive:true});onScrollHdr();
  const closeNav=()=>{nav.classList.remove('open');menuToggle.setAttribute('aria-expanded','false');menuToggle.classList.remove('menu-open')};
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&nav.classList.contains('open')){closeNav();menuToggle.focus()}});
  document.addEventListener('click',e=>{if(nav.classList.contains('open')&&!nav.contains(e.target)&&!menuToggle.contains(e.target))closeNav()});
  window.matchMedia('(min-width:901px)').addEventListener('change',e=>{if(e.matches)closeNav()});

(function(){
/* ===== DELIVERY SETTINGS =====
   1) Best: create a free form at formspree.io (or web3forms.com) and paste its URL below. Inquiries then arrive in your inbox.
   2) Otherwise the visitor's email app opens with the brief pre-written to OWNER_EMAIL. */
const FORM_ENDPOINT='';                 // e.g. 'https://formspree.io/f/xxxxxxxx'
const OWNER_EMAIL='contact@devvitech.com';
const T0=Date.now();
const form=document.getElementById('contactForm');if(!form)return;
const E=form.elements,steps=[].slice.call(form.querySelectorAll('.ct-step')),sts=[].slice.call(document.querySelectorAll('#ctStepper .ct-st')),lines=[].slice.call(document.querySelectorAll('#ctStepper .ct-line i'));
const back=document.getElementById('ctBack'),next=document.getElementById('ctNext'),sub=document.getElementById('ctSubmit'),msg=E.message,cnt=document.getElementById('ctCount'),rev=document.getElementById('ctReview'),pre=document.getElementById('ctPre'),done=document.getElementById('ctDone'),cardTop=document.querySelector('.ct-form-top'),urlF=document.getElementById('ctUrlField'),imp=document.getElementById('ctImprove');
document.getElementById('ctDeliveryNote').textContent=(FORM_ENDPOINT||(window.SBPM&&window.SBPM.contactUrl))?'Your inquiry is sent securely to my inbox. I’ll reply to the email address you provide.':(OWNER_EMAIL?'When you press send, your email app opens with your brief pre-written, ready for you to send to me.':'Demo mode: your brief is saved as a text file on your device.');
let cur=1,brief='',mode='demo';
const rad=n=>{const c=form.querySelector('input[name='+n+']:checked');return c?c.value:''};
const many=n=>[].slice.call(form.querySelectorAll('input[name='+n+']:checked')).map(x=>x.value);
const needUrl=()=>{const s=many('services');return s.indexOf('Website redesign')>-1||s.indexOf('SEO & speed optimization')>-1};
function syncCond(){const n=needUrl();urlF.classList.toggle('ct-need-url',n);document.getElementById('ctUrlLabel').textContent=n?'Your current website URL':'Website or company';document.getElementById('ctUrlOpt').style.display=n?'none':'';E.website.placeholder=n?'https://yourwebsite.com':'yourcompany.com';imp.classList.toggle('on',n)}
function setErr(el,bad){const f=el.closest('.ct-field');if(f)f.classList.toggle('bad',bad);el.setAttribute('aria-invalid',bad?'true':'false')}
function validate(s){let ok=true,first=null;const bad=(el,b)=>{setErr(el,b);if(b){ok=false;if(!first)first=el}};
 if(s===1){const f=form.querySelector('input[name=services]'),b=many('services').length===0;f.closest('.ct-field').classList.toggle('bad',b);if(b){ok=false;first=f}}
 if(s===2){bad(E.name,E.name.value.trim().length<2);bad(E.email,!E.email.value.trim()||!E.email.validity.valid);const w=E.website.value.trim();bad(E.website,(needUrl()&&!w)||(!!w&&!/^(https?:\/\/)?[^\s\/]+\.[^\s]{2,}$/i.test(w)));if(needUrl()&&!w)document.getElementById('contactSite-err').textContent='Please add your current website URL so I can review it.';else document.getElementById('contactSite-err').textContent='Please enter a valid website, like yourcompany.com.'}
 if(s===3){bad(msg,msg.value.trim().length<20);const c=E.consent,w=document.getElementById('ctConsentWrap');w.classList.toggle('bad',!c.checked);if(!c.checked){ok=false;if(!first)first=c}}
 if(!ok&&first)first.focus();return ok}
function data(){const w=E.website.value.trim();return[['Services',many('services').join(', ')||'—'],['Budget',rad('budget')],['Timeline',rad('timeline')],['Name',E.name.value.trim()],['Email',E.email.value.trim()],['Website',w||'—']].concat(needUrl()&&many('improve').length?[['Improve',many('improve').join(', ')]]:[])}
function renderReview(){rev.replaceChildren();data().forEach(r=>{const a=document.createElement('dt'),b=document.createElement('dd');a.textContent=r[0];b.textContent=r[1];rev.append(a,b)})}
function go(n,init){cur=n;steps.forEach((s,i)=>s.classList.toggle('on',i===n-1));sts.forEach((s,i)=>{s.classList.toggle('on',i===n-1);s.classList.toggle('done',i<n-1);s.querySelector('b').textContent=i<n-1?'✓':String(i+1)});lines.forEach((l,i)=>l.style.width=(n-1>i?'100%':'0'));back.hidden=n===1;next.hidden=n===3;sub.hidden=n!==3;if(n===3)renderReview();
 if(init)return;const f=steps[n-1].querySelector('input:not([type=radio]):not([type=checkbox]),textarea');if(f)setTimeout(()=>f.focus({preventScroll:true}),60);
 const t=cardTop.getBoundingClientRect().top;if(t<0||t>innerHeight*.5)cardTop.scrollIntoView({behavior:reduceMotion?'auto':'smooth',block:'start'})}
next.addEventListener('click',()=>{if(validate(cur))go(cur+1)});back.addEventListener('click',()=>go(cur-1));
form.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.tagName==='INPUT'&&e.target.type!=='checkbox'&&cur<3){e.preventDefault();if(validate(cur))go(cur+1)}});
form.addEventListener('input',e=>{if(e.target===msg)cnt.textContent=msg.value.length+' / 1500';const f=e.target.closest('.ct-field');if(f&&f.classList.contains('bad'))validate(cur);if(cur===3)renderReview()});
form.addEventListener('change',e=>{const t=e.target;
 if(t.name==='services'){if(t.checked){const other='Other / not sure yet';if(t.value===other)form.querySelectorAll('input[name=services]').forEach(x=>{if(x!==t)x.checked=false});else{const o=form.querySelector('input[name=services][value="'+other+'"]');if(o)o.checked=false}}syncCond();const f=t.closest('.ct-field');if(f&&many('services').length)f.classList.remove('bad')}
 if(t===E.consent)document.getElementById('ctConsentWrap').classList.remove('bad');if(cur===3)renderReview()});
// prefill from the Pricing page estimate
(function(){const q=new URLSearchParams(location.search),pk=q.get('package');if(!pk)return;
 const map={starter:['New website design','Starter Website'],business:['New website design','Business Website'],'wordpress-pro':['WordPress / Elementor development','WordPress Pro'],pro:['WordPress / Elementor development','WordPress Pro'],ecommerce:['eCommerce / WooCommerce store','eCommerce Store'],store:['eCommerce / WooCommerce store','eCommerce Store']};
 const m=map[pk];if(!m)return;const chk=v=>{const r=form.querySelector('input[name=services][value="'+v+'"]');if(r)r.checked=true};chk(m[0]);
 const est=+q.get('estimate')||0,extra=[];if(q.get('redesign')){extra.push('Website Redesign');chk('Website redesign')}if(q.get('extra_pages'))extra.push(q.get('extra_pages')+' extra page(s)');if(q.get('seo')){extra.push('Speed & SEO Basics');chk('SEO & speed optimization')}
 if(est){const b=est<300?'Under $300':est<=600?'$300–$600':est<=1000?'$600–$1,000':'$1,000+';const bi=[].slice.call(form.querySelectorAll('input[name=budget]')).find(x=>x.value===b);if(bi)bi.checked=true}
 msg.value='I\'m interested in the '+m[1]+' package'+(extra.length?' with '+extra.join(', '):'')+(est?' (demo estimate: $'+est.toLocaleString('en-US')+')':'')+'.\n\nProject goals: ';cnt.textContent=msg.value.length+' / 1500';
 pre.innerHTML='<b>Pre-filled from your pricing estimate:</b> '+m[1]+(extra.length?' + '+extra.join(', '):'')+(est?' · about $'+est.toLocaleString('en-US')+' (demo)':'')+'. Feel free to edit anything.';pre.classList.add('on');syncCond()})();
syncCond();
function mailHref(){let body=brief;const enc=s=>encodeURIComponent(s);let h='mailto:'+OWNER_EMAIL+'?subject='+enc('New project inquiry from '+E.name.value.trim())+'&body='+enc(body);if(h.length>1900){h='mailto:'+OWNER_EMAIL+'?subject='+enc('New project inquiry from '+E.name.value.trim())+'&body='+enc(body.slice(0,1100)+'\n\n[Brief shortened — please paste the full brief here]');}return h}
function download(){const blob=new Blob([brief],{type:'text/plain;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='project-inquiry-brief.txt';document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url)}
function finish(m){mode=m;form.hidden=true;cardTop.hidden=true;done.classList.toggle('mail',m==='mail');const T={sent:['Your inquiry has been sent.','Thank you! I’ve received your project brief and will reply to the email address you provided.'],mail:['One last step: press Send.','Your email app has opened with your brief pre-written. Press Send there to deliver it to me. If nothing opened, use the buttons below.'],demo:['Your brief is ready.','A text copy has been downloaded to your device. Email delivery is not connected yet.']}[m];document.getElementById('ctDoneTitle').textContent=T[0];document.getElementById('ctDoneText').textContent=T[1];done.classList.add('on');done.focus({preventScroll:true});done.scrollIntoView({behavior:reduceMotion?'auto':'smooth',block:'center'})}
form.addEventListener('submit',async e=>{e.preventDefault();for(let s=1;s<=3;s++){if(!validate(s)){if(s!==cur)go(s);return}}
 if(E._gotcha&&E._gotcha.value){finish('sent');return}
 brief=['PROJECT INQUIRY'].concat(data().map(r=>r[0]+': '+r[1]),['','Project details:',msg.value.trim(),'','Consent to be contacted: yes']).join('\n');
 const old=sub.innerHTML;sub.disabled=true;sub.textContent='Sending…';
 let m='demo';
 const SBc=window.SBPM||{},WA_NUM=String(SBc.whatsapp||'').replace(/\D/g,'');let waWin=null;
 if(WA_NUM){try{waWin=window.open('about:blank','_blank')}catch(x){waWin=null}}
 if(SBc.contactUrl){try{const r=await fetch(SBc.contactUrl,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({name:E.name.value.trim(),email:E.email.value.trim(),website:E.website.value.trim(),services:many('services').join(', '),improve:many('improve').join(', '),budget:rad('budget'),timeline:rad('timeline'),message:msg.value.trim(),elapsed:Date.now()-T0})});if(r.ok)m='sent'}catch(x){}}
 if(!SBc.contactUrl&&FORM_ENDPOINT){try{const r=await fetch(FORM_ENDPOINT,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({_subject:'New project inquiry from '+E.name.value.trim(),name:E.name.value.trim(),email:E.email.value.trim(),_replyto:E.email.value.trim(),website:E.website.value.trim(),services:many('services').join(', '),improve:many('improve').join(', '),budget:rad('budget'),timeline:rad('timeline'),message:msg.value.trim()})});if(r.ok)m='sent'}catch(x){}}
 if(m!=='sent'&&OWNER_EMAIL){m='mail';location.href=mailHref()}
 if(m==='demo')download();
 sub.disabled=false;sub.innerHTML=old;finish(m);
 if(WA_NUM){const waUrl='https://wa.me/'+WA_NUM+'?text='+encodeURIComponent(brief.slice(0,1800));if(waWin){try{waWin.location.href=waUrl}catch(x){}}else if(m==='sent'){setTimeout(()=>{location.href=waUrl},1200)}}});
const cp=document.getElementById('ctCopy');cp.addEventListener('click',()=>{(navigator.clipboard?navigator.clipboard.writeText(brief):Promise.reject()).then(()=>{cp.firstChild.textContent='Copied ✓ '}).catch(()=>{cp.firstChild.textContent='Copy not available '})});
document.getElementById('ctDl').addEventListener('click',download);document.getElementById('ctMail').addEventListener('click',()=>{location.href=mailHref()});
document.getElementById('ctNew').addEventListener('click',()=>{form.reset();cnt.textContent='0 / 1500';pre.classList.remove('on');done.classList.remove('on','mail');form.hidden=false;cardTop.hidden=false;form.querySelectorAll('.bad').forEach(x=>x.classList.remove('bad'));cp.firstChild.textContent='Copy brief ';syncCond();go(1)});
go(1,true);
})();
})();
