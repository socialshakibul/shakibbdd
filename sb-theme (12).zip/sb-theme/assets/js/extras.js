/* Small helpers needed because the page now lives in WordPress.
   1) <main> must be focusable for the skip link (blocks cannot store tabindex).
   2) The header is shared by every page, so the active menu link is set from the URL. */
(function(){
  var main=document.getElementById('main');
  if(main&&!main.hasAttribute('tabindex'))main.setAttribute('tabindex','-1');
  var path=location.pathname.replace(/\/+$/,'')||'/';
  var sets=document.querySelectorAll('#desktopNav .nav-link, #mainNav a:not(.m-cta)');
  var matched=false;
  [].forEach.call(sets,function(a){
    var p;try{p=new URL(a.getAttribute('href'),location.origin).pathname.replace(/\/+$/,'')||'/';}catch(e){return;}
    var on=(p===path);
    if(on)matched=true;
    a.classList.toggle('active',on&&a.classList.contains('nav-link'));
    if(on)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');
  });
  if(!matched){[].forEach.call(sets,function(a){a.classList.remove('active');a.removeAttribute('aria-current');});}
})();
