/* Back to Top (separate script so it always runs) */
(function(){
  var topBtn=document.getElementById('backToTop');
  if(!topBtn)return;
  function toggleTop(){
    var y=window.pageYOffset||document.documentElement.scrollTop||document.body.scrollTop||0;
    topBtn.classList.toggle('show',y>300);
  }
  window.addEventListener('scroll',toggleTop,{passive:true});
  window.addEventListener('load',toggleTop);
  toggleTop();
  topBtn.addEventListener('click',function(){
    try{window.scrollTo({top:0,behavior:'smooth'});}catch(e){window.scrollTo(0,0);}
  });
})();

(function(){
  const menuToggle=document.getElementById('menuToggle');
  const nav=document.getElementById('mainNav');
  menuToggle.addEventListener('click',function(){
    const open=nav.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded',String(open));
    menuToggle.classList.toggle('menu-open',open);
  });
  nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');menuToggle.setAttribute('aria-expanded','false');menuToggle.classList.remove('menu-open')}));
  const bar=document.getElementById('progressBar');
  function updateProgress(){
    const max=document.documentElement.scrollHeight-window.innerHeight;
    const value=max>0?(window.scrollY/max)*100:0;
    bar.style.width=Math.min(100,Math.max(0,value))+'%';
  }
  window.addEventListener('scroll',updateProgress,{passive:true});window.addEventListener('resize',updateProgress);updateProgress();
  const animatedCounters = new WeakSet();
  const reduceMotion=window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  function animateCounter(el){
    if(animatedCounters.has(el)) return;
    animatedCounters.add(el);
    if(reduceMotion){el.textContent=Number(el.dataset.count||0).toLocaleString("en-US")+(el.dataset.suffix||"");return;}
    const target=Number(el.dataset.count||0), suffix=el.dataset.suffix||'';
    const duration=1500, start=performance.now();
    function tick(now){
      const p=Math.min(1,(now-start)/duration);
      const eased=1-Math.pow(1-p,3);
      el.textContent=Math.round(target*eased).toLocaleString('en-US')+suffix;
      if(p<1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }
  const counterObserver = new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){animateCounter(entry.target);counterObserver.unobserve(entry.target)}}),{threshold:.25});
  document.querySelectorAll('.count-up').forEach(el=>counterObserver.observe(el));
  document.querySelectorAll('.reveal').forEach(function(el){var i=0,s=el;while((s=s.previousElementSibling)){if(s.classList.contains('reveal'))i++}el.style.setProperty('--rd',i%4)});
  const revealObserver=new IntersectionObserver(es=>es.forEach(e=>{
    if(e.isIntersecting){e.target.classList.add('is-visible');e.target.querySelectorAll('.count-up').forEach(animateCounter)}
    else if(e.boundingClientRect.top>0){e.target.classList.remove('is-visible')}
  }),{threshold:.12,rootMargin:'0px 0px -5% 0px'});
  document.querySelectorAll('.reveal').forEach(el=>revealObserver.observe(el));
  const yr=document.getElementById('year');if(yr)yr.textContent=new Date().getFullYear();
  function slidePill(box,sel,pill){
    if(!box||!pill)return null;
    const links=[].slice.call(box.querySelectorAll(sel));
    const cur=()=>box.querySelector(sel+'[aria-current="page"]');
    function moveTo(el){if(!el){pill.style.opacity='0';return}const c=box.getBoundingClientRect(),r=el.getBoundingClientRect();if(!r.width)return;pill.style.opacity='1';pill.style.width=r.width+'px';pill.style.height=r.height+'px';pill.style.transform='translate('+(r.left-c.left-box.clientLeft)+'px,'+(r.top-c.top-box.clientTop)+'px)'}
    const rest=()=>moveTo(cur());
    const snap=()=>{pill.style.transition='none';rest();void pill.offsetWidth;pill.style.transition=''};
    links.forEach(a=>{a.addEventListener('pointerenter',()=>moveTo(a));a.addEventListener('focus',()=>moveTo(a))});
    box.addEventListener('pointerleave',rest);
    box.addEventListener('focusout',e=>{if(!box.contains(e.relatedTarget))rest()});
    window.addEventListener('resize',snap);window.addEventListener('load',snap);
    snap();return snap;
  }
  slidePill(document.querySelector('.nav-links'),'.nav-link',document.querySelector('.nav-pill'));
  const mobBox=document.getElementById('mainNav');
  const snapMob=slidePill(mobBox,'a:not(.m-cta)',mobBox.querySelector('.m-pill'));
  menuToggle.addEventListener('click',()=>requestAnimationFrame(()=>snapMob&&snapMob()));
  const hdr=document.querySelector('.site-header');const onScrollHdr=()=>hdr.classList.toggle('is-scrolled',window.scrollY>8);window.addEventListener('scroll',onScrollHdr,{passive:true});onScrollHdr();
  const closeNav=()=>{nav.classList.remove('open');menuToggle.setAttribute('aria-expanded','false');menuToggle.classList.remove('menu-open')};
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&nav.classList.contains('open')){closeNav();menuToggle.focus()}});
  document.addEventListener('click',e=>{if(nav.classList.contains('open')&&!nav.contains(e.target)&&!menuToggle.contains(e.target))closeNav()});
  window.matchMedia('(min-width:901px)').addEventListener('change',e=>{if(e.matches)closeNav()});

(function(){
// Accessible category filters.
 const filters=[...document.querySelectorAll('.pj-filter')],cards=[...document.querySelectorAll('.sw-card')],groups=[...document.querySelectorAll('.pj-group')],empty=document.getElementById('projectEmpty');
 filters.forEach(button=>button.addEventListener('click',()=>{const filter=button.dataset.filter;filters.forEach(b=>b.setAttribute('aria-pressed',String(b===button)));let visible=0;cards.forEach(card=>{const show=filter==='all'||card.dataset.category.split(' ').includes(filter);card.hidden=!show;if(show)visible++;});groups.forEach(g=>{g.hidden=!g.querySelector('.sw-card:not([hidden])')});if(empty)empty.style.display=visible?'none':'block';}));
 
const D=(window.SBPM&&window.SBPM.projects&&window.SBPM.projects.length)?window.SBPM.projects:[{"cat": "Fitness & Gym", "title": "Fitness Center Website", "intro": "A bold, high-energy design for a gym or fitness club. A dark hero with a strong headline and a class-schedule button leads into a BMI calculator, trainer profiles, a class timetable and membership pricing.", "facts": [["Industry", "Fitness & gyms"], ["Style", "Dark, bold, high contrast"], ["Main action", "View class schedule"], ["Preview type", "Theme design preview"]], "secs": ["Hero with class schedule button", "BMI calculator", "About and experience", "Easy-steps process", "Classes and timetable", "Trainer profiles", "Membership pricing", "Testimonials and news", "Contact details"], "alt": "Fitness center website design preview"}, {"cat": "Law Firm", "title": "Law Firm Website", "intro": "A serious, trustworthy design for law practices and legal professionals. Deep navy and gold create authority, with a consultation button, clear practice-area cards and a profile of the lead attorney.", "facts": [["Industry", "Legal services"], ["Style", "Dark navy with gold accents"], ["Main action", "Book a consultation"], ["Preview type", "Template design preview"]], "secs": ["Hero with consultation button", "Firm introduction", "Attorney profile with key figures", "Practice-area cards", "Phone and email in the header"], "alt": "Law firm website design preview"}, {"cat": "Home Services", "title": "Residential Painting Website", "intro": "A bright, friendly design for painters and other home-service businesses. A large hero with a free-estimate button leads into service cards for About, Residential, Gallery and Contact, followed by a project showcase.", "facts": [["Industry", "Home services"], ["Style", "Bright, modern, family-friendly"], ["Main action", "Get a free estimate"], ["Preview type", "Concept design preview"]], "secs": ["Hero with free-estimate button", "Service cards", "Project showcase", "Gallery", "Contact"], "alt": "Residential painting website design preview"}, {"cat": "Fitness website · Web design", "title": "Fitness & Gym Website", "intro": "An illustrative website direction for a fitness business that wants to present membership options, training styles, and facilities in a clear and motivating way.", "facts": [["Project type", "Fitness business website concept"], ["Primary goal", "Explain services and membership options"], ["Audience", "Gym members and prospective visitors"], ["Status", "Illustrative concept only"]], "secs": ["Clear hero message with a primary contact or trial CTA", "Membership and pricing information layout", "Classes, trainers, and facilities content sections", "Mobile-friendly navigation and readable page spacing", "Accessible contrast and purposeful interaction states"], "alt": "Fitness & Gym Website design preview"}, {"cat": "eCommerce · Storefront design", "title": "Modern eCommerce Storefront", "intro": "A concept for a small online store that organizes product categories, product details, and shopping actions into a calmer customer journey.", "facts": [["Project type", "Online store concept"], ["Primary goal", "Improve product discovery flow"], ["Audience", "Online shoppers"], ["Status", "Illustrative concept only"]], "secs": ["Category-led product discovery", "Product cards with clear image and information hierarchy", "Product detail layout with key information near the CTA", "Cart and checkout journey planning", "Shipping, returns, and support information areas"], "alt": "Modern eCommerce Storefront design preview"}, {"cat": "Landing page · UI/UX", "title": "Software Product Landing Page", "intro": "A focused landing-page concept for a digital product, built around explaining its purpose, organizing benefits, and helping visitors decide what to do next.", "facts": [["Project type", "SaaS landing page concept"], ["Primary goal", "Clarify product value"], ["Audience", "Potential software users"], ["Status", "Illustrative concept only"]], "secs": ["Value proposition and primary CTA area", "Feature sections grouped by user need", "Product interface preview area", "FAQ and objection-handling structure", "Responsive layouts for smaller screens"], "alt": "Software Product Landing Page design preview"}, {"cat": "WordPress · Education", "title": "Online Course Platform", "intro": "An education website concept for presenting courses, instructor information, learning outcomes, and enrollment steps in a structured way.", "facts": [["Project type", "Education website concept"], ["Primary goal", "Make course information easier to scan"], ["Audience", "Learners and course creators"], ["Status", "Illustrative concept only"]], "secs": ["Course listing and category structure", "Course detail with outcomes and syllabus sections", "Instructor introduction and FAQ area", "Enrollment CTA placement", "WordPress-editable content approach"], "alt": "Online Course Platform design preview"}, {"cat": "Creative portfolio · Web design", "title": "Creative Agency Portfolio", "intro": "A portfolio concept for a creative studio that needs to communicate its point of view, show selected work, and make project inquiries straightforward.", "facts": [["Project type", "Agency portfolio concept"], ["Primary goal", "Present work and encourage inquiries"], ["Audience", "Prospective clients and collaborators"], ["Status", "Illustrative concept only"]], "secs": ["Distinctive hero and concise studio positioning", "Selected work gallery and project details", "Service summary and approach section", "Contact CTA and inquiry pathway", "Subtle motion with reduced-motion support"], "alt": "Creative Agency Portfolio design preview"}, {"cat": "UI/UX · Dashboard", "title": "Analytics Dashboard Interface", "intro": "A dashboard interface concept that groups summary information and common actions into a readable, organized workspace.", "facts": [["Project type", "Dashboard UI concept"], ["Primary goal", "Improve information clarity"], ["Audience", "Product and operations teams"], ["Status", "Illustrative concept only"]], "secs": ["Summary card and key information hierarchy", "Navigation structure for related dashboard areas", "Consistent spacing, labels, and interface states", "Responsive behavior for narrower screens", "Accessibility-minded contrast and focus treatment"], "alt": "Analytics Dashboard Interface design preview"}];
const m=document.getElementById('siteModal'),view=document.getElementById('smView'),img=document.getElementById('smImg'),vars=document.getElementById('smVariants'),panel=m.querySelector('.sm-panel');let prev=null;
const swCards=[].slice.call(document.querySelectorAll('.sw-card'));
function open(i,t){const d=D[i],card=swCards[i];prev=t;const imgs=[].slice.call(card.querySelectorAll('.sw-view img,.sw-extra img'));
 view.querySelectorAll('.pj-ph').forEach(x=>x.remove());
 if(imgs.length){img.hidden=false;img.src=imgs[0].src;img.alt=d.alt}else{img.hidden=true;img.removeAttribute('src');const ph=card.querySelector('.pj-preview');if(ph){const c=ph.cloneNode(true);c.classList.add('pj-ph');view.appendChild(c)}}
 vars.replaceChildren();vars.hidden=imgs.length<2;
 if(imgs.length>1)imgs.forEach((im,k)=>{const b=document.createElement('button');b.type='button';b.textContent='Design '+(k+1);b.setAttribute('aria-pressed',String(k===0));b.addEventListener('click',()=>{img.src=im.src;view.scrollTop=0;[].slice.call(vars.children).forEach(x=>x.setAttribute('aria-pressed',String(x===b)))});vars.appendChild(b)});
 document.getElementById('smCat').textContent=d.cat;document.getElementById('smTitle').textContent=d.title;document.getElementById('smIntro').textContent=d.intro;
 document.getElementById('smFacts').replaceChildren(...d.facts.map(f=>{const x=document.createElement('div'),a=document.createElement('small'),b=document.createElement('strong');a.textContent=f[0];b.textContent=f[1];x.append(a,b);return x}));
 document.getElementById('smSecs').replaceChildren(...d.secs.map(t=>{const l=document.createElement('li');l.textContent=t;return l}));
 view.scrollTop=0;panel.scrollTop=0;m.classList.add('is-open');m.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';document.getElementById('smClose').focus()}
function close(){m.classList.remove('is-open');m.setAttribute('aria-hidden','true');document.body.style.overflow='';if(prev)prev.focus()}
document.querySelectorAll('.sw-btn').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();open(+b.dataset.sw,b)}));
swCards.forEach((c,i)=>c.addEventListener('click',e=>{if(!e.target.closest('.sw-btn'))open(i,c.querySelector('.sw-btn'))}));
document.getElementById('smClose').addEventListener('click',close);m.addEventListener('click',e=>{if(e.target===m)close()});
document.addEventListener('keydown',e=>{if(!m.classList.contains('is-open'))return;if(e.key==='Escape')close();else if(e.key==='Tab'){const f=[].slice.call(m.querySelectorAll('button:not([hidden]),a[href],[tabindex="0"]')).filter(x=>x.offsetParent!==null);if(!f.length)return;const a=f[0],z=f[f.length-1];if(e.shiftKey&&document.activeElement===a){e.preventDefault();z.focus()}else if(!e.shiftKey&&document.activeElement===z){e.preventDefault();a.focus()}}});
})();
})();
