<?php
/**
 * Title: Services page content
 * Slug: sb-theme/services
 * Description: Full Services page (all sections).
 * Inserter: no
 */
?>
<!-- wp:group {"tagName":"main","anchor":"main"} -->
<main id="main" class="wp-block-group">
<!-- wp:group {"tagName":"section","className":"about-hero"} -->
<section class="wp-block-group about-hero">
<!-- wp:group {"className":"container about-hero-grid"} -->
<div class="wp-block-group container about-hero-grid">
<!-- wp:group {"className":"about-hero-copy reveal"} -->
<div class="wp-block-group about-hero-copy reveal">
<!-- wp:html -->
<div class="about-breadcrumb"><a href="/">Home</a> / Services</div>
<!-- /wp:html -->

<!-- wp:html -->
<span class="eyebrow">Services &amp; expertise</span>
<!-- /wp:html -->

<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Thoughtful digital work.<br/><span>Built for real goals.</span></h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>From a clear first design to a polished WordPress build, I help shape websites that are easy to use, responsive across devices, and practical to manage.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"hero-buttons"} -->
<div class="wp-block-group hero-buttons">
<!-- wp:html -->
<a class="btn btn-primary" href="/contact/">Discuss a Project <span class="arrow">↗</span></a>
<!-- /wp:html -->

<!-- wp:html -->
<a class="btn btn-light" href="#services">Explore Services <span class="arrow">↓</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-label="Illustration of a responsive website design" class="about-hero-art reveal"><div class="about-art-label"><span>Digital experience / 01</span><span>Built with purpose</span></div><div aria-hidden="true" class="sv-win"><div class="sv-win-head"><i></i><i></i><i></i></div><div class="sv-line s"></div><div class="sv-line l"></div><div class="sv-line m"></div><div class="sv-mini"><div><strong>01</strong>Clear structure</div><div><strong>02</strong>Responsive layout</div></div></div><div class="about-art-chip one"><strong>Design with intent</strong><small>Clear, useful layouts</small></div><div class="about-art-chip two"><strong>Ready for real users ↗</strong><small>Tested across screens</small></div></div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:html -->
<section aria-label="Services" class="about-marquee"><div aria-hidden="true" class="about-marquee-track"><div class="about-marquee-group"><span>Web Design</span><b>✳</b><span>Web Development</span><b>✳</b><span>WordPress</span><b>✳</b><span>UI/UX Design</span><b>✳</b><span>Website Redesign</span><b>✳</b><span>Responsive Websites</span><b>✳</b><span>SEO &amp; Optimization</span><b>✳</b></div><div class="about-marquee-group"><span>Web Design</span><b>✳</b><span>Web Development</span><b>✳</b><span>WordPress</span><b>✳</b><span>UI/UX Design</span><b>✳</b><span>Website Redesign</span><b>✳</b><span>Responsive Websites</span><b>✳</b><span>SEO &amp; Optimization</span><b>✳</b></div></div></section>
<!-- /wp:html -->

<!-- wp:group {"tagName":"section","anchor":"services","className":"section"} -->
<section id="services" class="wp-block-group section">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow">What I can help with</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Services built around your website goals.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p>Choose the support your project needs, from the first wireframe to ongoing website improvements.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"svc-grid sv-bento"} -->
<div class="wp-block-group svc-grid sv-bento">
<!-- wp:group {"tagName":"article","className":"svc svc-a from-l reveal sbv-d-0"} -->
<article class="wp-block-group svc svc-a from-l reveal sbv-d-0">
<!-- wp:group {"className":"svc-top"} -->
<div class="wp-block-group svc-top">
<!-- wp:html -->
<span class="svc-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><rect height="16" rx="2" width="18" x="3" y="4"></rect><path d="M3 9h18M9 9v11"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="svc-no">01</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"svc-body"} -->
<div class="wp-block-group svc-body">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Web Design</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Modern page layouts and visual systems that make your message clear and help visitors understand what to do next.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<ul class="svc-tags"><li>Layouts</li><li>Visual systems</li><li>Clear messaging</li></ul>
<!-- /wp:html -->

<!-- wp:html -->
<a class="svc-link" href="/contact/">Discuss design <span aria-hidden="true">→</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-hidden="true" class="svc-mock"><div class="m-bar"><i></i><i></i><i></i></div><div class="m-body"><b></b><b></b><b></b><span></span></div></div>
<!-- /wp:html -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"svc svc-b from-r reveal sbv-d-1"} -->
<article class="wp-block-group svc svc-b from-r reveal sbv-d-1">
<!-- wp:group {"className":"svc-top"} -->
<div class="wp-block-group svc-top">
<!-- wp:html -->
<span class="svc-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><path d="M8 8l-4 4 4 4M16 8l4 4-4 4M14 5l-4 14"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="svc-no">02</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"svc-body"} -->
<div class="wp-block-group svc-body">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Web Development</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Well-structured website builds with attention to responsive behavior, maintainable code, and a smooth browsing experience.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<ul class="svc-tags"><li>Clean code</li><li>Responsive</li></ul>
<!-- /wp:html -->

<!-- wp:html -->
<a class="svc-link" href="/contact/">Discuss development <span aria-hidden="true">→</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"svc svc-c from-b reveal sbv-d-2"} -->
<article class="wp-block-group svc svc-c from-b reveal sbv-d-2">
<!-- wp:group {"className":"svc-top"} -->
<div class="wp-block-group svc-top">
<!-- wp:html -->
<span class="svc-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"></circle><path d="M3 12h18M12 3a14 14 0 010 18M12 3a14 14 0 000 18"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="svc-no">03</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"svc-body"} -->
<div class="wp-block-group svc-body">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">WordPress Development</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>WordPress websites and editable page structures designed to make everyday content updates more practical.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<ul class="svc-tags"><li>Editable</li><li>CMS</li></ul>
<!-- /wp:html -->

<!-- wp:html -->
<a class="svc-link" href="/contact/">Discuss WordPress <span aria-hidden="true">→</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"svc svc-d from-b reveal sbv-d-3"} -->
<article class="wp-block-group svc svc-d from-b reveal sbv-d-3">
<!-- wp:group {"className":"svc-top"} -->
<div class="wp-block-group svc-top">
<!-- wp:html -->
<span class="svc-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><path d="M12 3l2.6 5.6 6 .7-4.5 4.1 1.2 6L12 16.3 6.7 19.4l1.2-6L3.4 9.3l6-.7z"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="svc-no">04</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"svc-body"} -->
<div class="wp-block-group svc-body">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">UI/UX Design</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Thoughtful user flows, information hierarchy, and interface details that make pages easier to understand and navigate.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<ul class="svc-tags"><li>User flows</li><li>Hierarchy</li></ul>
<!-- /wp:html -->

<!-- wp:html -->
<a class="svc-link" href="/contact/">Discuss UI/UX <span aria-hidden="true">→</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"svc svc-e from-b reveal sbv-d-4"} -->
<article class="wp-block-group svc svc-e from-b reveal sbv-d-4">
<!-- wp:group {"className":"svc-top"} -->
<div class="wp-block-group svc-top">
<!-- wp:html -->
<span class="svc-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="svc-no">05</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"svc-body"} -->
<div class="wp-block-group svc-body">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Website Redesign</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A fresh approach to outdated layouts, content structure, and visual consistency, while keeping the real needs in view.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<ul class="svc-tags"><li>Refresh</li><li>Consistency</li></ul>
<!-- /wp:html -->

<!-- wp:html -->
<a class="svc-link" href="/contact/">Discuss a redesign <span aria-hidden="true">→</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"svc svc-f from-l reveal sbv-d-5"} -->
<article class="wp-block-group svc svc-f from-l reveal sbv-d-5">
<!-- wp:group {"className":"svc-top"} -->
<div class="wp-block-group svc-top">
<!-- wp:html -->
<span class="svc-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><rect height="11" rx="2" width="14" x="2" y="5"></rect><rect height="10" rx="1.2" width="4.5" x="17.5" y="9"></rect></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="svc-no">06</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"svc-body"} -->
<div class="wp-block-group svc-body">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Responsive Website</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Layouts considered for desktop, tablet, and mobile, with readable type, comfortable spacing, and usable navigation.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<ul class="svc-tags"><li>Mobile-first</li><li>Readable type</li></ul>
<!-- /wp:html -->

<!-- wp:html -->
<a class="svc-link" href="/contact/">Discuss responsiveness <span aria-hidden="true">→</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"svc svc-g from-r reveal sbv-d-6"} -->
<article class="wp-block-group svc svc-g from-r reveal sbv-d-6">
<!-- wp:group {"className":"svc-top"} -->
<div class="wp-block-group svc-top">
<!-- wp:html -->
<span class="svc-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"></circle><path d="M21 21l-4.3-4.3"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="svc-no">07</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"svc-body"} -->
<div class="wp-block-group svc-body">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">SEO & Website Optimization</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Foundational on-page SEO, sensible page structure, image optimization, and performance-minded improvements.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<ul class="svc-tags"><li>On-page SEO</li><li>Performance</li></ul>
<!-- /wp:html -->

<!-- wp:html -->
<a class="svc-link" href="/contact/">Discuss optimization <span aria-hidden="true">→</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"sv-note reveal"} -->
<p class="sv-note reveal">Project scope depends on your goals and existing setup. SEO and optimization work supports best practices; search rankings and performance outcomes are not guaranteed.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","className":"section sbv-s-background-var-ink"} -->
<section class="wp-block-group section sbv-s-background-var-ink">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow sbv-s-color-var-lime">How I work</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2,"className":"sbv-s-color-white"} -->
<h2 class="wp-block-heading sbv-s-color-white">A clear process, from first idea to final checks.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"sbv-s-color-b6c2d4"} -->
<p class="sbv-s-color-b6c2d4">Each stage keeps the project focused, collaborative, and easier to review.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"about-process-grid sv-process"} -->
<div class="wp-block-group about-process-grid sv-process">
<!-- wp:group {"tagName":"article","className":"about-process-card reveal"} -->
<article class="wp-block-group about-process-card reveal">
<!-- wp:html -->
<span class="about-process-number">01 / DISCOVER</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Understand the goal</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Clarify the audience, project needs, content, and the action the website should help people take.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-process-card reveal"} -->
<article class="wp-block-group about-process-card reveal">
<!-- wp:html -->
<span class="about-process-number">02 / PLAN</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Shape the experience</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Organize page structure, key sections, and content hierarchy before moving into detailed design.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-process-card reveal"} -->
<article class="wp-block-group about-process-card reveal">
<!-- wp:html -->
<span class="about-process-number">03 / BUILD</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Design and develop</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Turn the plan into a considered interface and build the required responsive website experience.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-process-card reveal"} -->
<article class="wp-block-group about-process-card reveal">
<!-- wp:html -->
<span class="about-process-number">04 / REVIEW</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Check the details</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Review responsive layouts, links, forms, and key interactions; refine issues found during testing.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-process-card reveal"} -->
<article class="wp-block-group about-process-card reveal">
<!-- wp:html -->
<span class="about-process-number">05 / HANDOVER</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Prepare for launch</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Confirm the agreed scope, share the handover details, and outline practical next steps.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-process-card reveal"} -->
<article class="wp-block-group about-process-card reveal">
<!-- wp:html -->
<span class="about-process-number">ALWAYS</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Keep communication clear</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Questions, feedback, and decisions stay part of the process—not an afterthought.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","className":"section"} -->
<section class="wp-block-group section">
<!-- wp:group {"className":"container sv-faq-grid"} -->
<div class="wp-block-group container sv-faq-grid">
<!-- wp:group {"className":"reveal"} -->
<div class="wp-block-group reveal">
<!-- wp:html -->
<span class="eyebrow">Good to know</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">A few questions before we begin.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Every project is different. A short conversation can help clarify what’s needed and whether the service is a good fit.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<a class="btn btn-primary" href="/contact/">Ask About Your Project <span class="arrow">↗</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sv-faq reveal"} -->
<div class="wp-block-group sv-faq reveal">
<!-- wp:html -->
<details open=""><summary>Can you redesign an existing website?</summary><p>Yes. The first step is reviewing the current website, identifying the main issues, and agreeing on what should be improved or preserved.</p></details>
<!-- /wp:html -->

<!-- wp:html -->
<details><summary>Will the website work on mobile devices?</summary><p>Responsive layouts are part of the planned approach, with checks across common screen sizes during the review stage.</p></details>
<!-- /wp:html -->

<!-- wp:html -->
<details><summary>Can I update content after the website is built?</summary><p>For WordPress projects, the page structure can be planned around the agreed editing workflow and tools.</p></details>
<!-- /wp:html -->

<!-- wp:html -->
<details><summary>Does SEO work guarantee a higher Google ranking?</summary><p>No. SEO depends on many factors outside a single website update. The service focuses on foundational best practices and improvements within the agreed scope.</p></details>
<!-- /wp:html -->

<!-- wp:html -->
<details><summary>How do I get started?</summary><p>Use the contact page to share your goals, current website (if you have one), desired features, and any target deadline.</p></details>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:html -->
<section aria-labelledby="cta-title" class="cta-section cta2-section">
<div class="container">
<div class="cta2 reveal">
<div class="cta2-copy">
<span class="eyebrow">Have a project in mind?</span>
<h2 id="cta-title">Let’s make your next website <span>more purposeful.</span></h2>
<p>Tell me about your website, online store or redesign goals. We can map out a practical next step together.</p>
<div class="cta2-actions">
<a class="cta2-btn" href="/contact/"><span>Discuss a Project</span><i aria-hidden="true">↗</i></a>
<a class="cta2-ghost" href="mailto:contact@devvitech.com">Email Me <span aria-hidden="true">→</span></a>
</div>
</div>
<aside aria-label="What happens next" class="cta2-card">
<h3>What happens next</h3>
<ol>
<li><b>1</b><div><strong>Share your goals</strong><small>A new website, online store or redesign</small></div></li>
<li><b>2</b><div><strong>Get a clear plan</strong><small>Structure, scope and timeline</small></div></li>
<li><b>3</b><div><strong>Build and launch</strong><small>Quality-checked before handover</small></div></li>
</ol>
<div class="cta2-contact"><a href="mailto:contact@devvitech.com">contact@devvitech.com</a><span>Based in Sylhet, Bangladesh</span></div>
</aside>
</div>
</div>
</section>
<!-- /wp:html -->
</main>
<!-- /wp:group -->
