<?php
/**
 * Title: Pricing page content
 * Slug: sb-theme/pricing
 * Description: Full Pricing page (all sections).
 * Inserter: no
 */
?>
<!-- wp:group {"tagName":"main","anchor":"main"} -->
<main id="main" class="wp-block-group">
<!-- wp:group {"tagName":"section","className":"about-hero"} -->
<section class="wp-block-group about-hero">
<!-- wp:group {"className":"container about-hero-grid"} -->
<div class="wp-block-group container about-hero-grid">
<!-- wp:group {"className":"about-hero-copy reveal"} -->
<div class="wp-block-group about-hero-copy reveal">
<!-- wp:html -->
<div class="about-breadcrumb"><a href="/">Home</a> / Pricing</div>
<!-- /wp:html -->

<!-- wp:html -->
<span class="eyebrow">Clear scope. Thoughtful work.</span>
<!-- /wp:html -->

<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Website pricing,<br/><span>without the guesswork.</span></h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Explore sample packages for website design, WordPress builds, redesigns, and online stores. The right scope and final quote depend on your goals, content, and required features.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"hero-buttons"} -->
<div class="wp-block-group hero-buttons">
<!-- wp:html -->
<a class="btn btn-primary" href="/contact/">Discuss Your Project <span class="arrow">↗</span></a>
<!-- /wp:html -->

<!-- wp:html -->
<a class="btn btn-light" href="#packages">Compare Packages <span class="arrow">↓</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-label="Illustration of a website pricing package" class="about-hero-art reveal"><div class="about-art-label"><span>Project investment</span><span>01 / 04</span></div><div aria-hidden="true" class="pr-ticket"><small>WEBSITE PACKAGE</small><strong>Built around<br/>your goals.</strong><i></i><i class="s"></i><i></i><b></b></div><span class="pr-tag one">✦ Clear deliverables</span><span class="pr-tag two">From $299</span><span class="pr-tag three">Custom quote available</span></div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:html -->
<section aria-label="Packages" class="about-marquee"><div aria-hidden="true" class="about-marquee-track"><div class="about-marquee-group"><span>Starter Website</span><b>✳</b><span>Business Website</span><b>✳</b><span>WordPress Pro</span><b>✳</b><span>eCommerce Store</span><b>✳</b><span>Website Redesign</span><b>✳</b><span>Speed &amp; SEO Basics</span><b>✳</b></div><div class="about-marquee-group"><span>Starter Website</span><b>✳</b><span>Business Website</span><b>✳</b><span>WordPress Pro</span><b>✳</b><span>eCommerce Store</span><b>✳</b><span>Website Redesign</span><b>✳</b><span>Speed &amp; SEO Basics</span><b>✳</b></div></div></section>
<!-- /wp:html -->

<!-- wp:group {"tagName":"section","anchor":"packages","className":"section"} -->
<section id="packages" class="wp-block-group section">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"pr-note reveal"} -->
<div class="wp-block-group pr-note reveal">
<!-- wp:html -->
<span aria-hidden="true">i</span>
<!-- /wp:html -->

<!-- wp:html -->
<div><b>Demo pricing for portfolio presentation</b>These are illustrative USD starting prices for this demo page, not confirmed service rates or a binding quote. Update them to match the actual scope before publishing.</div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow">Choose a starting point</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Packages for different project sizes.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p>Each package can be tailored after we clarify the content, features, and goals for your website.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"pr-grid"} -->
<div class="wp-block-group pr-grid">
<!-- wp:group {"tagName":"article","className":"pr-card reveal sbv-d-0"} -->
<article class="wp-block-group pr-card reveal sbv-d-0">
<!-- wp:html -->
<span class="pr-tier">01 / Essentials</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Starter Website</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"pr-desc"} -->
<p class="pr-desc">A simple, professional online presence for an individual or small business.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"pr-price"} -->
<div class="wp-block-group pr-price">
<!-- wp:html -->
<strong class="pr-amt" data-v="299">$299</strong>
<!-- /wp:html -->

<!-- wp:html -->
<span>USD</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div class="pr-cap">Demo starting price · one-time</div>
<!-- /wp:html -->

<!-- wp:html -->
<a class="btn btn-light" href="contact.html?package=starter">Choose Starter <span class="arrow">↗</span></a>
<!-- /wp:html -->

<!-- wp:html -->
<ul class="pr-list"><li>Up to 3 core pages</li><li>Responsive desktop and mobile layout</li><li>Contact form or contact CTA</li><li>Basic on-page SEO setup</li><li>One feedback round</li></ul>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"pr-foot"} -->
<p class="pr-foot">Best for a small, straightforward website.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"pr-card feat reveal sbv-d-1"} -->
<article class="wp-block-group pr-card feat reveal sbv-d-1">
<!-- wp:html -->
<span class="pr-pop">★ Popular demo option</span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="pr-tier">02 / Business</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Business Website</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"pr-desc"} -->
<p class="pr-desc">A stronger multi-page website for a service business or growing brand.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"pr-price"} -->
<div class="wp-block-group pr-price">
<!-- wp:html -->
<strong class="pr-amt" data-v="599">$599</strong>
<!-- /wp:html -->

<!-- wp:html -->
<span>USD</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div class="pr-cap">Demo starting price · one-time</div>
<!-- /wp:html -->

<!-- wp:html -->
<a class="btn btn-primary" href="contact.html?package=business">Choose Business <span class="arrow">↗</span></a>
<!-- /wp:html -->

<!-- wp:html -->
<ul class="pr-list"><li>Up to 5 core pages</li><li>Custom visual direction</li><li>WordPress and Elementor setup</li><li>Inquiry form and clear CTAs</li><li>Basic on-page SEO structure</li><li>Two feedback rounds</li></ul>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"pr-foot"} -->
<p class="pr-foot">Best for businesses that need more room to explain their services.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"pr-card reveal sbv-d-2"} -->
<article class="wp-block-group pr-card reveal sbv-d-2">
<!-- wp:html -->
<span class="pr-tier">03 / Advanced</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">WordPress Pro</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"pr-desc"} -->
<p class="pr-desc">A more tailored WordPress experience with richer page layouts.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"pr-price"} -->
<div class="wp-block-group pr-price">
<!-- wp:html -->
<strong class="pr-amt" data-v="899">$899</strong>
<!-- /wp:html -->

<!-- wp:html -->
<span>USD</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div class="pr-cap">Demo starting price · one-time</div>
<!-- /wp:html -->

<!-- wp:html -->
<a class="btn btn-light" href="contact.html?package=wordpress-pro">Choose Pro <span class="arrow">↗</span></a>
<!-- /wp:html -->

<!-- wp:html -->
<ul class="pr-list"><li>Up to 7 core pages</li><li>Custom WordPress page layouts</li><li>Elementor editing workflow</li><li>Blog or resource section</li><li>Responsive and basic performance checks</li><li>Two feedback rounds</li></ul>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"pr-foot"} -->
<p class="pr-foot">Best for a growing website with more content needs.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"pr-card reveal sbv-d-3"} -->
<article class="wp-block-group pr-card reveal sbv-d-3">
<!-- wp:html -->
<span class="pr-tier">04 / Online store</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">eCommerce Store</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"pr-desc"} -->
<p class="pr-desc">A storefront concept for businesses planning to sell products online.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"pr-price"} -->
<div class="wp-block-group pr-price">
<!-- wp:html -->
<strong class="pr-amt" data-v="1299">$1,299</strong>
<!-- /wp:html -->

<!-- wp:html -->
<span>USD</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div class="pr-cap">Demo starting price · one-time</div>
<!-- /wp:html -->

<!-- wp:html -->
<a class="btn btn-light" href="contact.html?package=ecommerce">Choose eCommerce <span class="arrow">↗</span></a>
<!-- /wp:html -->

<!-- wp:html -->
<ul class="pr-list"><li>WooCommerce foundation</li><li>Store and product page setup</li><li>Up to 10 initial products added</li><li>Cart and checkout styling</li><li>Responsive store layouts</li><li>Two feedback rounds</li></ul>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"pr-foot"} -->
<p class="pr-foot">Best for a small store; complex integrations are quoted separately.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"pr-bottom reveal"} -->
<p class="pr-bottom reveal">Demo package limits are examples, not final commitments. Domain, hosting, paid themes/plugins, third-party subscriptions, copywriting, product photography, payment-provider fees, and ongoing maintenance are excluded unless specifically agreed.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","anchor":"estimate","className":"section sbv-s-background-eef0ff"} -->
<section id="estimate" class="wp-block-group section sbv-s-background-eef0ff">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow">Build your estimate</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Mix a package with the extras you need.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p>Illustrative add-on prices help show how optional work might be scoped. Confirm the final cost before starting.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"pr-est"} -->
<div class="wp-block-group pr-est">
<!-- wp:group {"className":"pr-panel reveal"} -->
<div class="wp-block-group pr-panel reveal">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><span class="pr-step">1</span>Choose a package</h3>
<!-- /wp:heading -->

<!-- wp:group {"anchor":"prPk","className":"pr-pk-grid"} -->
<div id="prPk" class="wp-block-group pr-pk-grid">
<!-- wp:html -->
<button aria-pressed="false" class="pr-pk" data-p="299" data-pk="starter" type="button">Starter<small>$299</small></button>
<!-- /wp:html -->

<!-- wp:html -->
<button aria-pressed="true" class="pr-pk" data-p="599" data-pk="business" type="button">Business<small>$599</small></button>
<!-- /wp:html -->

<!-- wp:html -->
<button aria-pressed="false" class="pr-pk" data-p="899" data-pk="pro" type="button">WordPress Pro<small>$899</small></button>
<!-- /wp:html -->

<!-- wp:html -->
<button aria-pressed="false" class="pr-pk" data-p="1299" data-pk="store" type="button">eCommerce<small>$1,299</small></button>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><span class="pr-step">2</span>Add optional extras</h3>
<!-- /wp:heading -->

<!-- wp:group {"className":"pr-ad"} -->
<div class="wp-block-group pr-ad">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<b>Website Redesign</b>
<!-- /wp:html -->

<!-- wp:paragraph -->
<p>Refresh an existing website’s layout, visual hierarchy, and responsive experience.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<em>From $199 · demo price</em>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<button aria-label="Add Website Redesign" aria-pressed="false" class="pr-tg" id="prRed" type="button"></button>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"pr-ad"} -->
<div class="wp-block-group pr-ad">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<b>Extra Page</b>
<!-- /wp:html -->

<!-- wp:paragraph -->
<p>Add another designed page that follows the agreed visual system.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<em>From $60 / page · demo price</em>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"pr-stepper"} -->
<div class="wp-block-group pr-stepper">
<!-- wp:html -->
<button aria-label="Remove a page" class="pr-step-btn" id="prMinus" type="button">−</button>
<!-- /wp:html -->

<!-- wp:html -->
<output aria-live="polite" id="prPages">0</output>
<!-- /wp:html -->

<!-- wp:html -->
<button aria-label="Add a page" class="pr-step-btn" id="prPlus" type="button">+</button>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"pr-ad"} -->
<div class="wp-block-group pr-ad">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<b>Speed &amp; SEO Basics</b>
<!-- /wp:html -->

<!-- wp:paragraph -->
<p>Foundational image, metadata, and performance-minded improvements within scope.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<em>From $120 · demo price</em>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<button aria-label="Add Speed and SEO Basics" aria-pressed="false" class="pr-tg" id="prSeo" type="button"></button>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<aside aria-label="Estimated starting total" class="pr-total reveal"><small>Estimated starting total</small><span class="pr-big"><span class="sbv-s-margin-0 sbv-s-font-size-inherit sbv-s-color-inherit sbv-s-font-weight-inherit" id="prTotal">$599</span><span>USD</span></span><ul class="pr-lines" id="prLines"></ul><a class="btn btn-primary" href="contact.html?package=business" id="prCta">Request this quote <span class="arrow">↗</span></a><p>Demo estimate only, not a binding quote. Domain, hosting, paid plugins and third-party fees are excluded unless agreed.</p></aside>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","className":"section sbv-s-background-var-ink"} -->
<section class="wp-block-group section sbv-s-background-var-ink">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow sbv-s-color-var-lime">How a quote works</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2,"className":"sbv-s-color-white"} -->
<h2 class="wp-block-heading sbv-s-color-white">Good work starts with a clear brief.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"sbv-s-color-b6c2d4"} -->
<p class="sbv-s-color-b6c2d4">Three simple steps from first message to a scope you can trust.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"pr-steps"} -->
<div class="wp-block-group pr-steps">
<!-- wp:group {"tagName":"article","className":"about-process-card reveal"} -->
<article class="wp-block-group about-process-card reveal">
<!-- wp:html -->
<span class="about-process-number">01</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Share your brief</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Tell me what the website needs to do, what content you already have, and any deadline or technical requirements.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-process-card reveal"} -->
<article class="wp-block-group about-process-card reveal">
<!-- wp:html -->
<span class="about-process-number">02</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Agree the scope</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>I recommend an appropriate package or a custom scope, with clear deliverables and review rounds.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-process-card reveal"} -->
<article class="wp-block-group about-process-card reveal">
<!-- wp:html -->
<span class="about-process-number">03</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Build and review</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The site is designed, built and refined through the agreed feedback rounds before launch.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","className":"section"} -->
<section class="wp-block-group section">
<!-- wp:group {"className":"container pr-faq-grid"} -->
<div class="wp-block-group container pr-faq-grid">
<!-- wp:group {"className":"reveal"} -->
<div class="wp-block-group reveal">
<!-- wp:html -->
<span class="eyebrow">Before we begin</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Questions about pricing and scope.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Tell me what the website needs to do, what content you already have, and any deadline or technical requirements. I can then recommend an appropriate scope.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<a class="btn btn-primary" href="/contact/">Get a Project Quote <span class="arrow">↗</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sv-faq reveal"} -->
<div class="wp-block-group sv-faq reveal">
<!-- wp:html -->
<details open=""><summary>Are these the final prices?</summary><p>No. The prices on this page are demo values for the portfolio layout. Replace them with approved rates before presenting them as actual offers.</p></details>
<!-- /wp:html -->

<!-- wp:html -->
<details><summary>What can change the final quote?</summary><p>Page count, custom functionality, content readiness, integrations, product volume, migration needs, and review rounds can all affect the scope and price.</p></details>
<!-- /wp:html -->

<!-- wp:html -->
<details><summary>Are domain and hosting included?</summary><p>They are excluded from these sample prices unless explicitly included in a written project agreement. Paid plugin and third-party service costs are also separate.</p></details>
<!-- /wp:html -->

<!-- wp:html -->
<details><summary>Do you guarantee SEO rankings or sales?</summary><p>No. The sample packages may include foundational SEO practices, but rankings, traffic, leads, and sales depend on many factors beyond a website build.</p></details>
<!-- /wp:html -->

<!-- wp:html -->
<details><summary>Can I request a custom package?</summary><p>Yes. Share your requirements through the contact page to discuss a tailored scope and quote.</p></details>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:html -->
<section aria-labelledby="cta-title" class="cta-section cta2-section">
<div class="container">
<div class="cta2 reveal">
<div class="cta2-copy">
<span class="eyebrow">Have a project in mind?</span>
<h2 id="cta-title">Let’s shape the right scope <span>together.</span></h2>
<p>Tell me about your website, online store or redesign goals. We can map out a practical next step together.</p>
<div class="cta2-actions">
<a class="cta2-btn" href="/contact/"><span>Discuss a Project</span><i aria-hidden="true">↗</i></a>
<a class="cta2-ghost" href="mailto:contact@devvitech.com">Email Me <span aria-hidden="true">→</span></a>
</div>
</div>
<aside aria-label="What happens next" class="cta2-card">
<h3>What happens next</h3>
<ol>
<li><b>1</b><div><strong>Share your goals</strong><small>A new website, online store or redesign</small></div></li>
<li><b>2</b><div><strong>Get a clear plan</strong><small>Structure, scope and timeline</small></div></li>
<li><b>3</b><div><strong>Build and launch</strong><small>Quality-checked before handover</small></div></li>
</ol>
<div class="cta2-contact"><a href="mailto:contact@devvitech.com">contact@devvitech.com</a><span>Based in Sylhet, Bangladesh</span></div>
</aside>
</div>
</div>
</section>
<!-- /wp:html -->
</main>
<!-- /wp:group -->
