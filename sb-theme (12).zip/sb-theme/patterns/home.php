<?php
/**
 * Title: Home page content
 * Slug: sb-theme/home
 * Description: Full home page (all sections).
 * Inserter: no
 */
?>
<!-- wp:group {"tagName":"main","anchor":"main"} -->
<main id="main" class="wp-block-group">
<!-- wp:group {"tagName":"section","className":"hero"} -->
<section class="wp-block-group hero">
<!-- wp:group {"className":"container hero-grid"} -->
<div class="wp-block-group container hero-grid">
<!-- wp:group {"className":"hero-copy"} -->
<div class="wp-block-group hero-copy">
<!-- wp:html -->
<div class="hero-kicker"><span class="status-dot"></span> WordPress · WooCommerce · Elementor</div>
<!-- /wp:html -->

<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Digital experiences built to <span>work harder.</span></h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>I’m Sadik Bin Jalil, a WordPress and eCommerce developer focused on building polished, fast, and easy-to-manage websites that help businesses move forward.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"hero-buttons"} -->
<div class="wp-block-group hero-buttons">
<!-- wp:html -->
<a class="btn btn-primary" href="/projects/">Explore Selected Work <span class="arrow">↗</span></a>
<!-- /wp:html -->

<!-- wp:html -->
<a class="btn btn-light" href="/contact/">Let’s Talk <span class="arrow">→</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"hero-note"} -->
<div class="wp-block-group hero-note">
<!-- wp:html -->
<div aria-hidden="true" class="avatar-stack"><span>WP</span><span>WC</span><span>UX</span></div>
<!-- /wp:html -->

<!-- wp:html -->
<span><strong>Strategy to launch</strong><br/>Thoughtful design. Careful development.</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-label="Sadik Bin Jalil profile and experience" class="hero-art profile-art" role="group">
<div class="profile-topline"><span>DEVVITECH / PROFILE</span><span class="profile-availability"><i></i> eCommerce Specialist</span></div>
<div class="profile-photo-wrap">
<img alt="Portrait of Sadik Bin Jalil, WordPress and eCommerce developer" class="profile-photo" decoding="async" fetchpriority="high" height="375" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/hero-profile.webp' ) ); ?>" width="340"/>
<div aria-hidden="true" class="profile-fallback">SB</div>
<div class="photo-caption"><span class="photo-caption-mark">SB</span><span><strong>Sadik Bin Jalil</strong><small>WordPress &amp; eCommerce Developer</small></span></div>
</div>
<div class="profile-floating-card experience-card"><span class="float-icon">✦</span><strong><span class="count-up" data-count="10" data-suffix="+">10+</span></strong><small>Years of experience</small></div>
<div class="profile-floating-card projects-card"><span class="float-icon">↗</span><strong><span class="count-up" data-count="350" data-suffix="+">350+</span></strong><small>Projects delivered</small></div>
<div class="profile-bottomline"><span>WordPress · WooCommerce · Elementor</span><span class="profile-spark">✳</span></div>
</div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-hidden="true" class="marquee-strip">
<div aria-hidden="true" class="marquee-track">
<div class="marquee-group"><span>WordPress Development <b>✳</b></span><span>WooCommerce Stores <b>✳</b></span><span>Elementor Builds <b>✳</b></span><span>Responsive Design <b>✳</b></span><span>Website Redesign <b>✳</b></span><span>Performance &amp; UX <b>✳</b></span></div>
<div class="marquee-group"><span>WordPress Development <b>✳</b></span><span>WooCommerce Stores <b>✳</b></span><span>Elementor Builds <b>✳</b></span><span>Responsive Design <b>✳</b></span><span>Website Redesign <b>✳</b></span><span>Performance &amp; UX <b>✳</b></span></div>
</div>
</div>
<!-- /wp:html -->

<!-- wp:html -->
<section aria-labelledby="skills-title" class="trust-strip sk-section"><div class="container"><div class="sk-head reveal"><span class="eyebrow">Core expertise</span><h2 id="skills-title">Specialist skills for digital growth</h2></div><ul class="sk-grid"><li class="sk reveal" style="--d:0"><span class="sk-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewbox="0 0 24 24"><circle cx="12" cy="12" r="9"></circle><path d="M6.5 9l3 8 2.5-6 2.5 6 3-8"></path></svg></span><div><strong>WordPress</strong><small>Custom themes and business websites</small></div></li><li class="sk reveal" style="--d:1"><span class="sk-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewbox="0 0 24 24"><circle cx="9" cy="20" r="1.5"></circle><circle cx="18" cy="20" r="1.5"></circle><path d="M3 4h2l2.5 11h11L21 7H6"></path></svg></span><div><strong>WooCommerce</strong><small>Online stores built to convert</small></div></li><li class="sk reveal" style="--d:2"><span class="sk-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewbox="0 0 24 24"><rect height="16" rx="2" width="18" x="3" y="4"></rect><path d="M3 9h18M9 9v11"></path></svg></span><div><strong>Elementor</strong><small>Editable, responsive layouts</small></div></li><li class="sk reveal" style="--d:3"><span class="sk-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewbox="0 0 24 24"><path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z"></path></svg></span><div><strong>Performance</strong><small>Fast, stable, mobile-ready pages</small></div></li><li class="sk reveal" style="--d:4"><span class="sk-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewbox="0 0 24 24"><circle cx="11" cy="11" r="7"></circle><path d="M20 20l-4-4"></path></svg></span><div><strong>SEO</strong><small>Search-friendly page structure</small></div></li></ul></div></section>
<!-- /wp:html -->

<!-- wp:group {"tagName":"section","anchor":"impact","className":"section"} -->
<section id="impact" class="wp-block-group section">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow">A thoughtful build process</span>
<!-- /wp:html -->

<!-- wp:heading -->
<h2 class="wp-block-heading">More than a website.<br/>A better digital foundation.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p>Every project deserves clear structure, useful details, responsive layouts, and a smooth experience from the first click to the final action.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"anchor":"statTrack","className":"stat-track"} -->
<div id="statTrack" class="wp-block-group stat-track">
<!-- wp:group {"className":"stat-stage"} -->
<div class="wp-block-group stat-stage">
<!-- wp:group {"className":"stat-deck"} -->
<div class="wp-block-group stat-deck">
<!-- wp:group {"tagName":"article","className":"stat-big sb-1 sbv-p-1"} -->
<article class="wp-block-group stat-big sb-1 sbv-p-1">
<!-- wp:group {"className":"sb-top"} -->
<div class="wp-block-group sb-top">
<!-- wp:html -->
<span class="sb-idx">01 / 04</span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="sb-chip">Experience</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sb-main"} -->
<div class="wp-block-group sb-main">
<!-- wp:group {"className":"sb-copy"} -->
<div class="wp-block-group sb-copy">
<!-- wp:html -->
<span class="sb-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewbox="0 0 24 24"><path d="M12 7v5l3 2"></path><circle cx="12" cy="12" r="9"></circle></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<strong><span class="stat-num" data-count="10" data-suffix="+">10+</span></strong>
<!-- /wp:html -->

<!-- wp:html -->
<span class="sb-label">Years of WordPress experience</span>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"sb-desc"} -->
<p class="sb-desc">Building WordPress websites for businesses, from landing pages to full eCommerce stores.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"vis vis-years"} -->
<div class="wp-block-group vis vis-years">
<!-- wp:html -->
<i style="--k:0;--h:28%"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:1;--h:35%"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:2;--h:42%"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:3;--h:49%"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:4;--h:56%"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:5;--h:63%"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:6;--h:70%"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:7;--h:77%"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:8;--h:84%"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:9;--h:91%"></i>
<!-- /wp:html -->

<!-- wp:html -->
<span>Year by year</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-hidden="true" class="sb-bar"><i></i></div>
<!-- /wp:html -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"stat-big sb-2 sbv-p-2"} -->
<article class="wp-block-group stat-big sb-2 sbv-p-2">
<!-- wp:group {"className":"sb-top"} -->
<div class="wp-block-group sb-top">
<!-- wp:html -->
<span class="sb-idx">02 / 04</span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="sb-chip">Delivery</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sb-main"} -->
<div class="wp-block-group sb-main">
<!-- wp:group {"className":"sb-copy"} -->
<div class="wp-block-group sb-copy">
<!-- wp:html -->
<span class="sb-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewbox="0 0 24 24"><path d="M3 7l9-4 9 4-9 4-9-4z"></path><path d="M3 12l9 4 9-4M3 17l9 4 9-4"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<strong><span class="stat-num" data-count="350" data-suffix="+">350+</span></strong>
<!-- /wp:html -->

<!-- wp:html -->
<span class="sb-label">Projects delivered by Devvitech</span>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"sb-desc"} -->
<p class="sb-desc">Websites and online stores delivered by the Devvitech team for clients and brands.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"vis vis-tiles"} -->
<div class="wp-block-group vis vis-tiles">
<!-- wp:html -->
<i style="--k:0"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:1"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:2"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:3"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:4"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:5"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:6"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:7"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:8"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:9"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:10"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:11"><b></b><u></u></i>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-hidden="true" class="sb-bar"><i></i></div>
<!-- /wp:html -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"stat-big sb-3 sbv-p-3"} -->
<article class="wp-block-group stat-big sb-3 sbv-p-3">
<!-- wp:group {"className":"sb-top"} -->
<div class="wp-block-group sb-top">
<!-- wp:html -->
<span class="sb-idx">03 / 04</span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="sb-chip">Training</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sb-main"} -->
<div class="wp-block-group sb-main">
<!-- wp:group {"className":"sb-copy"} -->
<div class="wp-block-group sb-copy">
<!-- wp:html -->
<span class="sb-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewbox="0 0 24 24"><path d="M2 9l10-5 10 5-10 5-10-5z"></path><path d="M6 11.5V16c3 2.5 9 2.5 12 0v-4.5"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<strong><span class="stat-num" data-count="1000" data-suffix="+">1,000+</span></strong>
<!-- /wp:html -->

<!-- wp:html -->
<span class="sb-label">Students trained at FreelancerLab</span>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"sb-desc"} -->
<p class="sb-desc">Learners trained in web and freelancing skills at Freelancer Lab, Sylhet.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"vis vis-people"} -->
<div class="wp-block-group vis vis-people">
<!-- wp:html -->
<i style="--k:0"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:1"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:2"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:3"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i style="--k:4"></i>
<!-- /wp:html -->

<!-- wp:html -->
<span>+ learners</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-hidden="true" class="sb-bar"><i></i></div>
<!-- /wp:html -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"stat-big sb-4 sbv-p-4"} -->
<article class="wp-block-group stat-big sb-4 sbv-p-4">
<!-- wp:group {"className":"sb-top"} -->
<div class="wp-block-group sb-top">
<!-- wp:html -->
<span class="sb-idx">04 / 04</span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="sb-chip">Process</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sb-main"} -->
<div class="wp-block-group sb-main">
<!-- wp:group {"className":"sb-copy"} -->
<div class="wp-block-group sb-copy">
<!-- wp:html -->
<span class="sb-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewbox="0 0 24 24"><circle cx="5" cy="18" r="2"></circle><circle cx="19" cy="6" r="2"></circle><path d="M7 18h6a4 4 0 0 0 0-8h-2a4 4 0 0 1 0-8h6"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<strong><span class="stat-num" data-count="4" data-suffix="">4</span></strong>
<!-- /wp:html -->

<!-- wp:html -->
<span class="sb-label">Core build stages</span>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"sb-desc"} -->
<p class="sb-desc">A clear path on every project: understand, plan, build and launch.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"vis vis-steps"} -->
<div class="wp-block-group vis vis-steps">
<!-- wp:group {"className":"sbv-k-0"} -->
<div class="wp-block-group sbv-k-0">
<!-- wp:html -->
<i>1</i>
<!-- /wp:html -->

<!-- wp:html -->
<span>Understand</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sbv-k-1"} -->
<div class="wp-block-group sbv-k-1">
<!-- wp:html -->
<i>2</i>
<!-- /wp:html -->

<!-- wp:html -->
<span>Plan</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sbv-k-2"} -->
<div class="wp-block-group sbv-k-2">
<!-- wp:html -->
<i>3</i>
<!-- /wp:html -->

<!-- wp:html -->
<span>Build</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sbv-k-3"} -->
<div class="wp-block-group sbv-k-3">
<!-- wp:html -->
<i>4</i>
<!-- /wp:html -->

<!-- wp:html -->
<span>Launch</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-hidden="true" class="sb-bar"><i></i></div>
<!-- /wp:html -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-hidden="true" class="stat-dots"><span></span><span></span><span></span><span></span></div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","anchor":"services","className":"section services-section"} -->
<section id="services" class="wp-block-group section services-section">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow">What I can help with</span>
<!-- /wp:html -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Digital services, built around your goals.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p>From a new business website to a custom online store or a careful redesign, the work starts with what your business actually needs.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"svc-grid"} -->
<div class="wp-block-group svc-grid">
<!-- wp:group {"tagName":"article","className":"svc svc-a from-l reveal sbv-d-0"} -->
<article class="wp-block-group svc svc-a from-l reveal sbv-d-0">
<!-- wp:group {"className":"svc-top"} -->
<div class="wp-block-group svc-top">
<!-- wp:html -->
<span class="svc-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewbox="0 0 24 24"><path d="M8 8l-4 4 4 4M16 8l4 4-4 4M14 5l-4 14"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="svc-no">01</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"svc-body"} -->
<div class="wp-block-group svc-body">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Custom WordPress Development</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Flexible business websites with clear structure, easy content editing and a foundation built for future growth.</p>
<!-- /wp:paragraph -->

<!-- wp:list {"className":"svc-tags"} -->
<ul class="wp-block-list svc-tags"><!-- wp:list-item -->
<li>Custom themes</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Business sites</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Easy editing</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:html -->
<a class="svc-link" href="/services/">Explore service <span aria-hidden="true">→</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-hidden="true" class="svc-mock"><div class="m-bar"><i></i><i></i><i></i></div><div class="m-body"><b></b><b></b><b></b><span></span></div></div>
<!-- /wp:html -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"svc svc-b from-r reveal sbv-d-1"} -->
<article class="wp-block-group svc svc-b from-r reveal sbv-d-1">
<!-- wp:group {"className":"svc-top"} -->
<div class="wp-block-group svc-top">
<!-- wp:html -->
<span class="svc-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewbox="0 0 24 24"><circle cx="9" cy="20" r="1.5"></circle><circle cx="18" cy="20" r="1.5"></circle><path d="M3 4h2l2.5 11h11L21 7H6"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="svc-no">02</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"svc-body"} -->
<div class="wp-block-group svc-body">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">WooCommerce Stores</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Product pages, store layouts and shopping journeys that make browsing and buying feel straightforward.</p>
<!-- /wp:paragraph -->

<!-- wp:list {"className":"svc-tags"} -->
<ul class="wp-block-list svc-tags"><!-- wp:list-item -->
<li>Product pages</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Checkout flow</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:html -->
<a class="svc-link" href="/services/">Explore service <span aria-hidden="true">→</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"svc svc-c from-b reveal sbv-d-2"} -->
<article class="wp-block-group svc svc-c from-b reveal sbv-d-2">
<!-- wp:group {"className":"svc-top"} -->
<div class="wp-block-group svc-top">
<!-- wp:html -->
<span class="svc-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewbox="0 0 24 24"><rect height="16" rx="2" width="18" x="3" y="4"></rect><path d="M3 9h18M9 9v11"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="svc-no">03</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"svc-body"} -->
<div class="wp-block-group svc-body">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Elementor Website Builds</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Responsive page layouts with practical editing flexibility and consistent spacing.</p>
<!-- /wp:paragraph -->

<!-- wp:list {"className":"svc-tags"} -->
<ul class="wp-block-list svc-tags"><!-- wp:list-item -->
<li>Responsive</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Editable</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:html -->
<a class="svc-link" href="/services/">Explore service <span aria-hidden="true">→</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"svc svc-d from-b reveal sbv-d-3"} -->
<article class="wp-block-group svc svc-d from-b reveal sbv-d-3">
<!-- wp:group {"className":"svc-top"} -->
<div class="wp-block-group svc-top">
<!-- wp:html -->
<span class="svc-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewbox="0 0 24 24"><path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="svc-no">04</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"svc-body"} -->
<div class="wp-block-group svc-body">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Website Redesign</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Refresh an outdated site with better hierarchy, clearer calls to action and a more considered user journey.</p>
<!-- /wp:paragraph -->

<!-- wp:list {"className":"svc-tags"} -->
<ul class="wp-block-list svc-tags"><!-- wp:list-item -->
<li>Modern UI</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Clear CTAs</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:html -->
<a class="svc-link" href="/services/">Explore service <span aria-hidden="true">→</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"svc svc-e from-b reveal sbv-d-4"} -->
<article class="wp-block-group svc svc-e from-b reveal sbv-d-4">
<!-- wp:group {"className":"svc-top"} -->
<div class="wp-block-group svc-top">
<!-- wp:html -->
<span class="svc-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewbox="0 0 24 24"><path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="svc-no">05</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"svc-body"} -->
<div class="wp-block-group svc-body">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Speed & Performance</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Review key performance issues and improve the foundations that make pages feel quicker and more reliable.</p>
<!-- /wp:paragraph -->

<!-- wp:list {"className":"svc-tags"} -->
<ul class="wp-block-list svc-tags"><!-- wp:list-item -->
<li>Faster loading</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Core Web Vitals</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:html -->
<a class="svc-link" href="/services/">Explore service <span aria-hidden="true">→</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"svc svc-f from-b reveal sbv-d-5"} -->
<article class="wp-block-group svc svc-f from-b reveal sbv-d-5">
<!-- wp:group {"className":"svc-top"} -->
<div class="wp-block-group svc-top">
<!-- wp:html -->
<span class="svc-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewbox="0 0 24 24"><circle cx="11" cy="11" r="7"></circle><path d="M20 20l-4-4"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="svc-no">06</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"svc-body"} -->
<div class="wp-block-group svc-body">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Landing Pages & SEO Optimization</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Focused, search-friendly pages that rank, load fast and guide visitors toward one clear action.</p>
<!-- /wp:paragraph -->

<!-- wp:list {"className":"svc-tags"} -->
<ul class="wp-block-list svc-tags"><!-- wp:list-item -->
<li>Keyword-ready structure</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Fast on mobile</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>One clear CTA</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:html -->
<a class="svc-link" href="/services/">Explore service <span aria-hidden="true">→</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<ul aria-hidden="true" class="svc-checks"><li>Title &amp; meta</li><li>Headings</li><li>Mobile ready</li><li>Fast loading</li></ul>
<!-- /wp:html -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:html -->
<section aria-labelledby="value-title" class="section stack-section" id="value">
<div class="container stack-wrap">
<div class="stack-intro reveal"><span class="eyebrow">Built around your customer</span><h2 id="value-title">A website should earn its place.</h2><p>Every project starts with three questions: what does the customer need, what will they find, and what does the business gain?</p><a class="btn btn-primary" href="/contact/">Start a project <span class="arrow">↗</span></a></div>
<div class="stack-list">
<article class="stack-card sc-1" style="--i:0"><span class="sc-num">01</span><h3>What your customer needs</h3><p>Visitors arrive with one question: can this business solve my problem? Every page is built to answer it fast.</p><ul><li><button class="sc-point" data-card="0" data-point="0" type="button"><span>Clear offer above the fold</span><span aria-hidden="true">→</span></button></li><li><button class="sc-point" data-card="0" data-point="1" type="button"><span>Easy navigation on any device</span><span aria-hidden="true">→</span></button></li><li><button class="sc-point" data-card="0" data-point="2" type="button"><span>Real proof and trust signals</span><span aria-hidden="true">→</span></button></li></ul><p class="sc-hint">Select a point to read more</p></article>
<article class="stack-card sc-2" style="--i:1"><span class="sc-num">02</span><h3>What they find on your website</h3><p>A fast, mobile-friendly site where products, prices and contact options are easy to find.</p><ul><li><button class="sc-point" data-card="1" data-point="0" type="button"><span>Quick load times</span><span aria-hidden="true">→</span></button></li><li><button class="sc-point" data-card="1" data-point="1" type="button"><span>Search-friendly structure (SEO)</span><span aria-hidden="true">→</span></button></li><li><button class="sc-point" data-card="1" data-point="2" type="button"><span>Simple checkout and contact paths</span><span aria-hidden="true">→</span></button></li></ul><p class="sc-hint">Select a point to read more</p></article>
<article class="stack-card sc-3" style="--i:2"><span class="sc-num">03</span><h3>What your business gains</h3><p>More enquiries, smoother orders and a site that can grow without starting over.</p><ul><li><button class="sc-point" data-card="2" data-point="0" type="button"><span>Conversion-focused layouts</span><span aria-hidden="true">→</span></button></li><li><button class="sc-point" data-card="2" data-point="1" type="button"><span>Easy content editing in WordPress</span><span aria-hidden="true">→</span></button></li><li><button class="sc-point" data-card="2" data-point="2" type="button"><span>A foundation for future growth</span><span aria-hidden="true">→</span></button></li></ul><p class="sc-hint">Select a point to read more</p></article>
<article class="stack-card sc-4" style="--i:3"><span class="sc-num">04</span><h3>How it is delivered</h3><p>A clear process, honest communication and quality checks before every handover.</p><ul><li><button class="sc-point" data-card="3" data-point="0" type="button"><span>Plan, design, build, launch</span><span aria-hidden="true">→</span></button></li><li><button class="sc-point" data-card="3" data-point="1" type="button"><span>Testing across phones, tablets and desktops</span><span aria-hidden="true">→</span></button></li><li><button class="sc-point" data-card="3" data-point="2" type="button"><span>Maintenance and support options</span><span aria-hidden="true">→</span></button></li></ul><p class="sc-hint">Select a point to read more</p></article>
</div>
</div>
</section>
<!-- /wp:html -->

<!-- wp:group {"tagName":"section","anchor":"projects","className":"section"} -->
<section id="projects" class="wp-block-group section">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow">Design showcase</span>
<!-- /wp:html -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Website directions for real businesses.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p>Hover a preview to watch the full page scroll, then open the details. Live client sites are linked below.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sw-grid"} -->
<div class="wp-block-group sw-grid">
<!-- wp:group {"tagName":"article","className":"sw-card reveal sbv-d-0"} -->
<article class="wp-block-group sw-card reveal sbv-d-0">
<!-- wp:group {"className":"sw-frame"} -->
<div class="wp-block-group sw-frame">
<!-- wp:group {"className":"sw-bar"} -->
<div class="wp-block-group sw-bar">
<!-- wp:html -->
<i></i>
<!-- /wp:html -->

<!-- wp:html -->
<i></i>
<!-- /wp:html -->

<!-- wp:html -->
<i></i>
<!-- /wp:html -->

<!-- wp:html -->
<span>Design preview</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sw-view"} -->
<div class="wp-block-group sw-view">
<!-- wp:html -->
<img alt="Fitness center website design preview" decoding="async" height="900" loading="lazy" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/project-fitness.webp' ) ); ?>" width="455"/>
<!-- /wp:html -->

<!-- wp:html -->
<span aria-hidden="true" class="sw-hint">Hover to scroll</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sw-meta"} -->
<div class="wp-block-group sw-meta">
<!-- wp:html -->
<small>Fitness &amp; Gym</small>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Fitness Center Website</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A bold, high-energy design for a gym or fitness club.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<button aria-haspopup="dialog" class="sw-btn" data-sw="0" type="button">View details <span aria-hidden="true">↗</span></button>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"sw-card reveal sbv-d-1"} -->
<article class="wp-block-group sw-card reveal sbv-d-1">
<!-- wp:group {"className":"sw-frame"} -->
<div class="wp-block-group sw-frame">
<!-- wp:group {"className":"sw-bar"} -->
<div class="wp-block-group sw-bar">
<!-- wp:html -->
<i></i>
<!-- /wp:html -->

<!-- wp:html -->
<i></i>
<!-- /wp:html -->

<!-- wp:html -->
<i></i>
<!-- /wp:html -->

<!-- wp:html -->
<span>Design preview</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sw-view"} -->
<div class="wp-block-group sw-view">
<!-- wp:html -->
<img alt="Law firm website design preview" decoding="async" height="1200" loading="lazy" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/project-ecommerce.webp' ) ); ?>" width="600"/>
<!-- /wp:html -->

<!-- wp:html -->
<span aria-hidden="true" class="sw-hint">Hover to scroll</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sw-meta"} -->
<div class="wp-block-group sw-meta">
<!-- wp:html -->
<small>Law Firm</small>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Law Firm Website</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A serious, trustworthy design for law practices and legal professionals.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<button aria-haspopup="dialog" class="sw-btn" data-sw="1" type="button">View details <span aria-hidden="true">↗</span></button>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"sw-card reveal sbv-d-2"} -->
<article class="wp-block-group sw-card reveal sbv-d-2">
<!-- wp:group {"className":"sw-frame"} -->
<div class="wp-block-group sw-frame">
<!-- wp:group {"className":"sw-bar"} -->
<div class="wp-block-group sw-bar">
<!-- wp:html -->
<i></i>
<!-- /wp:html -->

<!-- wp:html -->
<i></i>
<!-- /wp:html -->

<!-- wp:html -->
<i></i>
<!-- /wp:html -->

<!-- wp:html -->
<span>Design preview</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sw-view"} -->
<div class="wp-block-group sw-view">
<!-- wp:html -->
<img alt="Residential painting website design preview" decoding="async" height="1075" loading="lazy" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/project-business.webp' ) ); ?>" width="736"/>
<!-- /wp:html -->

<!-- wp:html -->
<span aria-hidden="true" class="sw-hint">Hover to scroll</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sw-meta"} -->
<div class="wp-block-group sw-meta">
<!-- wp:html -->
<small>Home Services</small>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Residential Painting Website</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A bright, friendly design for painters and other home-service businesses.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<button aria-haspopup="dialog" class="sw-btn" data-sw="2" type="button">View details <span aria-hidden="true">↗</span></button>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sw-live"} -->
<div class="wp-block-group sw-live">
<!-- wp:html -->
<span>Live work by Sadik</span>
<!-- /wp:html -->

<!-- wp:html -->
<a href="https://freelancerlabbd.com" rel="noopener noreferrer" target="_blank">Freelancer Lab <i aria-hidden="true">↗</i></a>
<!-- /wp:html -->

<!-- wp:html -->
<a href="https://imransolicitors.co.uk" rel="noopener noreferrer" target="_blank">Imran Solicitors <i aria-hidden="true">↗</i></a>
<!-- /wp:html -->

<!-- wp:html -->
<a href="https://greatamericangaragedoors.com" rel="noopener noreferrer" target="_blank">Great American Garage Doors <i aria-hidden="true">↗</i></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","anchor":"process","className":"section process-section"} -->
<section id="process" class="wp-block-group section process-section">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow">A clear process</span>
<!-- /wp:html -->

<!-- wp:heading -->
<h2 class="wp-block-heading">From first conversation<br/>to confident launch.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p>Good collaboration means knowing what happens next. Each stage is shaped around communication, quality checks, and shared decisions.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"process-grid"} -->
<div class="wp-block-group process-grid">
<!-- wp:group {"tagName":"article","className":"process-step reveal"} -->
<article class="wp-block-group process-step reveal">
<!-- wp:html -->
<span aria-hidden="true" class="ps-dot"><svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="3.2" viewbox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="step-num">STEP 01 / DISCOVER</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Understand</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Talk through your goals, audience, existing website, and what success should look like.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<span aria-hidden="true" class="ps-badge"></span>
<!-- /wp:html -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"process-step reveal"} -->
<article class="wp-block-group process-step reveal">
<!-- wp:html -->
<span aria-hidden="true" class="ps-dot"><svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="3.2" viewbox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="step-num">STEP 02 / PLAN</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Shape the plan</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Set the page structure, priorities, content needs, timeline, and scope before the build.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<span aria-hidden="true" class="ps-badge"></span>
<!-- /wp:html -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"process-step reveal"} -->
<article class="wp-block-group process-step reveal">
<!-- wp:html -->
<span aria-hidden="true" class="ps-dot"><svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="3.2" viewbox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="step-num">STEP 03 / BUILD</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Design & develop</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Create the experience, test responsive layouts, and refine details with your feedback.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<span aria-hidden="true" class="ps-badge"></span>
<!-- /wp:html -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"process-step reveal"} -->
<article class="wp-block-group process-step reveal">
<!-- wp:html -->
<span aria-hidden="true" class="ps-dot"><svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="3.2" viewbox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="step-num">STEP 04 / LAUNCH</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Review & deliver</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Check the key journeys, prepare handover details, and launch with a clear next-step plan.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<span aria-hidden="true" class="ps-badge"></span>
<!-- /wp:html -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"anchor":"processFinish","className":"process-finish"} -->
<div id="processFinish" class="wp-block-group process-finish">
<!-- wp:html -->
<span aria-hidden="true" class="pf-check"><svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="3.2" viewbox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg></span>
<!-- /wp:html -->

<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<strong>Project launched</strong>
<!-- /wp:html -->

<!-- wp:html -->
<small>Every stage complete, ready for your visitors.</small>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","anchor":"approach","className":"section"} -->
<section id="approach" class="wp-block-group section">
<!-- wp:group {"className":"container why-grid"} -->
<div class="wp-block-group container why-grid">
<!-- wp:group {"className":"why-intro reveal"} -->
<div class="wp-block-group why-intro reveal">
<!-- wp:html -->
<span class="eyebrow">The approach</span>
<!-- /wp:html -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Clear thinking.<br/>Careful execution.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A strong website balances visual polish with the practical things that make it useful: clarity, usability, speed, responsive behavior, and a maintainable setup.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<a class="btn btn-primary" href="/about/">More About Me <span class="arrow">↗</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"why-list"} -->
<div class="wp-block-group why-list">
<!-- wp:group {"tagName":"article","className":"why-item reveal"} -->
<article class="wp-block-group why-item reveal">
<!-- wp:html -->
<span class="why-num">01</span>
<!-- /wp:html -->

<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Purpose before decoration</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Page structure and calls to action are planned around what visitors need to understand and do.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"why-item reveal"} -->
<article class="wp-block-group why-item reveal">
<!-- wp:html -->
<span class="why-num">02</span>
<!-- /wp:html -->

<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Responsive from the start</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Layouts are designed to work across desktop, tablet, and mobile rather than treated as an afterthought.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"why-item reveal"} -->
<article class="wp-block-group why-item reveal">
<!-- wp:html -->
<span class="why-num">03</span>
<!-- /wp:html -->

<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Editable and practical</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Where the project uses WordPress and Elementor, the goal is to keep future content updates manageable.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"why-item reveal"} -->
<article class="wp-block-group why-item reveal">
<!-- wp:html -->
<span class="why-num">04</span>
<!-- /wp:html -->

<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Quality checks matter</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Navigation, forms, spacing, links, and core page behavior should be checked before handover.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","anchor":"testimonials","className":"section testimonial-section"} -->
<section id="testimonials" class="wp-block-group section testimonial-section">
<!-- wp:group {"className":"container testimonial-wrap"} -->
<div class="wp-block-group container testimonial-wrap">
<!-- wp:group {"className":"testimonial-side reveal"} -->
<div class="wp-block-group testimonial-side reveal">
<!-- wp:html -->
<span class="eyebrow">Client feedback</span>
<!-- /wp:html -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Trust is built through the process.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Every project starts with a conversation. Tell me about your goals and we will map out a practical next step together.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"ts-actions"} -->
<div class="wp-block-group ts-actions">
<!-- wp:html -->
<a class="btn btn-lime" href="/contact/">Start a conversation <span class="arrow">↗</span></a>
<!-- /wp:html -->

<!-- wp:html -->
<a class="ts-mail" href="mailto:contact@devvitech.com">contact@devvitech.com</a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:list {"className":"ts-points"} -->
<ul class="wp-block-list ts-points"><!-- wp:list-item -->
<li>Clear communication</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Honest scope and timeline</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Quality checks before handover</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal"} -->
<div class="wp-block-group reveal">
<!-- wp:group {"className":"testimonial-card"} -->
<div class="wp-block-group testimonial-card">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<div class="quote-mark">“</div>
<!-- /wp:html -->

<!-- wp:html -->
<blockquote id="quoteText">This space is reserved for an authentic client testimonial about the collaboration, communication, and final website experience.</blockquote>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"quote-author"} -->
<div class="wp-block-group quote-author">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<strong id="quoteName">Client testimonial placeholder</strong>
<!-- /wp:html -->

<!-- wp:html -->
<small id="quoteRole">Replace with approved name and role</small>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"quote-controls"} -->
<div class="wp-block-group quote-controls">
<!-- wp:html -->
<button aria-label="Previous testimonial" id="quotePrev" type="button">←</button>
<!-- /wp:html -->

<!-- wp:html -->
<button aria-label="Next testimonial" id="quoteNext" type="button">→</button>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"testimonial-disclaimer"} -->
<p class="testimonial-disclaimer">Placeholder text only — no testimonial is being presented as a real client quote.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","anchor":"visitor-feedback","className":"section visitor-feedback"} -->
<section id="visitor-feedback" class="wp-block-group section visitor-feedback">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow">Visitor comments</span>
<!-- /wp:html -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Leave a note. Keep the conversation moving.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p>Share a thought, question, or quick piece of feedback. Approved comments can appear in the rotating showcase.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"feedback-layout"} -->
<div class="wp-block-group feedback-layout">
<!-- wp:group {"className":"feedback-form-card reveal"} -->
<div class="wp-block-group feedback-form-card reveal">
<!-- wp:html -->
<span class="fb-badge"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewbox="0 0 24 24"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"></path></svg></span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Write a comment</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Your message is reviewed first, then shown in the rotating comment panel once it is approved.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<form class="feedback-form" id="visitorCommentForm">
<label for="visitorName">Your name<input autocomplete="name" id="visitorName" maxlength="60" name="name" placeholder="Enter your name" required=""/></label>
<label for="visitorComment">Your comment<textarea id="visitorComment" maxlength="500" name="comment" placeholder="Write your comment (up to 500 characters)" required=""></textarea><span class="cm-count" id="cmCount">0 / 500</span></label>
<button class="btn btn-primary" type="submit">Submit Comment <span class="arrow">↗</span></button>
<p aria-live="polite" class="feedback-status" id="feedbackStatus"></p>
<p class="feedback-local-note">Comments are reviewed before they appear on the site.</p>
</form>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"feedback-display-card reveal"} -->
<div class="wp-block-group feedback-display-card reveal">
<!-- wp:html -->
<span class="fb-badge fb-badge-2"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewbox="0 0 24 24"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"></path></svg></span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Community notes</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Comments rotate automatically every few seconds.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"comment-stage"} -->
<div class="wp-block-group comment-stage">
<!-- wp:group {"tagName":"article","anchor":"rotatingComment","className":"rotating-comment"} -->
<article id="rotatingComment" class="wp-block-group rotating-comment">
<!-- wp:html -->
<blockquote id="rotatingCommentText">Have a question about a website project? Leave a comment and start the conversation.</blockquote>
<!-- /wp:html -->

<!-- wp:group {"tagName":"footer"} -->
<footer class="wp-block-group">
<!-- wp:html -->
<span class="comment-avatar" id="rotatingCommentAvatar">V</span>
<!-- /wp:html -->

<!-- wp:html -->
<span><strong id="rotatingCommentName">Visitor</strong><br/><span id="rotatingCommentLabel">Community comment</span></span>
<!-- /wp:html -->
</footer>
<!-- /wp:group -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-hidden="true" class="cm-progress"><i id="cmBar"></i></div>
<!-- /wp:html -->

<!-- wp:group {"className":"comment-rotation-label"} -->
<div class="wp-block-group comment-rotation-label">
<!-- wp:html -->
<span id="commentCounter">Comment 1</span>
<!-- /wp:html -->

<!-- wp:html -->
<div aria-hidden="true" class="comment-dots" id="commentDots"></div>
<!-- /wp:html -->

<!-- wp:html -->
<button aria-pressed="false" class="comment-toggle" id="commentToggle" type="button">Pause</button>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","anchor":"freelancer-lab","className":"section"} -->
<section id="freelancer-lab" class="wp-block-group section">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow">Freelancer Lab · Sylhet</span>
<!-- /wp:html -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Teaching the next generation of web professionals.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p>Beyond client work, Sadik co-founded Freelancer Lab in Sylhet to help learners build practical, job-ready web and freelancing skills.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"service-grid"} -->
<div class="wp-block-group service-grid">
<!-- wp:group {"tagName":"article","className":"service-card reveal"} -->
<article class="wp-block-group service-card reveal">
<!-- wp:html -->
<div class="service-icon">✎</div>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Hands-on training</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Practical lessons in WordPress, WooCommerce and website building, focused on real projects rather than theory alone.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"service-card reveal"} -->
<article class="wp-block-group service-card reveal">
<!-- wp:html -->
<div class="service-icon">↗</div>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Freelancing guidance</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Learn how to find clients, present your work and deliver websites that solve real business problems.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"service-card reveal"} -->
<article class="wp-block-group service-card reveal">
<!-- wp:html -->
<div class="service-icon">⌖</div>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Learn in Sylhet</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>An in-person learning space at West World Shopping City, 9th floor, Zindabazar, Sylhet. <a class="card-link" href="/contact/">Ask about the next batch <span>→</span></a></p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:html -->
<section aria-labelledby="cta-title" class="cta-section cta2-section">
<div class="container">
<div class="cta2 reveal">
<div class="cta2-copy">
<span class="eyebrow">Have a project in mind?</span>
<h2 id="cta-title">Let’s build something <span>useful.</span></h2>
<p>Tell me about your website, online store or redesign goals. We can map out a practical next step together.</p>
<div class="cta2-actions">
<a class="cta2-btn" href="/contact/"><span>Discuss a Project</span><i aria-hidden="true">↗</i></a>
<a class="cta2-ghost" href="mailto:contact@devvitech.com">Email Me <span aria-hidden="true">→</span></a>
</div>
</div>
<aside aria-label="What happens next" class="cta2-card">
<h3>What happens next</h3>
<ol>
<li><b>1</b><div><strong>Share your goals</strong><small>A new website, online store or redesign</small></div></li>
<li><b>2</b><div><strong>Get a clear plan</strong><small>Structure, scope and timeline</small></div></li>
<li><b>3</b><div><strong>Build and launch</strong><small>Quality-checked before handover</small></div></li>
</ol>
<div class="cta2-contact"><a href="mailto:contact@devvitech.com">contact@devvitech.com</a><span>Based in Sylhet, Bangladesh</span></div>
</aside>
</div>
</div>
</section>
<!-- /wp:html -->

<!-- wp:html -->
<div aria-hidden="true" aria-labelledby="pmTitle" aria-modal="true" class="point-modal" id="pointModal" role="dialog"><div class="pm-panel" id="pmPanel"><button aria-label="Close" class="pm-close" id="pmClose" type="button">×</button><span class="pm-kicker" id="pmKicker"></span><div class="pm-body" id="pmBody"><h3 id="pmTitle"></h3><div class="pm-block"><small>What it means</small><p id="pmDesc"></p></div><div class="pm-block"><small>Why it matters</small><p id="pmWhy"></p></div></div><div class="pm-nav"><button aria-label="Previous point" id="pmPrev" type="button">←</button><span id="pmCount"></span><button aria-label="Next point" id="pmNext" type="button">→</button></div></div></div>
<!-- /wp:html -->

<!-- wp:html -->
<div aria-hidden="true" aria-labelledby="smTitle" aria-modal="true" class="site-modal" id="siteModal" role="dialog"><div class="sm-panel"><button aria-label="Close details" class="sm-close" id="smClose" type="button">×</button><div class="sm-frame"><div class="sw-bar"><i></i><i></i><i></i><span>Design preview · scroll to explore</span></div><div aria-label="Scrollable website preview" class="sm-view" id="smView" tabindex="0"><img alt="" id="smImg"/></div></div><div class="sm-info"><span class="eyebrow" id="smCat"></span><h3 id="smTitle"></h3><p id="smIntro"></p><div class="sm-facts" id="smFacts"></div><h4>Key sections</h4><ul class="sm-secs" id="smSecs"></ul><p class="sm-note">Design preview for illustration. This is not a completed client project.</p><a class="btn btn-primary" href="/contact/">Discuss a similar website <span class="arrow">↗</span></a></div></div></div>
<!-- /wp:html -->

<!-- wp:html -->
<div aria-hidden="true" aria-labelledby="projectModalTitle" aria-modal="true" class="project-modal" id="projectModal" role="dialog">
<div class="project-modal-panel" role="document"><button aria-label="Close project details" class="project-modal-close" id="projectModalClose" type="button">×</button><span class="eyebrow" id="projectModalCategory">Project concept</span><h2 id="projectModalTitle">Project details</h2><p class="project-modal-intro" id="projectModalIntro"></p><div class="project-detail-grid" id="projectDetailGrid"></div><h3>Build focus</h3><ul class="project-detail-list" id="projectDetailList"></ul><p class="project-modal-note" id="projectModalNote"></p><a class="btn btn-dark project-modal-link" id="projectModalLink" rel="noopener noreferrer" target="_blank">Visit live site <span class="arrow">↗</span></a></div>
</div>
<!-- /wp:html -->
</main>
<!-- /wp:group -->
