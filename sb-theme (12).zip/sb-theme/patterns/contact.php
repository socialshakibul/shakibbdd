<?php
/**
 * Title: Contact page content
 * Slug: sb-theme/contact
 * Description: Full Contact page (all sections).
 * Inserter: no
 */
?>
<!-- wp:group {"tagName":"main","anchor":"main"} -->
<main id="main" class="wp-block-group">
<!-- wp:group {"tagName":"section","className":"about-hero"} -->
<section class="wp-block-group about-hero">
<!-- wp:group {"className":"container about-hero-grid"} -->
<div class="wp-block-group container about-hero-grid">
<!-- wp:group {"className":"about-hero-copy reveal"} -->
<div class="wp-block-group about-hero-copy reveal">
<!-- wp:html -->
<div class="about-breadcrumb"><a href="/">Home</a> / Contact</div>
<!-- /wp:html -->

<!-- wp:html -->
<span class="eyebrow">Have a project in mind?</span>
<!-- /wp:html -->

<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Let’s make your<br/><span>next idea happen.</span></h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Tell me what you’re building, improving, or trying to solve. I’ll help you think through the scope and a practical next step for your website.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"hero-buttons"} -->
<div class="wp-block-group hero-buttons">
<!-- wp:html -->
<a class="btn btn-primary" href="#project-inquiry">Start a project inquiry <span class="arrow">↘</span></a>
<!-- /wp:html -->

<!-- wp:html -->
<a class="btn btn-light" href="/pricing/">View pricing <span class="arrow">→</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<ul class="ct-checks"><li>No obligation</li><li>Clear scope</li><li>Practical next step</li></ul>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-label="Project discussion illustration" class="about-hero-art reveal"><div class="about-art-label"><span>Let’s talk / 01</span><span>Open to inquiries</span></div><div aria-hidden="true" class="ct-card"><div class="ct-top"><strong>Project conversation</strong><span class="ct-live">Open to inquiries</span></div><h2>Good work starts with a clear brief.</h2><p>A little context helps turn a broad idea into a focused plan.</p><div class="ct-row sbv-s-i-0"><span>⌘</span><div><strong>Share your goal</strong><small>What should your website help you achieve?</small></div></div><div class="ct-row sbv-s-i-1"><span>↗</span><div><strong>Define the scope</strong><small>Pages, features, platform, and priorities.</small></div></div><div class="ct-row sbv-s-i-2"><span>✓</span><div><strong>Plan the next step</strong><small>Discuss fit, timing, and a sensible approach.</small></div></div></div><div class="ct-chip-float">WordPress · Elementor · eCommerce</div></div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:html -->
<section aria-label="What I can help with" class="about-marquee"><div aria-hidden="true" class="about-marquee-track"><div class="about-marquee-group"><span>WordPress &amp; Elementor</span><b>✳</b><span>Website Design</span><b>✳</b><span>eCommerce</span><b>✳</b><span>Website Redesign</span><b>✳</b><span>UI/UX Design</span><b>✳</b><span>Landing Pages</span><b>✳</b></div><div class="about-marquee-group"><span>WordPress &amp; Elementor</span><b>✳</b><span>Website Design</span><b>✳</b><span>eCommerce</span><b>✳</b><span>Website Redesign</span><b>✳</b><span>UI/UX Design</span><b>✳</b><span>Landing Pages</span><b>✳</b></div></div></section>
<!-- /wp:html -->

<!-- wp:group {"tagName":"section","anchor":"project-inquiry","className":"section sbv-s-background-eef0ff"} -->
<section id="project-inquiry" class="wp-block-group section sbv-s-background-eef0ff">
<!-- wp:group {"className":"container ct-layout"} -->
<div class="wp-block-group container ct-layout">
<!-- wp:group {"tagName":"aside","className":"ct-side reveal"} -->
<aside class="wp-block-group ct-side reveal">
<!-- wp:html -->
<span class="eyebrow">Get in touch</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Let’s talk about what you need.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Choose a channel below or send a project brief using the form. Include as much detail as you can comfortably share.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"ct-method"} -->
<div class="wp-block-group ct-method">
<!-- wp:html -->
<span>in</span>
<!-- /wp:html -->

<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<strong>LinkedIn</strong>
<!-- /wp:html -->

<!-- wp:html -->
<small><a href="https://www.linkedin.com/in/sadikbinjalil/" rel="noopener" target="_blank">Connect professionally ↗</a></small>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"ct-method"} -->
<div class="wp-block-group ct-method">
<!-- wp:html -->
<span>⌘</span>
<!-- /wp:html -->

<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<strong>GitHub</strong>
<!-- /wp:html -->

<!-- wp:html -->
<small><a href="https://github.com/sadikbinjalil" rel="noopener" target="_blank">View code profile ↗</a></small>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"ct-method"} -->
<div class="wp-block-group ct-method">
<!-- wp:html -->
<span>↗</span>
<!-- /wp:html -->

<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<strong>Project type</strong>
<!-- /wp:html -->

<!-- wp:html -->
<small>New website, redesign, WordPress, or eCommerce</small>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"ct-quick"} -->
<div class="wp-block-group ct-quick">
<!-- wp:html -->
<small>Explore more</small>
<!-- /wp:html -->

<!-- wp:html -->
<a href="/services/">Services <span>→</span></a>
<!-- /wp:html -->

<!-- wp:html -->
<a href="/projects/">Projects <span>→</span></a>
<!-- /wp:html -->

<!-- wp:html -->
<a href="/pricing/">Pricing &amp; estimates <span>→</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div class="ct-tip"><b>Tip:</b> Mention your target audience, essential pages, preferred platform, and any deadline to make the first discussion more useful.</div>
<!-- /wp:html -->
</aside>
<!-- /wp:group -->

<!-- wp:group {"className":"ct-form-card reveal"} -->
<div class="wp-block-group ct-form-card reveal">
<!-- wp:group {"className":"ct-form-top"} -->
<div class="wp-block-group ct-form-top">
<!-- wp:group {"className":"ct-form-head"} -->
<div class="wp-block-group ct-form-head">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow">Project inquiry</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Tell me about your project.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Three quick steps. Fields marked with * are required.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<span class="ct-badge">No obligation</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-label="Form progress" class="ct-stepper" id="ctStepper"><div class="ct-st on" data-s="1"><b>1</b><span>Project</span></div><div class="ct-line"><i></i></div><div class="ct-st" data-s="2"><b>2</b><span>You</span></div><div class="ct-line"><i></i></div><div class="ct-st" data-s="3"><b>3</b><span>Details</span></div></div>
<!-- /wp:html -->

<!-- wp:html -->
<div class="ct-pre" id="ctPre" role="note"></div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<form class="ct-form" id="contactForm" novalidate=""><div class="ct-step on" data-step="1"><h3 class="ct-step-title">What do you need?<small>Select everything that applies. You can pick more than one.</small></h3><fieldset class="ct-field sbv-s-grid-column-1-1"><legend class="vh sbv-s-position-absolute sbv-s-left-9999px">Services</legend><div class="ct-svcs"><label class="ct-svc"><input name="services" type="checkbox" value="New website design"/><span class="ct-svc-in"><i><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><rect height="16" rx="2" width="18" x="3" y="4"></rect><path d="M3 9h18M9 9v11"></path></svg></i><b>New website design</b><small>Start fresh with a clear structure and a modern look.</small><em>✓</em></span></label><label class="ct-svc"><input name="services" type="checkbox" value="Website redesign"/><span class="ct-svc-in"><i><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"></path></svg></i><b>Website redesign</b><small>Refresh an existing site’s layout, content and mobile experience.</small><em>✓</em></span></label><label class="ct-svc"><input name="services" type="checkbox" value="WordPress / Elementor development"/><span class="ct-svc-in"><i><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"></circle><path d="M3 12h18M12 3a14 14 0 010 18M12 3a14 14 0 000 18"></path></svg></i><b>WordPress / Elementor</b><small>Editable, well-structured WordPress builds.</small><em>✓</em></span></label><label class="ct-svc"><input name="services" type="checkbox" value="eCommerce / WooCommerce store"/><span class="ct-svc-in"><i><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><path d="M5 7h14l-1.5 9h-11z"></path><circle cx="9" cy="20" r="1.2"></circle><circle cx="16" cy="20" r="1.2"></circle><path d="M5 7L4 3H2"></path></svg></i><b>eCommerce store</b><small>A WooCommerce storefront ready to sell online.</small><em>✓</em></span></label><label class="ct-svc"><input name="services" type="checkbox" value="SEO &amp; speed optimization"/><span class="ct-svc-in"><i><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"></circle><path d="M21 21l-4.3-4.3"></path></svg></i><b>SEO &amp; speed optimization</b><small>On-page SEO, image and performance improvements.</small><em>✓</em></span></label><label class="ct-svc"><input name="services" type="checkbox" value="Landing page"/><span class="ct-svc-in"><i><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><path d="M4 4h16v16H4z"></path><path d="M8 9h8M8 13h5"></path></svg></i><b>Landing page</b><small>One focused page built around a single goal.</small><em>✓</em></span></label><label class="ct-svc"><input name="services" type="checkbox" value="UI/UX design"/><span class="ct-svc-in"><i><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><path d="M12 3l2.6 5.6 6 .7-4.5 4.1 1.2 6L12 16.3 6.7 19.4l1.2-6L3.4 9.3l6-.7z"></path></svg></i><b>UI/UX design</b><small>User flows, hierarchy and interface details.</small><em>✓</em></span></label><label class="ct-svc"><input name="services" type="checkbox" value="Other / not sure yet"/><span class="ct-svc-in"><i><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"></circle><path d="M9.5 9.5a2.5 2.5 0 114 2c-.9.6-1.5 1.1-1.5 2.2M12 17h.01"></path></svg></i><b>Not sure yet</b><small>Describe the idea and we’ll shape it together.</small><em>✓</em></span></label></div><span class="ct-err sbv-s-margin-top-8px">Please select at least one service.</span></fieldset><fieldset class="ct-field sbv-s-grid-column-1-1"><legend>Estimated budget<span class="ct-opt">(optional)</span></legend><div class="ct-chips" role="radiogroup"><label class="ct-chip"><input checked="" name="budget" type="radio" value="Not sure yet"/><span>Not sure yet</span></label><label class="ct-chip"><input name="budget" type="radio" value="Under $300"/><span>Under $300</span></label><label class="ct-chip"><input name="budget" type="radio" value="$300–$600"/><span>$300–$600</span></label><label class="ct-chip"><input name="budget" type="radio" value="$600–$1,000"/><span>$600–$1,000</span></label><label class="ct-chip"><input name="budget" type="radio" value="$1,000+"/><span>$1,000+</span></label></div></fieldset><fieldset class="ct-field sbv-s-grid-column-1-1"><legend>Ideal timeline<span class="ct-opt">(optional)</span></legend><div class="ct-chips" role="radiogroup"><label class="ct-chip"><input checked="" name="timeline" type="radio" value="Flexible"/><span>Flexible</span></label><label class="ct-chip"><input name="timeline" type="radio" value="Within 1–2 weeks"/><span>Within 1–2 weeks</span></label><label class="ct-chip"><input name="timeline" type="radio" value="Within a month"/><span>Within a month</span></label><label class="ct-chip"><input name="timeline" type="radio" value="1–3 months"/><span>1–3 months</span></label></div></fieldset></div><div class="ct-step" data-step="2"><h3 class="ct-step-title">Who should I reply to?<small>Just the essentials so I can get back to you.</small></h3><div class="ct-field"><label for="contactName">Your name *</label><div class="ct-ctl"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"></circle><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"></path></svg><input autocomplete="name" class="ct-input" id="contactName" name="name" placeholder="e.g. Alex Morgan" required="" type="text"/></div><span class="ct-err" id="contactName-err">Please enter your name.</span></div><div class="ct-field"><label for="contactEmail">Email address *</label><div class="ct-ctl"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><rect height="14" rx="2" width="18" x="3" y="5"></rect><path d="M3 7l9 6 9-6"></path></svg><input autocomplete="email" class="ct-input" id="contactEmail" name="email" placeholder="you@example.com" required="" type="email"/></div><span class="ct-err" id="contactEmail-err">Please enter a valid email address.</span></div><div class="ct-field sbv-s-grid-column-1-1" id="ctUrlField"><label for="contactSite"><span id="ctUrlLabel">Website or company</span><span class="ct-req-star"> *</span><span class="ct-opt" id="ctUrlOpt">(optional)</span></label><div class="ct-ctl"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><path d="M10 14a4 4 0 005.7 0l3-3a4 4 0 00-5.7-5.7l-1 1"></path><path d="M14 10a4 4 0 00-5.7 0l-3 3a4 4 0 005.7 5.7l1-1"></path></svg><input autocomplete="url" class="ct-input" id="contactSite" inputmode="url" name="website" placeholder="yourcompany.com" type="text"/></div><span class="ct-err" id="contactSite-err">Please enter a valid website, like yourcompany.com.</span></div><div class="ct-cond" id="ctImprove"><strong>What should be improved?</strong><small>Pick the areas you care about most for your current website.</small><div class="ct-chips"><label class="ct-chip"><input name="improve" type="checkbox" value="Visual design"/><span>Visual design</span></label><label class="ct-chip"><input name="improve" type="checkbox" value="Mobile experience"/><span>Mobile experience</span></label><label class="ct-chip"><input name="improve" type="checkbox" value="Page speed"/><span>Page speed</span></label><label class="ct-chip"><input name="improve" type="checkbox" value="SEO"/><span>SEO</span></label><label class="ct-chip"><input name="improve" type="checkbox" value="Content &amp; structure"/><span>Content &amp; structure</span></label><label class="ct-chip"><input name="improve" type="checkbox" value="More enquiries"/><span>More enquiries</span></label></div></div></div><div class="ct-step" data-step="3"><h3 class="ct-step-title">Describe your project<small>Tell me how you’d like to work together: goals, pages, features, references.</small></h3><div class="ct-field sbv-s-grid-column-1-1"><label for="contactMessage">Project details *</label><textarea class="ct-input" id="contactMessage" maxlength="1500" name="message" placeholder="What are you building? Which pages or features do you need? Do you have an existing website or reference?" required=""></textarea><span class="ct-count" id="ctCount">0 / 1500</span><span class="ct-err" id="contactMessage-err">Please add a little more detail (at least 20 characters).</span></div><div aria-live="polite" class="ct-review"><h4>Your brief at a glance</h4><dl id="ctReview"></dl></div><label class="ct-consent" id="ctConsentWrap"><input id="ctConsent" name="consent" type="checkbox"/><i>✓</i><span>I agree to be contacted about this inquiry. *</span></label><p class="ct-note" id="ctDeliveryNote"></p><input aria-hidden="true" autocomplete="off" class="ct-hp" name="_gotcha" tabindex="-1" type="text"/></div><div class="ct-nav" id="ctNav"><button class="btn btn-light" hidden="" id="ctBack" type="button"><span class="arrow">←</span> Back</button><span class="spacer"></span><button class="btn btn-primary" id="ctNext" type="button">Continue <span class="arrow">→</span></button><button class="btn btn-primary" hidden="" id="ctSubmit" type="submit">Send my inquiry <span class="arrow">↗</span></button></div></form>
<!-- /wp:html -->

<!-- wp:html -->
<div class="ct-done" id="ctDone" tabindex="-1"><svg aria-hidden="true" viewBox="0 0 80 80"><circle cx="40" cy="40" r="30"></circle><path d="M27 41l10 10 18-21"></path></svg><h3 id="ctDoneTitle">Your brief is ready.</h3><p id="ctDoneText"></p><div class="row"><button class="btn btn-primary ct-mailrow" id="ctMail" type="button">Open email again <span class="arrow">✉</span></button><button class="btn btn-light" id="ctCopy" type="button">Copy brief <span class="arrow">⧉</span></button><button class="btn btn-light" id="ctDl" type="button">Download again <span class="arrow">↓</span></button><button class="btn btn-light" id="ctNew" type="button">Start a new brief</button></div></div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","className":"section sbv-s-background-var-ink"} -->
<section class="wp-block-group section sbv-s-background-var-ink">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow sbv-s-color-var-lime">A simple process</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2,"className":"sbv-s-color-white"} -->
<h2 class="wp-block-heading sbv-s-color-white">From first message to clear next steps.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"sbv-s-color-b6c2d4"} -->
<p class="sbv-s-color-b6c2d4">A straightforward starting point keeps the conversation focused and useful.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"pr-steps"} -->
<div class="wp-block-group pr-steps">
<!-- wp:group {"tagName":"article","className":"about-process-card reveal"} -->
<article class="wp-block-group about-process-card reveal">
<!-- wp:html -->
<span class="about-process-number">01</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Share the brief</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Describe your goals, audience, key pages, and the main challenge you want the website to solve.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-process-card reveal"} -->
<article class="wp-block-group about-process-card reveal">
<!-- wp:html -->
<span class="about-process-number">02</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Discuss the scope</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Review priorities, required features, platform, and a realistic project direction.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-process-card reveal"} -->
<article class="wp-block-group about-process-card reveal">
<!-- wp:html -->
<span class="about-process-number">03</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Agree on a plan</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Confirm the deliverables, timeline, and quote before any work begins.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","className":"section"} -->
<section class="wp-block-group section">
<!-- wp:group {"className":"container pr-faq-grid"} -->
<div class="wp-block-group container pr-faq-grid">
<!-- wp:group {"className":"reveal"} -->
<div class="wp-block-group reveal">
<!-- wp:html -->
<span class="eyebrow">Quick answers</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Before you reach out.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Not every detail needs to be decided before the first conversation. A starting idea is enough.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<a class="btn btn-primary" href="#project-inquiry">Send a project brief <span class="arrow">↑</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sv-faq reveal"} -->
<div class="wp-block-group sv-faq reveal">
<!-- wp:html -->
<details open=""><summary>What should I include in my message?</summary><p>Share your main goal, audience, required pages or features, any existing website, and a rough timeline or budget if you have one.</p></details>
<!-- /wp:html -->

<!-- wp:html -->
<details><summary>Can I ask about a redesign?</summary><p>Yes. Include your current website link in the project details and explain what you would like to improve.</p></details>
<!-- /wp:html -->

<!-- wp:html -->
<details><summary>What if I’m not sure what I need?</summary><p>That’s fine. Describe the problem or idea, and the first discussion can help clarify the scope.</p></details>
<!-- /wp:html -->

<!-- wp:html -->
<details><summary>Does submitting this demo form send a message?</summary><p>Not yet. This front-end demo prepares a project brief for review. Connect a form service or backend before publishing to receive real submissions.</p></details>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:html -->
<section aria-labelledby="cta-title" class="cta-section cta2-section">
<div class="container">
<div class="cta2 reveal">
<div class="cta2-copy">
<span class="eyebrow">Have a project in mind?</span>
<h2 id="cta-title">Let’s build something <span>purposeful.</span></h2>
<p>Tell me about your website, online store or redesign goals. We can map out a practical next step together.</p>
<div class="cta2-actions">
<a class="cta2-btn" href="#project-inquiry"><span>Discuss a Project</span><i aria-hidden="true">↗</i></a>
<a class="cta2-ghost" href="mailto:contact@devvitech.com">Email Me <span aria-hidden="true">→</span></a>
</div>
</div>
<aside aria-label="What happens next" class="cta2-card">
<h3>What happens next</h3>
<ol>
<li><b>1</b><div><strong>Share your goals</strong><small>A new website, online store or redesign</small></div></li>
<li><b>2</b><div><strong>Get a clear plan</strong><small>Structure, scope and timeline</small></div></li>
<li><b>3</b><div><strong>Build and launch</strong><small>Quality-checked before handover</small></div></li>
</ol>
<div class="cta2-contact"><a href="mailto:contact@devvitech.com">contact@devvitech.com</a><span>Based in Sylhet, Bangladesh</span></div>
</aside>
</div>
</div>
</section>
<!-- /wp:html -->
</main>
<!-- /wp:group -->
