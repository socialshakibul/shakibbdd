<?php
/**
 * Title: About page content
 * Slug: sb-theme/about
 * Description: Full About page (all sections).
 * Inserter: no
 */
?>
<!-- wp:group {"tagName":"main","anchor":"main"} -->
<main id="main" class="wp-block-group">
<!-- wp:group {"tagName":"section","className":"about-hero"} -->
<section class="wp-block-group about-hero">
<!-- wp:group {"className":"container about-hero-grid"} -->
<div class="wp-block-group container about-hero-grid">
<!-- wp:group {"className":"about-hero-copy reveal"} -->
<div class="wp-block-group about-hero-copy reveal">
<!-- wp:html -->
<div class="about-breadcrumb"><a href="/">Home</a> / About</div>
<!-- /wp:html -->

<!-- wp:html -->
<span class="eyebrow">A little about me</span>
<!-- /wp:html -->

<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Thoughtful websites.<br/><span>Purposeful results.</span></h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>I’m Sadik Bin Jalil, a WordPress and eCommerce developer focused on building polished, fast, and easy-to-manage websites that help businesses move forward. This page shares the principles, experience and process behind the work.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"hero-buttons"} -->
<div class="wp-block-group hero-buttons">
<!-- wp:html -->
<a class="btn btn-primary" href="/projects/">Explore Selected Work <span class="arrow">↗</span></a>
<!-- /wp:html -->

<!-- wp:html -->
<a class="btn btn-light" href="/contact/">Discuss a Project <span class="arrow">→</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"hero-note"} -->
<div class="wp-block-group hero-note">
<!-- wp:html -->
<div aria-hidden="true" class="avatar-stack"><span>WP</span><span>WC</span><span>UX</span></div>
<!-- /wp:html -->

<!-- wp:html -->
<span><strong>From idea to launch</strong><br/>Clear communication. Careful execution.</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-label="Sadik Bin Jalil profile card" class="about-hero-art reveal">
<div class="about-art-label"><span>PROFILE / ABOUT</span><span>WordPress · eCommerce</span></div>
<div class="about-portrait-frame"><img alt="Sadik Bin Jalil profile portrait" loading="eager" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/hero-profile.webp' ) ); ?>"/><div aria-hidden="true" class="about-portrait-fallback">SB</div><div class="about-portrait-caption"><span class="photo-caption-mark">SB</span><span><b>Sadik Bin Jalil</b><small>WordPress &amp; eCommerce</small></span></div></div>
<div class="about-art-chip one"><strong>WordPress</strong><small>Flexible website foundations</small></div><div class="about-art-chip two"><strong>Build with purpose ↗</strong><small>Useful, responsive experiences</small></div>
</div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:html -->
<section aria-label="Professional focus areas" class="about-marquee"><div aria-hidden="true" class="about-marquee-track"><div class="about-marquee-group"><span>WordPress Development</span><b>✳</b><span>WooCommerce</span><b>✳</b><span>Elementor Websites</span><b>✳</b><span>Responsive Design</span><b>✳</b><span>Website Redesign</span><b>✳</b><span>eCommerce Experiences</span><b>✳</b></div><div class="about-marquee-group"><span>WordPress Development</span><b>✳</b><span>WooCommerce</span><b>✳</b><span>Elementor Websites</span><b>✳</b><span>Responsive Design</span><b>✳</b><span>Website Redesign</span><b>✳</b><span>eCommerce Experiences</span><b>✳</b></div></div></section>
<!-- /wp:html -->

<!-- wp:group {"tagName":"section","className":"section"} -->
<section class="wp-block-group section">
<!-- wp:group {"className":"container about-story-grid"} -->
<div class="wp-block-group container about-story-grid">
<!-- wp:group {"className":"about-story-aside reveal"} -->
<div class="wp-block-group about-story-aside reveal">
<!-- wp:html -->
<span class="eyebrow">My Story</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Make websites easier to use—and easier to manage.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Good development should feel thoughtful to the visitor and practical for the people running the business.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"about-prose reveal"} -->
<div class="wp-block-group about-prose reveal">
<!-- wp:paragraph -->
<p>A website is more than a visual showcase. It should help people understand an offer, find the information they need, and take the next step without friction.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>My professional focus centers on WordPress-based websites and eCommerce experiences. That means considering the content structure, responsive behavior, usability, and how comfortably a site can be maintained after launch.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>I value clear scope, honest communication, and decisions that serve the project—not effects added just for decoration. Each build should balance visual quality with accessibility, performance, and the needs of its audience.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","anchor":"impact","className":"section"} -->
<section id="impact" class="wp-block-group section">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow">Experience &amp; achievements</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Numbers that reflect<br/>the work behind it.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p>Every project deserves clear structure, useful details, responsive layouts, and a smooth experience from the first click to the final action.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"anchor":"statTrack","className":"stat-track"} -->
<div id="statTrack" class="wp-block-group stat-track">
<!-- wp:group {"className":"stat-stage"} -->
<div class="wp-block-group stat-stage">
<!-- wp:group {"className":"stat-deck"} -->
<div class="wp-block-group stat-deck">
<!-- wp:group {"tagName":"article","className":"stat-big sb-1 sbv-p-1"} -->
<article class="wp-block-group stat-big sb-1 sbv-p-1">
<!-- wp:group {"className":"sb-top"} -->
<div class="wp-block-group sb-top">
<!-- wp:html -->
<span class="sb-idx">01 / 04</span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="sb-chip">Experience</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sb-main"} -->
<div class="wp-block-group sb-main">
<!-- wp:group {"className":"sb-copy"} -->
<div class="wp-block-group sb-copy">
<!-- wp:html -->
<span class="sb-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><path d="M12 7v5l3 2"></path><circle cx="12" cy="12" r="9"></circle></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<strong><span class="stat-num" data-count="10" data-suffix="+">10+</span></strong>
<!-- /wp:html -->

<!-- wp:html -->
<span class="sb-label">Years of WordPress experience</span>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"sb-desc"} -->
<p class="sb-desc">Building WordPress websites for businesses, from landing pages to full eCommerce stores.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"vis vis-years"} -->
<div class="wp-block-group vis vis-years">
<!-- wp:html -->
<i class="sbv-k-0 sbv-h-28"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-1 sbv-h-35"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-2 sbv-h-42"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-3 sbv-h-49"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-4 sbv-h-56"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-5 sbv-h-63"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-6 sbv-h-70"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-7 sbv-h-77"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-8 sbv-h-84"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-9 sbv-h-91"></i>
<!-- /wp:html -->

<!-- wp:html -->
<span>Year by year</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-hidden="true" class="sb-bar"><i></i></div>
<!-- /wp:html -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"stat-big sb-2 sbv-p-2"} -->
<article class="wp-block-group stat-big sb-2 sbv-p-2">
<!-- wp:group {"className":"sb-top"} -->
<div class="wp-block-group sb-top">
<!-- wp:html -->
<span class="sb-idx">02 / 04</span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="sb-chip">Delivery</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sb-main"} -->
<div class="wp-block-group sb-main">
<!-- wp:group {"className":"sb-copy"} -->
<div class="wp-block-group sb-copy">
<!-- wp:html -->
<span class="sb-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><path d="M3 7l9-4 9 4-9 4-9-4z"></path><path d="M3 12l9 4 9-4M3 17l9 4 9-4"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<strong><span class="stat-num" data-count="350" data-suffix="+">350+</span></strong>
<!-- /wp:html -->

<!-- wp:html -->
<span class="sb-label">Projects delivered by Devvitech</span>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"sb-desc"} -->
<p class="sb-desc">Websites and online stores delivered by the Devvitech team for clients and brands.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"vis vis-tiles"} -->
<div class="wp-block-group vis vis-tiles">
<!-- wp:html -->
<i class="sbv-k-0"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-1"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-2"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-3"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-4"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-5"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-6"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-7"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-8"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-9"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-10"><b></b><u></u></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-11"><b></b><u></u></i>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-hidden="true" class="sb-bar"><i></i></div>
<!-- /wp:html -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"stat-big sb-3 sbv-p-3"} -->
<article class="wp-block-group stat-big sb-3 sbv-p-3">
<!-- wp:group {"className":"sb-top"} -->
<div class="wp-block-group sb-top">
<!-- wp:html -->
<span class="sb-idx">03 / 04</span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="sb-chip">Training</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sb-main"} -->
<div class="wp-block-group sb-main">
<!-- wp:group {"className":"sb-copy"} -->
<div class="wp-block-group sb-copy">
<!-- wp:html -->
<span class="sb-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><path d="M2 9l10-5 10 5-10 5-10-5z"></path><path d="M6 11.5V16c3 2.5 9 2.5 12 0v-4.5"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<strong><span class="stat-num" data-count="1000" data-suffix="+">1,000+</span></strong>
<!-- /wp:html -->

<!-- wp:html -->
<span class="sb-label">Students trained at FreelancerLab</span>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"sb-desc"} -->
<p class="sb-desc">Learners trained in web and freelancing skills at Freelancer Lab, Sylhet.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"vis vis-people"} -->
<div class="wp-block-group vis vis-people">
<!-- wp:html -->
<i class="sbv-k-0"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-1"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-2"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-3"></i>
<!-- /wp:html -->

<!-- wp:html -->
<i class="sbv-k-4"></i>
<!-- /wp:html -->

<!-- wp:html -->
<span>+ learners</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-hidden="true" class="sb-bar"><i></i></div>
<!-- /wp:html -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"stat-big sb-4 sbv-p-4"} -->
<article class="wp-block-group stat-big sb-4 sbv-p-4">
<!-- wp:group {"className":"sb-top"} -->
<div class="wp-block-group sb-top">
<!-- wp:html -->
<span class="sb-idx">04 / 04</span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="sb-chip">Process</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sb-main"} -->
<div class="wp-block-group sb-main">
<!-- wp:group {"className":"sb-copy"} -->
<div class="wp-block-group sb-copy">
<!-- wp:html -->
<span class="sb-icon"><svg aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="5" cy="18" r="2"></circle><circle cx="19" cy="6" r="2"></circle><path d="M7 18h6a4 4 0 0 0 0-8h-2a4 4 0 0 1 0-8h6"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<strong><span class="stat-num" data-count="4" data-suffix="">4</span></strong>
<!-- /wp:html -->

<!-- wp:html -->
<span class="sb-label">Core build stages</span>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"sb-desc"} -->
<p class="sb-desc">A clear path on every project: understand, plan, build and launch.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"vis vis-steps"} -->
<div class="wp-block-group vis vis-steps">
<!-- wp:group {"className":"sbv-k-0"} -->
<div class="wp-block-group sbv-k-0">
<!-- wp:html -->
<i>1</i>
<!-- /wp:html -->

<!-- wp:html -->
<span>Understand</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sbv-k-1"} -->
<div class="wp-block-group sbv-k-1">
<!-- wp:html -->
<i>2</i>
<!-- /wp:html -->

<!-- wp:html -->
<span>Plan</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sbv-k-2"} -->
<div class="wp-block-group sbv-k-2">
<!-- wp:html -->
<i>3</i>
<!-- /wp:html -->

<!-- wp:html -->
<span>Build</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sbv-k-3"} -->
<div class="wp-block-group sbv-k-3">
<!-- wp:html -->
<i>4</i>
<!-- /wp:html -->

<!-- wp:html -->
<span>Launch</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-hidden="true" class="sb-bar"><i></i></div>
<!-- /wp:html -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-hidden="true" class="stat-dots"><span></span><span></span><span></span><span></span></div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","className":"section"} -->
<section class="wp-block-group section">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow">Skills &amp; expertise</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Built around the details that make a website work.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p>A clear structure, a consistent interface, and a smooth experience across screen sizes.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"about-skills-grid"} -->
<div class="wp-block-group about-skills-grid">
<!-- wp:group {"tagName":"article","className":"about-skill-card reveal"} -->
<article class="wp-block-group about-skill-card reveal">
<!-- wp:html -->
<div class="about-skill-icon">W</div>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">WordPress Development</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Flexible content structures and manageable page layouts for business websites.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"about-skill-tags"} -->
<div class="wp-block-group about-skill-tags">
<!-- wp:html -->
<span>Page structure</span>
<!-- /wp:html -->

<!-- wp:html -->
<span>CMS</span>
<!-- /wp:html -->

<!-- wp:html -->
<span>Maintenance</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-skill-card reveal"} -->
<article class="wp-block-group about-skill-card reveal">
<!-- wp:html -->
<div class="about-skill-icon">E</div>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Elementor Websites</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Consistent sections and reusable layout patterns designed for practical editing.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"about-skill-tags"} -->
<div class="wp-block-group about-skill-tags">
<!-- wp:html -->
<span>Responsive layouts</span>
<!-- /wp:html -->

<!-- wp:html -->
<span>Reusable sections</span>
<!-- /wp:html -->

<!-- wp:html -->
<span>UI consistency</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-skill-card reveal"} -->
<article class="wp-block-group about-skill-card reveal">
<!-- wp:html -->
<div class="about-skill-icon">↗</div>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">WooCommerce & eCommerce</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Store experiences that help visitors browse products and understand the path to purchase.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"about-skill-tags"} -->
<div class="wp-block-group about-skill-tags">
<!-- wp:html -->
<span>Product layouts</span>
<!-- /wp:html -->

<!-- wp:html -->
<span>Store UX</span>
<!-- /wp:html -->

<!-- wp:html -->
<span>Clear CTAs</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-skill-card reveal"} -->
<article class="wp-block-group about-skill-card reveal">
<!-- wp:html -->
<div class="about-skill-icon">▦</div>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Responsive Design</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Layouts that adapt carefully to mobile, tablet, and desktop screens.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"about-skill-tags"} -->
<div class="wp-block-group about-skill-tags">
<!-- wp:html -->
<span>Mobile-first checks</span>
<!-- /wp:html -->

<!-- wp:html -->
<span>Flexible grids</span>
<!-- /wp:html -->

<!-- wp:html -->
<span>Readable type</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-skill-card reveal"} -->
<article class="wp-block-group about-skill-card reveal">
<!-- wp:html -->
<div class="about-skill-icon">✦</div>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">UI & User Experience</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Visual hierarchy, useful navigation, and interactions that support the visitor’s next step.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"about-skill-tags"} -->
<div class="wp-block-group about-skill-tags">
<!-- wp:html -->
<span>Navigation</span>
<!-- /wp:html -->

<!-- wp:html -->
<span>Visual hierarchy</span>
<!-- /wp:html -->

<!-- wp:html -->
<span>Accessibility</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-skill-card reveal"} -->
<article class="wp-block-group about-skill-card reveal">
<!-- wp:html -->
<div class="about-skill-icon">⚙</div>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Website Improvement</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Reviewing existing pages for clarity, consistency, usability, and maintainability.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"about-skill-tags"} -->
<div class="wp-block-group about-skill-tags">
<!-- wp:html -->
<span>Redesign planning</span>
<!-- /wp:html -->

<!-- wp:html -->
<span>Content clarity</span>
<!-- /wp:html -->

<!-- wp:html -->
<span>Quality checks</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","className":"section sbv-s-background-eef0ff"} -->
<section class="wp-block-group section sbv-s-background-eef0ff">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow">Professional Journey</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">A thoughtful progression from discovery to launch.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p>A simple framework keeps the work organized and helps expectations stay clear.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"about-journey"} -->
<div class="wp-block-group about-journey">
<!-- wp:group {"tagName":"article","className":"about-journey-item reveal"} -->
<article class="wp-block-group about-journey-item reveal">
<!-- wp:html -->
<span class="about-journey-dot"></span>
<!-- /wp:html -->

<!-- wp:group {"className":"about-journey-card"} -->
<div class="wp-block-group about-journey-card">
<!-- wp:html -->
<small>Step 01 · Discover</small>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Understand the goal</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Discuss the audience, business needs, required pages, content, and the main action visitors should take.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-journey-item reveal"} -->
<article class="wp-block-group about-journey-item reveal">
<!-- wp:html -->
<span class="about-journey-dot"></span>
<!-- /wp:html -->

<!-- wp:group {"className":"about-journey-card"} -->
<div class="wp-block-group about-journey-card">
<!-- wp:html -->
<small>Step 02 · Plan</small>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Shape the structure</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Organize page sections, navigation, content hierarchy, and the design direction before moving into the build.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-journey-item reveal"} -->
<article class="wp-block-group about-journey-item reveal">
<!-- wp:html -->
<span class="about-journey-dot"></span>
<!-- /wp:html -->

<!-- wp:group {"className":"about-journey-card"} -->
<div class="wp-block-group about-journey-card">
<!-- wp:html -->
<small>Step 03 · Build</small>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Design and develop</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Create a consistent interface with responsive layouts, purposeful interactions, and maintainable page sections.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-journey-item reveal"} -->
<article class="wp-block-group about-journey-item reveal">
<!-- wp:html -->
<span class="about-journey-dot"></span>
<!-- /wp:html -->

<!-- wp:group {"className":"about-journey-card"} -->
<div class="wp-block-group about-journey-card">
<!-- wp:html -->
<small>Step 04 · Review &amp; launch</small>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Check the details</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Review key pages, links, forms, screen sizes, and user flows before the site is ready to go live.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","anchor":"process","className":"section process-section"} -->
<section id="process" class="wp-block-group section process-section">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow">A clear process</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">From first conversation<br/>to confident launch.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p>Good collaboration means knowing what happens next. Each stage is shaped around communication, quality checks, and shared decisions.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"process-grid"} -->
<div class="wp-block-group process-grid">
<!-- wp:group {"tagName":"article","className":"process-step reveal"} -->
<article class="wp-block-group process-step reveal">
<!-- wp:html -->
<span aria-hidden="true" class="ps-dot"><svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="3.2" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="step-num">STEP 01 / DISCOVER</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Understand</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Talk through your goals, audience, existing website, and what success should look like.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<span aria-hidden="true" class="ps-badge"></span>
<!-- /wp:html -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"process-step reveal"} -->
<article class="wp-block-group process-step reveal">
<!-- wp:html -->
<span aria-hidden="true" class="ps-dot"><svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="3.2" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="step-num">STEP 02 / PLAN</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Shape the plan</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Set the page structure, priorities, content needs, timeline, and scope before the build.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<span aria-hidden="true" class="ps-badge"></span>
<!-- /wp:html -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"process-step reveal"} -->
<article class="wp-block-group process-step reveal">
<!-- wp:html -->
<span aria-hidden="true" class="ps-dot"><svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="3.2" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="step-num">STEP 03 / BUILD</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Design & develop</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Create the experience, test responsive layouts, and refine details with your feedback.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<span aria-hidden="true" class="ps-badge"></span>
<!-- /wp:html -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"process-step reveal"} -->
<article class="wp-block-group process-step reveal">
<!-- wp:html -->
<span aria-hidden="true" class="ps-dot"><svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="3.2" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg></span>
<!-- /wp:html -->

<!-- wp:html -->
<span class="step-num">STEP 04 / LAUNCH</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Review & deliver</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Check the key journeys, prepare handover details, and launch with a clear next-step plan.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<span aria-hidden="true" class="ps-badge"></span>
<!-- /wp:html -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"anchor":"processFinish","className":"process-finish"} -->
<div id="processFinish" class="wp-block-group process-finish">
<!-- wp:html -->
<span aria-hidden="true" class="pf-check"><svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="3.2" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg></span>
<!-- /wp:html -->

<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<strong>Project launched</strong>
<!-- /wp:html -->

<!-- wp:html -->
<small>Every stage complete, ready for your visitors.</small>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","className":"section sbv-s-background-var-ink"} -->
<section class="wp-block-group section sbv-s-background-var-ink">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow sbv-s-color-var-lime">Values &amp; Philosophy</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2,"className":"sbv-s-color-white"} -->
<h2 class="wp-block-heading sbv-s-color-white">Good work is clear, considered, and collaborative.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"sbv-s-color-b6c2d4"} -->
<p class="sbv-s-color-b6c2d4">The principles that guide a productive website project.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"about-process-grid"} -->
<div class="wp-block-group about-process-grid">
<!-- wp:group {"tagName":"article","className":"about-process-card reveal"} -->
<article class="wp-block-group about-process-card reveal">
<!-- wp:html -->
<span class="about-process-number">01 / CLARITY</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Clear communication</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Agree on goals, scope, and priorities before the build gets underway.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-process-card reveal"} -->
<article class="wp-block-group about-process-card reveal">
<!-- wp:html -->
<span class="about-process-number">02 / USABILITY</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">People first</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Make information easy to find and the next step easy to understand.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-process-card reveal"} -->
<article class="wp-block-group about-process-card reveal">
<!-- wp:html -->
<span class="about-process-number">03 / CONSISTENCY</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Care for details</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Keep typography, spacing, interactions, and components coherent across pages.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-process-card reveal"} -->
<article class="wp-block-group about-process-card reveal">
<!-- wp:html -->
<span class="about-process-number">04 / OWNERSHIP</span>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Practical to manage</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Prefer structures that are understandable and maintainable after handoff.</p>
<!-- /wp:paragraph -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","anchor":"projects","className":"section"} -->
<section id="projects" class="wp-block-group section">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow">Design showcase</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Website directions for real businesses.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p>Hover a preview to watch the full page scroll, then open the details. Live client sites are linked below.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sw-grid"} -->
<div class="wp-block-group sw-grid">
<!-- wp:group {"tagName":"article","className":"sw-card reveal sbv-d-0"} -->
<article class="wp-block-group sw-card reveal sbv-d-0">
<!-- wp:group {"className":"sw-frame"} -->
<div class="wp-block-group sw-frame">
<!-- wp:group {"className":"sw-bar"} -->
<div class="wp-block-group sw-bar">
<!-- wp:html -->
<i></i>
<!-- /wp:html -->

<!-- wp:html -->
<i></i>
<!-- /wp:html -->

<!-- wp:html -->
<i></i>
<!-- /wp:html -->

<!-- wp:html -->
<span>Design preview</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sw-view"} -->
<div class="wp-block-group sw-view">
<!-- wp:html -->
<img alt="Fitness center website design preview" decoding="async" height="900" loading="lazy" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/project-fitness.webp' ) ); ?>" width="455"/>
<!-- /wp:html -->

<!-- wp:html -->
<span aria-hidden="true" class="sw-hint">Hover to scroll</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sw-meta"} -->
<div class="wp-block-group sw-meta">
<!-- wp:html -->
<small>Fitness &amp; Gym</small>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Fitness Center Website</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A bold, high-energy design for a gym or fitness club.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<button aria-haspopup="dialog" class="sw-btn" data-sw="0" type="button">View details <span aria-hidden="true">↗</span></button>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"sw-card reveal sbv-d-1"} -->
<article class="wp-block-group sw-card reveal sbv-d-1">
<!-- wp:group {"className":"sw-frame"} -->
<div class="wp-block-group sw-frame">
<!-- wp:group {"className":"sw-bar"} -->
<div class="wp-block-group sw-bar">
<!-- wp:html -->
<i></i>
<!-- /wp:html -->

<!-- wp:html -->
<i></i>
<!-- /wp:html -->

<!-- wp:html -->
<i></i>
<!-- /wp:html -->

<!-- wp:html -->
<span>Design preview</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sw-view"} -->
<div class="wp-block-group sw-view">
<!-- wp:html -->
<img alt="Law firm website design preview" decoding="async" height="1200" loading="lazy" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/project-ecommerce.webp' ) ); ?>" width="600"/>
<!-- /wp:html -->

<!-- wp:html -->
<span aria-hidden="true" class="sw-hint">Hover to scroll</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sw-meta"} -->
<div class="wp-block-group sw-meta">
<!-- wp:html -->
<small>Law Firm</small>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Law Firm Website</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A serious, trustworthy design for law practices and legal professionals.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<button aria-haspopup="dialog" class="sw-btn" data-sw="1" type="button">View details <span aria-hidden="true">↗</span></button>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"sw-card reveal sbv-d-2"} -->
<article class="wp-block-group sw-card reveal sbv-d-2">
<!-- wp:group {"className":"sw-frame"} -->
<div class="wp-block-group sw-frame">
<!-- wp:group {"className":"sw-bar"} -->
<div class="wp-block-group sw-bar">
<!-- wp:html -->
<i></i>
<!-- /wp:html -->

<!-- wp:html -->
<i></i>
<!-- /wp:html -->

<!-- wp:html -->
<i></i>
<!-- /wp:html -->

<!-- wp:html -->
<span>Design preview</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sw-view"} -->
<div class="wp-block-group sw-view">
<!-- wp:html -->
<img alt="Residential painting website design preview" decoding="async" height="1075" loading="lazy" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/project-business.webp' ) ); ?>" width="736"/>
<!-- /wp:html -->

<!-- wp:html -->
<span aria-hidden="true" class="sw-hint">Hover to scroll</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sw-meta"} -->
<div class="wp-block-group sw-meta">
<!-- wp:html -->
<small>Home Services</small>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Residential Painting Website</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A bright, friendly design for painters and other home-service businesses.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<button aria-haspopup="dialog" class="sw-btn" data-sw="2" type="button">View details <span aria-hidden="true">↗</span></button>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sw-live"} -->
<div class="wp-block-group sw-live">
<!-- wp:html -->
<span>Live work by Sadik</span>
<!-- /wp:html -->

<!-- wp:html -->
<a href="https://freelancerlabbd.com" rel="noopener noreferrer" target="_blank">Freelancer Lab <i aria-hidden="true">↗</i></a>
<!-- /wp:html -->

<!-- wp:html -->
<a href="https://imransolicitors.co.uk" rel="noopener noreferrer" target="_blank">Imran Solicitors <i aria-hidden="true">↗</i></a>
<!-- /wp:html -->

<!-- wp:html -->
<a href="https://greatamericangaragedoors.com" rel="noopener noreferrer" target="_blank">Great American Garage Doors <i aria-hidden="true">↗</i></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:html -->
<section aria-labelledby="cta-title" class="cta-section cta2-section">
<div class="container">
<div class="cta2 reveal">
<div class="cta2-copy">
<span class="eyebrow">Have a project in mind?</span>
<h2 id="cta-title">Let’s build something <span>useful.</span></h2>
<p>Tell me about your website, online store or redesign goals. We can map out a practical next step together.</p>
<div class="cta2-actions">
<a class="cta2-btn" href="/contact/"><span>Discuss a Project</span><i aria-hidden="true">↗</i></a>
<a class="cta2-ghost" href="mailto:contact@devvitech.com">Email Me <span aria-hidden="true">→</span></a>
</div>
</div>
<aside aria-label="What happens next" class="cta2-card">
<h3>What happens next</h3>
<ol>
<li><b>1</b><div><strong>Share your goals</strong><small>A new website, online store or redesign</small></div></li>
<li><b>2</b><div><strong>Get a clear plan</strong><small>Structure, scope and timeline</small></div></li>
<li><b>3</b><div><strong>Build and launch</strong><small>Quality-checked before handover</small></div></li>
</ol>
<div class="cta2-contact"><a href="mailto:contact@devvitech.com">contact@devvitech.com</a><span>Based in Sylhet, Bangladesh</span></div>
</aside>
</div>
</div>
</section>
<!-- /wp:html -->

<!-- wp:html -->
<div aria-hidden="true" aria-labelledby="smTitle" aria-modal="true" class="site-modal" id="siteModal" role="dialog"><div class="sm-panel"><button aria-label="Close details" class="sm-close" id="smClose" type="button">×</button><div class="sm-frame"><div class="sw-bar"><i></i><i></i><i></i><span>Design preview · scroll to explore</span></div><div aria-label="Scrollable website preview" class="sm-view" id="smView" tabindex="0"><img alt="" id="smImg"/></div></div><div class="sm-info"><span class="eyebrow" id="smCat"></span><h3 id="smTitle"></h3><p id="smIntro"></p><div class="sm-facts" id="smFacts"></div><h4>Key sections</h4><ul class="sm-secs" id="smSecs"></ul><p class="sm-note">Design preview for illustration. This is not a completed client project.</p><a class="btn btn-primary" href="/contact/">Discuss a similar website <span class="arrow">↗</span></a></div></div></div>
<!-- /wp:html -->
</main>
<!-- /wp:group -->
