<?php
/**
 * Title: Projects page content
 * Slug: sb-theme/projects
 * Description: Full Projects page (all sections).
 * Inserter: no
 */
?>
<!-- wp:group {"tagName":"main","anchor":"main"} -->
<main id="main" class="wp-block-group">
<!-- wp:group {"tagName":"section","className":"about-hero"} -->
<section class="wp-block-group about-hero">
<!-- wp:group {"className":"container about-hero-grid"} -->
<div class="wp-block-group container about-hero-grid">
<!-- wp:group {"className":"about-hero-copy reveal"} -->
<div class="wp-block-group about-hero-copy reveal">
<!-- wp:html -->
<div class="about-breadcrumb"><a href="/">Home</a> / Projects</div>
<!-- /wp:html -->

<!-- wp:html -->
<span class="eyebrow">Selected work · Concept explorations</span>
<!-- /wp:html -->

<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Ideas shaped into<br/><span>digital experiences.</span></h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Explore website designs and illustrative concept directions across WordPress, eCommerce and interface design. Open any project to see its overview, features and approach.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"hero-buttons"} -->
<div class="wp-block-group hero-buttons">
<!-- wp:html -->
<a class="btn btn-primary" href="#projects">Explore Projects <span class="arrow">↓</span></a>
<!-- /wp:html -->

<!-- wp:html -->
<a class="btn btn-light" href="/contact/">Discuss a Project <span class="arrow">↗</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div aria-label="Preview of selected website designs" class="about-hero-art reveal"><div class="about-art-label"><span>Project archive / 2026</span><span>Selected work</span></div><div aria-hidden="true" class="pc-stage"><div class="pc-shot a"><img alt="" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/project-fitness.webp' ) ); ?>"/></div><div class="pc-shot b"><img alt="" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/project-ecommerce.webp' ) ); ?>"/></div><div class="pc-shot c"><img alt="" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/project-business.webp' ) ); ?>"/></div></div><div class="about-art-chip two"><strong>9 projects ↗</strong><small>Showcases &amp; concepts</small></div></div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:html -->
<section aria-label="Project categories" class="about-marquee"><div aria-hidden="true" class="about-marquee-track"><div class="about-marquee-group"><span>Web Design</span><b>✳</b><span>WordPress</span><b>✳</b><span>eCommerce</span><b>✳</b><span>UI/UX Design</span><b>✳</b><span>Landing Pages</span><b>✳</b><span>Dashboards</span><b>✳</b></div><div class="about-marquee-group"><span>Web Design</span><b>✳</b><span>WordPress</span><b>✳</b><span>eCommerce</span><b>✳</b><span>UI/UX Design</span><b>✳</b><span>Landing Pages</span><b>✳</b><span>Dashboards</span><b>✳</b></div></div></section>
<!-- /wp:html -->

<!-- wp:group {"tagName":"section","className":"section sbv-s-background-var-ink sbv-s-color-white sbv-s-padding-72px-0"} -->
<section class="wp-block-group section sbv-s-background-var-ink sbv-s-color-white sbv-s-padding-72px-0">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow sbv-s-color-var-lime">The collection</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2,"className":"sbv-s-color-white"} -->
<h2 class="wp-block-heading sbv-s-color-white">A portfolio built around different goals.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"sbv-s-color-b6c2d4"} -->
<p class="sbv-s-color-b6c2d4">From business websites to product pages and dashboards, each project explores a different digital need.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"about-stat-grid"} -->
<div class="wp-block-group about-stat-grid">
<!-- wp:group {"className":"about-stat reveal"} -->
<div class="wp-block-group about-stat reveal">
<!-- wp:html -->
<strong class="count-up" data-count="<?php echo function_exists( 'sbpm_count_projects' ) ? (int) sbpm_count_projects( 'showcase' ) : 3; ?>">0</strong>
<!-- /wp:html -->

<!-- wp:html -->
<span>Showcase website designs</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"about-stat reveal"} -->
<div class="wp-block-group about-stat reveal">
<!-- wp:html -->
<strong class="count-up" data-count="<?php echo function_exists( 'sbpm_count_projects' ) ? (int) sbpm_count_projects( 'concept' ) : 6; ?>">0</strong>
<!-- /wp:html -->

<!-- wp:html -->
<span>Concept directions</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"about-stat reveal"} -->
<div class="wp-block-group about-stat reveal">
<!-- wp:html -->
<strong class="count-up" data-count="<?php echo function_exists( 'sbpm_count_projects' ) ? (int) sbpm_count_projects( 'categories' ) : 4; ?>">0</strong>
<!-- /wp:html -->

<!-- wp:html -->
<span>Categories to explore</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","anchor":"projects","className":"section"} -->
<section id="projects" class="wp-block-group section">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow">Project gallery</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Real designs and concept ideas, side by side.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p>Choose a category to narrow the gallery, then open any project for its overview, key sections and a larger scrollable preview.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<?php if ( function_exists( 'sbpm_render_projects' ) ) : ?>
<!-- wp:html -->
<?php echo sbpm_render_projects(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
<!-- /wp:html -->

<?php else : ?>
<!-- wp:html -->
<div aria-label="Filter projects by category" class="pj-filters reveal" role="group">
<button aria-pressed="true" class="pj-filter" data-filter="all" type="button">All Projects <span>(9)</span></button>
<button aria-pressed="false" class="pj-filter" data-filter="web-design" type="button">Web Design</button>
<button aria-pressed="false" class="pj-filter" data-filter="wordpress" type="button">WordPress</button>
<button aria-pressed="false" class="pj-filter" data-filter="ecommerce" type="button">eCommerce</button>
<button aria-pressed="false" class="pj-filter" data-filter="ui-ux" type="button">UI/UX Design</button>
</div>
<!-- /wp:html -->

<!-- wp:group {"className":"pj-group"} -->
<div class="wp-block-group pj-group">
<!-- wp:heading {"level":3,"className":"pj-group-title reveal"} -->
<h3 class="wp-block-heading pj-group-title reveal">Website showcase <small>Hover a preview to watch the full page scroll</small></h3>
<!-- /wp:heading -->

<!-- wp:group {"className":"sw-grid"} -->
<div class="wp-block-group sw-grid">
<!-- wp:html -->
<article class="sw-card reveal sbv-d-0" data-category="web-design wordpress"><div class="sw-frame"><div class="sw-bar"><i></i><i></i><i></i><span>Design preview</span></div><div class="sw-view"><img alt="Fitness center website design preview" decoding="async" height="900" loading="lazy" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/project-fitness.webp' ) ); ?>" width="455"/><span aria-hidden="true" class="sw-hint">Hover to scroll</span></div></div><div class="sw-meta"><small>Fitness &amp; Gym</small><h3>Fitness Center Website</h3><p>A bold, high-energy design for a gym or fitness club.</p><button aria-haspopup="dialog" class="sw-btn" data-sw="0" type="button">View details <span aria-hidden="true">↗</span></button></div></article>
<!-- /wp:html -->

<!-- wp:html -->
<article class="sw-card reveal sbv-d-1" data-category="web-design"><div class="sw-frame"><div class="sw-bar"><i></i><i></i><i></i><span>Design preview</span></div><div class="sw-view"><img alt="Law firm website design preview" decoding="async" height="1200" loading="lazy" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/project-ecommerce.webp' ) ); ?>" width="600"/><span aria-hidden="true" class="sw-hint">Hover to scroll</span></div></div><div class="sw-meta"><small>Law Firm</small><h3>Law Firm Website</h3><p>A serious, trustworthy design for law practices and legal professionals.</p><button aria-haspopup="dialog" class="sw-btn" data-sw="1" type="button">View details <span aria-hidden="true">↗</span></button></div></article>
<!-- /wp:html -->

<!-- wp:html -->
<article class="sw-card reveal sbv-d-2" data-category="web-design wordpress"><div class="sw-frame"><div class="sw-bar"><i></i><i></i><i></i><span>Design preview</span></div><div class="sw-view"><img alt="Residential painting website design preview" decoding="async" height="1075" loading="lazy" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/project-business.webp' ) ); ?>" width="736"/><span aria-hidden="true" class="sw-hint">Hover to scroll</span></div></div><div class="sw-meta"><small>Home Services</small><h3>Residential Painting Website</h3><p>A bright, friendly design for painters and other home-service businesses.</p><button aria-haspopup="dialog" class="sw-btn" data-sw="2" type="button">View details <span aria-hidden="true">↗</span></button></div></article>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"sw-live"} -->
<div class="wp-block-group sw-live">
<!-- wp:html -->
<span>Live work by Sadik</span>
<!-- /wp:html -->

<!-- wp:html -->
<a href="https://freelancerlabbd.com" rel="noopener noreferrer" target="_blank">Freelancer Lab <i aria-hidden="true">↗</i></a>
<!-- /wp:html -->

<!-- wp:html -->
<a href="https://imransolicitors.co.uk" rel="noopener noreferrer" target="_blank">Imran Solicitors <i aria-hidden="true">↗</i></a>
<!-- /wp:html -->

<!-- wp:html -->
<a href="https://greatamericangaragedoors.com" rel="noopener noreferrer" target="_blank">Great American Garage Doors <i aria-hidden="true">↗</i></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"pj-group"} -->
<div class="wp-block-group pj-group">
<!-- wp:heading {"level":3,"className":"pj-group-title reveal"} -->
<h3 class="wp-block-heading pj-group-title reveal">Concept explorations <small>Illustrative design directions</small></h3>
<!-- /wp:heading -->

<!-- wp:group {"anchor":"projectGrid","className":"sw-grid"} -->
<div id="projectGrid" class="wp-block-group sw-grid">
<!-- wp:html -->
<article class="sw-card reveal sbv-d-0" data-category="web-design wordpress"><div class="sw-frame"><div class="sw-bar"><i></i><i></i><i></i><span>Design preview</span></div><div class="sw-view"><img alt="Fitness and gym website design preview" decoding="async" height="960" loading="lazy" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/projects-img-6.webp' ) ); ?>" width="640"/><span aria-hidden="true" class="sw-hint">Hover to scroll</span></div></div><div class="sw-meta"><small>Fitness website<span class="concept-pill">Concept</span></small><h3>Fitness &amp; Gym Website</h3><p>A bold, responsive website direction for a fitness brand to present memberships, classes, and facilities clearly.</p><div class="pj-tags"><span class="pj-tag">WordPress</span><span class="pj-tag">Responsive UI</span><span class="pj-tag">CTA design</span></div><button aria-haspopup="dialog" class="sw-btn" data-sw="3" type="button">View details <span aria-hidden="true">↗</span></button></div><div class="sw-extra" hidden=""><img alt="" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/projects-img-7.webp' ) ); ?>"/><img alt="" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/projects-img-8.webp' ) ); ?>"/></div></article>
<!-- /wp:html -->

<!-- wp:html -->
<article class="sw-card reveal sbv-d-1" data-category="ecommerce wordpress"><div class="sw-frame"><div class="sw-bar"><i></i><i></i><i></i><span>Design preview</span></div><div class="sw-view"><div class="pj-preview pv-shop"><div class="pv-browser"><div class="pv-nav"><i></i><i></i><i></i></div><div class="pv-content"><div class="pv-brand"></div><div class="pv-headline"></div><div class="pv-headline short"></div><div class="pv-copy"></div><div class="pv-cta"></div><div class="pv-blocks"><i></i><i></i><i></i></div></div></div></div></div></div><div class="sw-meta"><small>Online store<span class="concept-pill">Concept</span></small><h3>Modern eCommerce Storefront</h3><p>A store concept focused on product discovery, clear product information, and a simpler path toward checkout.</p><div class="pj-tags"><span class="pj-tag">WooCommerce</span><span class="pj-tag">Product UI</span><span class="pj-tag">UX flow</span></div><button aria-haspopup="dialog" class="sw-btn" data-sw="4" type="button">View details <span aria-hidden="true">↗</span></button></div></article>
<!-- /wp:html -->

<!-- wp:html -->
<article class="sw-card reveal sbv-d-2" data-category="web-design ui-ux"><div class="sw-frame"><div class="sw-bar"><i></i><i></i><i></i><span>Design preview</span></div><div class="sw-view"><div class="pj-preview pv-saas"><div class="pv-browser"><div class="pv-nav"><i></i><i></i><i></i></div><div class="pv-content"><div class="pv-brand"></div><div class="pv-headline"></div><div class="pv-headline short"></div><div class="pv-copy"></div><div class="pv-cta"></div><div class="pv-blocks"><i></i><i></i><i></i></div></div></div></div></div></div><div class="sw-meta"><small>SaaS landing page<span class="concept-pill">Concept</span></small><h3>Software Product Landing Page</h3><p>A focused landing-page concept for explaining a digital product, organizing benefits, and guiding visitors to a next step.</p><div class="pj-tags"><span class="pj-tag">Landing page</span><span class="pj-tag">UI/UX</span><span class="pj-tag">Conversion flow</span></div><button aria-haspopup="dialog" class="sw-btn" data-sw="5" type="button">View details <span aria-hidden="true">↗</span></button></div></article>
<!-- /wp:html -->

<!-- wp:html -->
<article class="sw-card reveal sbv-d-0" data-category="wordpress web-design"><div class="sw-frame"><div class="sw-bar"><i></i><i></i><i></i><span>Design preview</span></div><div class="sw-view"><div class="pj-preview pv-course"><div class="pv-browser"><div class="pv-nav"><i></i><i></i><i></i></div><div class="pv-content"><div class="pv-brand"></div><div class="pv-headline"></div><div class="pv-headline short"></div><div class="pv-copy"></div><div class="pv-cta"></div><div class="pv-blocks"><i></i><i></i><i></i></div></div></div></div></div></div><div class="sw-meta"><small>Education website<span class="concept-pill">Concept</span></small><h3>Online Course Platform</h3><p>An education website concept that organizes course information, instructor introductions, and enrollment actions.</p><div class="pj-tags"><span class="pj-tag">WordPress</span><span class="pj-tag">Content design</span><span class="pj-tag">Responsive</span></div><button aria-haspopup="dialog" class="sw-btn" data-sw="6" type="button">View details <span aria-hidden="true">↗</span></button></div></article>
<!-- /wp:html -->

<!-- wp:html -->
<article class="sw-card reveal sbv-d-1" data-category="web-design ui-ux"><div class="sw-frame"><div class="sw-bar"><i></i><i></i><i></i><span>Design preview</span></div><div class="sw-view"><div class="pj-preview pv-agency"><div class="pv-browser"><div class="pv-nav"><i></i><i></i><i></i></div><div class="pv-content"><div class="pv-brand"></div><div class="pv-headline"></div><div class="pv-headline short"></div><div class="pv-copy"></div><div class="pv-cta"></div><div class="pv-blocks"><i></i><i></i><i></i></div></div></div></div></div></div><div class="sw-meta"><small>Creative agency<span class="concept-pill">Concept</span></small><h3>Creative Agency Portfolio</h3><p>A distinctive portfolio direction with editorial typography, project previews, and clear inquiry pathways.</p><div class="pj-tags"><span class="pj-tag">Visual design</span><span class="pj-tag">Portfolio UX</span><span class="pj-tag">Motion</span></div><button aria-haspopup="dialog" class="sw-btn" data-sw="7" type="button">View details <span aria-hidden="true">↗</span></button></div></article>
<!-- /wp:html -->

<!-- wp:html -->
<article class="sw-card reveal sbv-d-2" data-category="ui-ux web-design"><div class="sw-frame"><div class="sw-bar"><i></i><i></i><i></i><span>Design preview</span></div><div class="sw-view"><div class="pj-preview pv-dashboard"><div class="pv-browser"><div class="pv-nav"><i></i><i></i><i></i></div><div class="pv-content"><div class="pv-brand"></div><div class="pv-headline"></div><div class="pv-headline short"></div><div class="pv-copy"></div><div class="pv-cta"></div><div class="pv-blocks"><i></i><i></i><i></i></div></div></div></div></div></div><div class="sw-meta"><small>Dashboard UI<span class="concept-pill">Concept</span></small><h3>Analytics Dashboard Interface</h3><p>A dashboard UI concept that prioritizes information hierarchy, readable summaries, and a calm workspace layout.</p><div class="pj-tags"><span class="pj-tag">UI/UX</span><span class="pj-tag">Dashboard</span><span class="pj-tag">Accessibility</span></div><button aria-haspopup="dialog" class="sw-btn" data-sw="8" type="button">View details <span aria-hidden="true">↗</span></button></div></article>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<?php endif; ?>

<!-- wp:html -->
<div class="pj-empty" id="projectEmpty" role="status">No concepts match this category yet.</div>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"pjs-disclaimer reveal"} -->
<p class="pjs-disclaimer reveal"><strong>Portfolio transparency:</strong> The six concept entries are illustrative projects created to demonstrate possible design directions. They are not presented as verified client launches, completed commercial work, performance results or testimonials.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","className":"section sbv-s-background-eef0ff"} -->
<section class="wp-block-group section sbv-s-background-eef0ff">
<!-- wp:group {"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"section-head reveal"} -->
<div class="wp-block-group section-head reveal">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="eyebrow">In every project</span>
<!-- /wp:html -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">The details that stay consistent.</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p>Whatever the project type, these principles shape the final result.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"about-skills-grid"} -->
<div class="wp-block-group about-skills-grid">
<!-- wp:group {"tagName":"article","className":"about-skill-card reveal"} -->
<article class="wp-block-group about-skill-card reveal">
<!-- wp:html -->
<div class="about-skill-icon">▦</div>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Responsive by default</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Layouts are planned for mobile, tablet and desktop, with readable type and comfortable spacing.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"about-skill-tags"} -->
<div class="wp-block-group about-skill-tags">
<!-- wp:html -->
<span>Mobile-first</span>
<!-- /wp:html -->

<!-- wp:html -->
<span>Flexible grids</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-skill-card reveal"} -->
<article class="wp-block-group about-skill-card reveal">
<!-- wp:html -->
<div class="about-skill-icon">W</div>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Easy to manage</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Page structures are organised so content can be updated without friction after launch.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"about-skill-tags"} -->
<div class="wp-block-group about-skill-tags">
<!-- wp:html -->
<span>WordPress</span>
<!-- /wp:html -->

<!-- wp:html -->
<span>Editable sections</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->

<!-- wp:group {"tagName":"article","className":"about-skill-card reveal"} -->
<article class="wp-block-group about-skill-card reveal">
<!-- wp:html -->
<div class="about-skill-icon">↗</div>
<!-- /wp:html -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Clear next steps</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Every page guides visitors toward an enquiry, a purchase or the next useful action.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"about-skill-tags"} -->
<div class="wp-block-group about-skill-tags">
<!-- wp:html -->
<span>Clear CTAs</span>
<!-- /wp:html -->

<!-- wp:html -->
<span>User flows</span>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</article>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:html -->
<section aria-labelledby="cta-title" class="cta-section cta2-section">
<div class="container">
<div class="cta2 reveal">
<div class="cta2-copy">
<span class="eyebrow">Have a project in mind?</span>
<h2 id="cta-title">Let’s shape your next <span>digital experience.</span></h2>
<p>Tell me about your website, online store or redesign goals. We can map out a practical next step together.</p>
<div class="cta2-actions">
<a class="cta2-btn" href="/contact/"><span>Discuss a Project</span><i aria-hidden="true">↗</i></a>
<a class="cta2-ghost" href="mailto:contact@devvitech.com">Email Me <span aria-hidden="true">→</span></a>
</div>
</div>
<aside aria-label="What happens next" class="cta2-card">
<h3>What happens next</h3>
<ol>
<li><b>1</b><div><strong>Share your goals</strong><small>A new website, online store or redesign</small></div></li>
<li><b>2</b><div><strong>Get a clear plan</strong><small>Structure, scope and timeline</small></div></li>
<li><b>3</b><div><strong>Build and launch</strong><small>Quality-checked before handover</small></div></li>
</ol>
<div class="cta2-contact"><a href="mailto:contact@devvitech.com">contact@devvitech.com</a><span>Based in Sylhet, Bangladesh</span></div>
</aside>
</div>
</div>
</section>
<!-- /wp:html -->

<!-- wp:html -->
<div aria-hidden="true" aria-labelledby="smTitle" aria-modal="true" class="site-modal" id="siteModal" role="dialog"><div class="sm-panel"><button aria-label="Close details" class="sm-close" id="smClose" type="button">×</button><div class="sm-frame"><div class="sw-bar"><i></i><i></i><i></i><span>Design preview · scroll to explore</span></div><div aria-label="Scrollable website preview" class="sm-view" id="smView" tabindex="0"><img alt="" id="smImg"/></div><div class="sm-variants" hidden="" id="smVariants"></div></div><div class="sm-info"><span class="eyebrow" id="smCat"></span><h3 id="smTitle"></h3><p id="smIntro"></p><div class="sm-facts" id="smFacts"></div><h4>Key sections</h4><ul class="sm-secs" id="smSecs"></ul><p class="sm-note">Design preview for illustration. This is not a completed client project.</p><a class="btn btn-primary" href="/contact/">Discuss a similar website <span class="arrow">↗</span></a></div></div></div>
<!-- /wp:html -->
</main>
<!-- /wp:group -->
